
# Bank Account 1

Bank account collects bank account information from merchant. It is optional till the time of boarding where bank account becomes required along with ddaType, achType, accountNumber, routingNumber & bankName.

## Structure

`BankAccount1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dda_type` | [`DdaTypeEnum`](../../doc/models/dda-type-enum.md) | Optional | Direct deposit account type. |
| `ach_type` | [`AchTypeEnum`](../../doc/models/ach-type-enum.md) | Optional | Check deposit type |
| `account_number` | `String` | Optional | Direct deposit account number.  Maximum 17 characters.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `17` |
| `routing_number` | `String` | Optional | Bank routing number. Must be 9 characters and pass ACH Mod-10 validation.<br>**Constraints**: *Minimum Length*: `9`, *Maximum Length*: `9` |
| `bank_name` | `String` | Optional | Bank name used for credit card processing services. |

## Example (as JSON)

```json
{
  "ddaType": "Checking",
  "achType": "Commercial Checking",
  "accountNumber": "011401545",
  "routingNumber": "102000076",
  "bankName": "Bank name"
}
```

