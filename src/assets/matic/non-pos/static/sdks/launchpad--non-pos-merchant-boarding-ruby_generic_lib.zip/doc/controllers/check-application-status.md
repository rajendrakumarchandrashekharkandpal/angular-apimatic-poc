# Check Application Status

```ruby
check_application_status_controller = client.check_application_status
```

## Class Name

`CheckApplicationStatusController`

## Methods

* [Get Application Status](../../doc/controllers/check-application-status.md#get-application-status)
* [Fetch Application Status History](../../doc/controllers/check-application-status.md#fetch-application-status-history)
* [Fetch Signer Status](../../doc/controllers/check-application-status.md#fetch-signer-status)


# Get Application Status

Retrieves the status of a contract when passed with an externalRefID. Both the externalRefID and authorization header are required.

```ruby
def get_application_status(external_ref_id,
                           v_correlation_id: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `UUID \| String` | Header, Required | The externalRefId returned from POST /applications call. |
| `v_correlation_id` | `UUID \| String` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`ApplicationStatus`](../../doc/models/application-status.md)

## Example Usage

```ruby
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

result = check_application_status_controller.get_application_status(
  external_ref_id,
  v_correlation_id: v_correlation_id
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Fetch Application Status History

Use this endpoint to get a application's status history.

```ruby
def fetch_application_status_history(external_ref_id,
                                     v_correlation_id: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `UUID \| String` | Header, Required | The externalRefId returned from POST /applications call. |
| `v_correlation_id` | `UUID \| String` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`StatusHistoryResponse`](../../doc/models/status-history-response.md)

## Example Usage

```ruby
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

result = check_application_status_controller.fetch_application_status_history(
  external_ref_id,
  v_correlation_id: v_correlation_id
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Fetch Signer Status

Use this endpoint to get signer status

```ruby
def fetch_signer_status(external_ref_id,
                        v_correlation_id: nil,
                        content_type: ContentTypeEnum::ENUM_APPLICATIONJSON)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `UUID \| String` | Header, Required | The externalRefId returned from POST /applications call. |
| `v_correlation_id` | `UUID \| String` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `content_type` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

[`SignerStatus`](../../doc/models/signer-status.md)

## Example Usage

```ruby
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

content_type = ContentTypeEnum::ENUM_APPLICATIONJSON

result = check_application_status_controller.fetch_signer_status(
  external_ref_id,
  v_correlation_id: v_correlation_id,
  content_type: content_type
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

