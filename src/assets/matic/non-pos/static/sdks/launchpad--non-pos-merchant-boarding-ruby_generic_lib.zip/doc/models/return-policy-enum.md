
# Return Policy Enum

The business's return policy.

## Enumeration

`ReturnPolicyEnum`

## Fields

| Name |
|  --- |
| `ENUM_3_DAY` |
| `ENUM_30_DAY` |
| `ENUM_60_DAY` |
| `ENUM_60_DAY1` |
| `ENUM_ALL_SALES_FINAL` |
| `ENUM_EXCHANGE_ONLYSTORE_CREDIT` |
| `ENUM_NO_RETURN_POLICY` |

## Example

```
30 Day
```

