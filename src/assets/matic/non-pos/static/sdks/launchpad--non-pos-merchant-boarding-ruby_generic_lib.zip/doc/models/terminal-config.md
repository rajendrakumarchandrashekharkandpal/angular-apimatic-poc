
# Terminal Config

## Structure

`TerminalConfig`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_id` | `String` | Optional | Partner assigned unique request ID for terminal setup. |
| `terminal_id` | `String` | Required | Terminal ID number. |
| `terminal_model` | `String` | Optional | The model name of the terminal in use. |
| `price` | `Float` | Required | Terminal price |
| `quantity` | `Integer` | Required | - |
| `logical_application_id` | `String` | Required | Logical application ID. |
| `access_method` | `String` | Required | Methods of terminal access. |
| `payment_method` | [`PaymentMethodEnum`](../../doc/models/payment-method-enum.md) | Required | Payment method for the selected terminal. |
| `environment_name` | `String` | Required | Environment name |
| `is_var` | `TrueClass \| FalseClass` | Optional | The value added reseller. Default value is false.<br>**Default**: `false` |
| `emv_capable` | `TrueClass \| FalseClass` | Optional | Is it EMV capabale?<br>**Default**: `false` |
| `lease_id` | `String` | Optional | Lease ID. Required when PaymentMethod is selected as lease. |
| `lease_term_length` | [`LeaseTermLengthEnum`](../../doc/models/lease-term-length-enum.md) | Optional | Lease term for the peripheral |
| `terminal_sequence_number` | `String` | Optional | Terminal sequence number. If not sent, the API will autogenerate a number.<br>**Constraints**: *Pattern*: `^[0-9]` |
| `special_customizations` | `String` | Optional | Any customization request for a terminal configuration.<br>**Constraints**: *Maximum Length*: `255` |

## Example (as JSON)

```json
{
  "requestId": "41231",
  "terminalId": "iCT220",
  "terminalModel": "Ingenico iCT220 CTLS 3.X Dial",
  "price": 187.99,
  "quantity": 1,
  "logicalApplicationId": "MONE510",
  "accessMethod": "SSL",
  "paymentMethod": "PURCHASE / SALE",
  "environmentName": "Retail",
  "isVar": false,
  "emvCapable": true,
  "leaseId": "12",
  "leaseTermLength": "24",
  "terminalSequenceNumber": "14",
  "specialCustomizations": "Mulitple merchant setup is Yes"
}
```

