
# Transaction Info 1

## Structure

`TransactionInfo1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `annual_sales_volume` | `Float` | Required | Projected annual sales volume.<br>**Constraints**: `>= 0`, `<= 9999999999999.99` |
| `percent_retail_swiped_transactions` | `Integer` | Required | Projected Percentage of daily card-present transactions.<br>**Constraints**: `>= 0`, `<= 100` |
| `average_ticket` | `Float` | Optional | Average ticket dollar amount.<br>**Constraints**: `>= 0`, `<= 9999999.99` |
| `highest_ticket` | `Float` | Optional | Highest ticket dollar amount.<br>**Constraints**: `>= 0`, `<= 9999999.99` |
| `current_processor` | `String` | Optional | the current processor |
| `accept_chargebacks` | [`AcceptChargebacksEnum`](../../doc/models/accept-chargebacks-enum.md) | Optional | Do you have more than 25 chargeback accepted in the last 12 months? |
| `chargeback_percent` | `Integer` | Optional | Projected chargeback percentage.<br><br>`Required when acceptChargebacks is 'Yes'`<br><br>`Optional when acceptChargebacks is null or 'No'.`<br>**Constraints**: `>= 0`, `<= 100` |
| `return_percent` | `Integer` | Optional | Projected return percent of  goods sold<br>**Constraints**: `>= 0`, `<= 100` |
| `card_not_present_percent` | `Integer` | Optional | Percent of card not present transactions.<br>**Constraints**: `>= 0`, `<= 100` |
| `business_to_business_percent` | `Integer` | Optional | Percent of business-to-business transactions.<br>**Constraints**: `>= 0`, `<= 100` |
| `internet_transaction_percent` | `Integer` | Optional | Percent of internet transactions.<br>**Constraints**: `>= 0`, `<= 100` |
| `in_person_transaction_percent` | `Integer` | Optional | Percent of in person transactions.<br>**Constraints**: `>= 0`, `<= 100` |
| `moto_transaction_percent` | `Integer` | Optional | Percent of mail or phone order transactions.<br>**Constraints**: `>= 0`, `<= 100` |
| `annual_credit_sales_volume` | `Float` | Optional | Projected annual credit card sales volume.<br>**Constraints**: `>= 0`, `<= 999999999.99` |
| `annual_debit_sales_volume` | `Float` | Optional | Projected annual debit card sales volume.<br>**Constraints**: `>= 0`, `<= 999999999.99` |
| `annual_amex_volume` | `Float` | Optional | Projected annual Amex volume. `This field is required when you opt-in for Amex`<br>**Constraints**: `>= 0`, `<= 999999999.99` |
| `amex_average_ticket` | `Float` | Optional | AverageTicket dollar amount for Amex.<br>`This field is required when you opt-in for Amex`<br>**Constraints**: `>= 0`, `<= 9999999.99` |
| `average_numberof_days` | `Integer` | Optional | Average number of days from when cardholder is charged & when products or services are received IN FULL by cardholder.<br>**Constraints**: `>= 0`, `<= 365` |
| `needs_processing_by` | `Date` | Optional | Date (CCYY-MM-DD) by which the Equipment needs to be setup. This field may be required for a given partner. |

## Example (as JSON)

```json
{
  "annualSalesVolume": 20000.12,
  "percentRetailSwipedTransactions": 82,
  "averageTicket": 2.3,
  "highestTicket": 32.41,
  "currentProcessor": "Global Payments",
  "acceptChargebacks": "No",
  "chargebackPercent": 0,
  "returnPercent": 10,
  "cardNotPresentPercent": 20,
  "businessToBusinessPercent": 20,
  "internetTransactionPercent": 10,
  "inPersonTransactionPercent": 10,
  "motoTransactionPercent": 10,
  "annualCreditSalesVolume": 123.32,
  "annualDebitSalesVolume": 32.23,
  "annualAmexVolume": 10000,
  "amexAverageTicket": 2.3,
  "averageNumberofDays": 10,
  "needsProcessingBy": "2022-11-01"
}
```

