
# Error Response Exception

## Structure

`ErrorResponseException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `http_status_code` | `Integer` | Optional | - |
| `http_status_message` | `String` | Optional | - |
| `errors` | [`Array<Error>`](../../doc/models/error.md) | Optional | - |

## Example (as JSON)

```json
{
  "httpStatusCode": 404,
  "httpStatusMessage": "STATUS-MESSAGE",
  "errors": [
    {
      "errorCode": "errorCode6",
      "errorMessage": "errorMessage8",
      "target": "target2"
    },
    {
      "errorCode": "errorCode6",
      "errorMessage": "errorMessage8",
      "target": "target2"
    },
    {
      "errorCode": "errorCode6",
      "errorMessage": "errorMessage8",
      "target": "target2"
    }
  ]
}
```

