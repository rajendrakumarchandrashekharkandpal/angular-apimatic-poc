
# Tax Exempt Enum

## Enumeration

`TaxExemptEnum`

## Fields

| Name |
|  --- |
| `ENUM_TRUE` |
| `ENUM_FALSE` |

