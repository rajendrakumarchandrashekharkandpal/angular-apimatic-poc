
# Terminal Deployment

## Structure

`TerminalDeployment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `equipment_update_deploy` | [`EquipmentUpdateDeployEnum`](../../doc/models/equipment-update-deploy-enum.md) | Required | - |
| `terminal_build_flag` | `TrueClass \| FalseClass` | Optional | - |
| `front_end_build_flag` | `TrueClass \| FalseClass` | Optional | - |
| `sic_merchant_flag` | `TrueClass \| FalseClass` | Optional | - |
| `special_instructions` | `String` | Optional | Special instructions for terminal deployment.<br>**Constraints**: *Maximum Length*: `255` |

## Example (as JSON)

```json
{
  "equipmentUpdateDeploy": "M",
  "terminalBuildFlag": true,
  "frontEndBuildFlag": true,
  "sicMerchantFlag": false,
  "specialInstructions": "Retail - H52460A (SP)"
}
```

