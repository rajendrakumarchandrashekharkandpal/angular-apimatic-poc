
# Inline Response 2001

## Structure

`InlineResponse2001`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `String` | Optional | UP or DOWN status of Lauchpad & it's downstream system. |

## Example (as JSON)

```json
{
  "status": "UP"
}
```

