
# Advanced Settlement Inner

Advanced Settlement gives merchants options to settle their account according to their needs with different settlement categories.

## Structure

`AdvancedSettlementInner`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `settlement_categories` | [`Array<SettlementCategoryEnum>`](../../doc/models/settlement-category-enum.md) | Optional | - |
| `bank_account` | [`BankAccount1`](../../doc/models/bank-account-1.md) | Optional | Bank account collects bank account information from merchant. It is optional till the time of boarding where bank account becomes required along with ddaType, achType, accountNumber, routingNumber & bankName. |

## Example (as JSON)

```json
{
  "settlementCategories": [
    "Fees"
  ],
  "bankAccount": {
    "ddaType": "Checking",
    "achType": "Commercial Checking",
    "accountNumber": "accountNumber4",
    "routingNumber": "routingNumber0",
    "bankName": "bankName6"
  }
}
```

