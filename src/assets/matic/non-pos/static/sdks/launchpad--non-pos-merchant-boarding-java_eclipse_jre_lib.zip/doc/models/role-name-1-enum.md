
# Role Name 1 Enum

The role of the signer. Please note the below.

1) Merchant role name is mandatory.
2) Required fields indicated in schema are those required for all role names other than "SalesRep"
3) The "SalesRep" role name only requires the following fields > roleName, signingExperience, signingOrder, firstName, lastName, email
4) The "Signer2" role name is for a Personal Guarantor. This signer must be included if a Personal Guarantor is on the application. Include the Guarnator's information in this object.

## Enumeration

`RoleName1Enum`

## Fields

| Name |
|  --- |
| `SalesRep` |
| `Merchant` |
| `Signer2` |
| `Signer3` |
| `Signer4` |
| `Signer5` |
| `Signer6` |
| `Signer7` |
| `Signer8` |
| `Guarantor2` |
| `Guarantor3` |
| `Guarantor4` |

## Example

```
Merchant
```

