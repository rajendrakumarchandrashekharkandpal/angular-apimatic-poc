
# Signing Experience Enum

Signing ceremony type

## Enumeration

`SigningExperienceEnum`

## Fields

| Name |
|  --- |
| `Embed` |
| `Email` |
| `Wet` |

## Example

```
email
```

