
# Transaction Info 1

## Structure

`TransactionInfo1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AnnualSalesVolume` | `double` | Required | Projected annual sales volume.<br>**Constraints**: `>= 0`, `<= 9999999999999.99` | double getAnnualSalesVolume() | setAnnualSalesVolume(double annualSalesVolume) |
| `PercentRetailSwipedTransactions` | `int` | Required | Projected Percentage of daily card-present transactions.<br>**Constraints**: `>= 0`, `<= 100` | int getPercentRetailSwipedTransactions() | setPercentRetailSwipedTransactions(int percentRetailSwipedTransactions) |
| `AverageTicket` | `Double` | Optional | Average ticket dollar amount.<br>**Constraints**: `>= 0`, `<= 9999999.99` | Double getAverageTicket() | setAverageTicket(Double averageTicket) |
| `HighestTicket` | `Double` | Optional | Highest ticket dollar amount.<br>**Constraints**: `>= 0`, `<= 9999999.99` | Double getHighestTicket() | setHighestTicket(Double highestTicket) |
| `CurrentProcessor` | `String` | Optional | the current processor | String getCurrentProcessor() | setCurrentProcessor(String currentProcessor) |
| `AcceptChargebacks` | [`AcceptChargebacksEnum`](../../doc/models/accept-chargebacks-enum.md) | Optional | Do you have more than 25 chargeback accepted in the last 12 months? | AcceptChargebacksEnum getAcceptChargebacks() | setAcceptChargebacks(AcceptChargebacksEnum acceptChargebacks) |
| `ChargebackPercent` | `Integer` | Optional | Projected chargeback percentage.<br><br>`Required when acceptChargebacks is 'Yes'`<br><br>`Optional when acceptChargebacks is null or 'No'.`<br>**Constraints**: `>= 0`, `<= 100` | Integer getChargebackPercent() | setChargebackPercent(Integer chargebackPercent) |
| `ReturnPercent` | `Integer` | Optional | Projected return percent of  goods sold<br>**Constraints**: `>= 0`, `<= 100` | Integer getReturnPercent() | setReturnPercent(Integer returnPercent) |
| `CardNotPresentPercent` | `Integer` | Optional | Percent of card not present transactions.<br>**Constraints**: `>= 0`, `<= 100` | Integer getCardNotPresentPercent() | setCardNotPresentPercent(Integer cardNotPresentPercent) |
| `BusinessToBusinessPercent` | `Integer` | Optional | Percent of business-to-business transactions.<br>**Constraints**: `>= 0`, `<= 100` | Integer getBusinessToBusinessPercent() | setBusinessToBusinessPercent(Integer businessToBusinessPercent) |
| `InternetTransactionPercent` | `Integer` | Optional | Percent of internet transactions.<br>**Constraints**: `>= 0`, `<= 100` | Integer getInternetTransactionPercent() | setInternetTransactionPercent(Integer internetTransactionPercent) |
| `InPersonTransactionPercent` | `Integer` | Optional | Percent of in person transactions.<br>**Constraints**: `>= 0`, `<= 100` | Integer getInPersonTransactionPercent() | setInPersonTransactionPercent(Integer inPersonTransactionPercent) |
| `MotoTransactionPercent` | `Integer` | Optional | Percent of mail or phone order transactions.<br>**Constraints**: `>= 0`, `<= 100` | Integer getMotoTransactionPercent() | setMotoTransactionPercent(Integer motoTransactionPercent) |
| `AnnualCreditSalesVolume` | `Double` | Optional | Projected annual credit card sales volume.<br>**Constraints**: `>= 0`, `<= 999999999.99` | Double getAnnualCreditSalesVolume() | setAnnualCreditSalesVolume(Double annualCreditSalesVolume) |
| `AnnualDebitSalesVolume` | `Double` | Optional | Projected annual debit card sales volume.<br>**Constraints**: `>= 0`, `<= 999999999.99` | Double getAnnualDebitSalesVolume() | setAnnualDebitSalesVolume(Double annualDebitSalesVolume) |
| `AnnualAmexVolume` | `Double` | Optional | Projected annual Amex volume. `This field is required when you opt-in for Amex`<br>**Constraints**: `>= 0`, `<= 999999999.99` | Double getAnnualAmexVolume() | setAnnualAmexVolume(Double annualAmexVolume) |
| `AmexAverageTicket` | `Double` | Optional | AverageTicket dollar amount for Amex.<br>`This field is required when you opt-in for Amex`<br>**Constraints**: `>= 0`, `<= 9999999.99` | Double getAmexAverageTicket() | setAmexAverageTicket(Double amexAverageTicket) |
| `AverageNumberofDays` | `Integer` | Optional | Average number of days from when cardholder is charged & when products or services are received IN FULL by cardholder.<br>**Constraints**: `>= 0`, `<= 365` | Integer getAverageNumberofDays() | setAverageNumberofDays(Integer averageNumberofDays) |
| `NeedsProcessingBy` | `LocalDate` | Optional | Date (CCYY-MM-DD) by which the Equipment needs to be setup. This field may be required for a given partner. | LocalDate getNeedsProcessingBy() | setNeedsProcessingBy(LocalDate needsProcessingBy) |

## Example (as JSON)

```json
{
  "annualSalesVolume": 20000.12,
  "percentRetailSwipedTransactions": 82,
  "averageTicket": 2.3,
  "highestTicket": 32.41,
  "currentProcessor": "Global Payments",
  "acceptChargebacks": "No",
  "chargebackPercent": 0,
  "returnPercent": 10,
  "cardNotPresentPercent": 20,
  "businessToBusinessPercent": 20,
  "internetTransactionPercent": 10,
  "inPersonTransactionPercent": 10,
  "motoTransactionPercent": 10,
  "annualCreditSalesVolume": 123.32,
  "annualDebitSalesVolume": 32.23,
  "annualAmexVolume": 10000,
  "amexAverageTicket": 2.3,
  "averageNumberofDays": 10,
  "needsProcessingBy": "2022-11-01"
}
```

