
# Type Enum

The Owner Type. Please note the above Ownership Types where a Control Owner is required.

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `EnumControlOwnerContact` |
| `EnumOwner1Contact` |
| `EnumOwner2Contact` |
| `EnumOwner3Contact` |
| `EnumOwner4Contact` |

