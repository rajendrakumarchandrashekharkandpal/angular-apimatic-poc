
# Error Response Exception

## Structure

`ErrorResponseException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `HttpStatusCode` | `Integer` | Optional | - | Integer getHttpStatusCode() | setHttpStatusCode(Integer httpStatusCode) |
| `HttpStatusMessage` | `String` | Optional | - | String getHttpStatusMessage() | setHttpStatusMessage(String httpStatusMessage) |
| `Errors` | [`List<Error>`](../../doc/models/error.md) | Optional | - | List<Error> getErrors() | setErrors(List<Error> errors) |

## Example (as JSON)

```json
{
  "httpStatusCode": 404,
  "httpStatusMessage": "STATUS-MESSAGE",
  "errors": [
    {
      "errorCode": "errorCode6",
      "errorMessage": "errorMessage8",
      "target": "target2"
    },
    {
      "errorCode": "errorCode6",
      "errorMessage": "errorMessage8",
      "target": "target2"
    },
    {
      "errorCode": "errorCode6",
      "errorMessage": "errorMessage8",
      "target": "target2"
    }
  ]
}
```

