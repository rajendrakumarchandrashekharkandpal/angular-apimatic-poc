# Initiate Boarding Application

```java
InitiateBoardingApplicationController initiateBoardingApplicationController = client.getInitiateBoardingApplicationController();
```

## Class Name

`InitiateBoardingApplicationController`

## Methods

* [Fetch Application](../../doc/controllers/initiate-boarding-application.md#fetch-application)
* [Exisiting Application](../../doc/controllers/initiate-boarding-application.md#exisiting-application)
* [New Application](../../doc/controllers/initiate-boarding-application.md#new-application)


# Fetch Application

Retrieves existing application data.

```java
CompletableFuture<ExistingApplication> fetchApplicationAsync(
    final UUID externalRefId,
    final UUID vCorrelationId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`ExistingApplication`](../../doc/models/existing-application.md)

## Example Usage

```java
UUID externalRefId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");
UUID vCorrelationId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");

initiateBoardingApplicationController.fetchApplicationAsync(externalRefId, vCorrelationId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Exisiting Application

This endpoint allows merchants to update an existing application with new information.

```java
CompletableFuture<Void> exisitingApplicationAsync(
    final ExistingApplication1 body,
    final UUID vCorrelationId,
    final ContentTypeEnum contentType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ExistingApplication1`](../../doc/models/existing-application-1.md) | Body, Required | - |
| `vCorrelationId` | `UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

`void`

## Example Usage

```java
ExistingApplication1 body = new ExistingApplication1.Builder(
    "df8a6d82-3bb4-4f3b-ba18-57a5981ede8e",
    new BusinessInfo1.Builder(
        "The DBA Name",
        "legalName8",
        OwnershipTypeEnum.LLC,
        "5812"
    )
    .businessEstablishedDate(DateTimeHelper.fromSimpleDate("2000-03-23"))
    .websiteUrl("www.thefoodplace.com")
    .numberOfLocation(2)
    .federalTaxId("123456781")
    .paymentAcceptanceMethod(Arrays.asList(
            PaymentAcceptanceMethodEnum.INPERSON,
            PaymentAcceptanceMethodEnum.ONLINESITE
        ))
    .pciadc(PciadcEnum.NO)
    .pcidssValidated(PcidssValidatedEnum.NO)
    .surroundingArea(SurroundingAreaEnum.COMMERCIAL)
    .productServiceSold("Food")
    .ownAddYears(2)
    .seasonal(SeasonalEnum.YES)
    .activeMonths(Arrays.asList(
            ActiveMonthEnum.JAN,
            ActiveMonthEnum.FEB,
            ActiveMonthEnum.MAR
        ))
    .warranty(WarrantyEnum.ENUM_1_YEAR)
    .returnPolicy(ReturnPolicyEnum.ENUM_30_DAY)
    .govOwnedMerchantCountry("US")
    .build(),
    new TransactionInfo1.Builder(
        20000.12D,
        82
    )
    .averageTicket(2.3D)
    .highestTicket(32.41D)
    .currentProcessor("Global Payments")
    .acceptChargebacks(AcceptChargebacksEnum.NO)
    .chargebackPercent(0)
    .returnPercent(10)
    .cardNotPresentPercent(20)
    .businessToBusinessPercent(20)
    .internetTransactionPercent(10)
    .inPersonTransactionPercent(10)
    .motoTransactionPercent(10)
    .annualCreditSalesVolume(123.32D)
    .annualDebitSalesVolume(32.23D)
    .annualAmexVolume(10000D)
    .amexAverageTicket(2.3D)
    .averageNumberofDays(10)
    .needsProcessingBy(DateTimeHelper.fromSimpleDate("2022-11-01"))
    .build()
)
.leadSource("Activate")
.addresses(Arrays.asList(
        new Address1.Builder(
            AddressTypeEnum.ENUM_MAILING_ADDRESS,
            "1234 W Tester Ave.",
            "City Town",
            State1Enum.CO,
            "United States",
            "80123"
        )
        .postalCodeExtension("1234")
        .build(),
        new Address1.Builder(
            AddressTypeEnum.ENUM_PHYSICAL_ADDRESS,
            "1234 W Tester Ave.",
            "City Town",
            State1Enum.CO,
            "United States",
            "80123"
        )
        .postalCodeExtension("1234")
        .build()
    ))
.routeToSalesRep(false)
.build();

UUID vCorrelationId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");
ContentTypeEnum contentType = ContentTypeEnum.ENUM_APPLICATIONJSON;

initiateBoardingApplicationController.exisitingApplicationAsync(body, vCorrelationId, contentType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# New Application

Use this endpoint to collect the merchant information needed to initiate a new contract.

```java
CompletableFuture<ApplicationResponse> newApplicationAsync(
    final Application body,
    final UUID vCorrelationId,
    final ContentTypeEnum contentType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Application`](../../doc/models/application.md) | Body, Required | - |
| `vCorrelationId` | `UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

[`ApplicationResponse`](../../doc/models/application-response.md)

## Example Usage

```java
Application body = new Application.Builder(
    new BusinessInfo1.Builder(
        "The DBA Name",
        "legalName8",
        OwnershipTypeEnum.LLC,
        "5812"
    )
    .businessEstablishedDate(DateTimeHelper.fromSimpleDate("2000-03-23"))
    .websiteUrl("www.thefoodplace.com")
    .numberOfLocation(2)
    .federalTaxId("123456781")
    .paymentAcceptanceMethod(Arrays.asList(
            PaymentAcceptanceMethodEnum.INPERSON,
            PaymentAcceptanceMethodEnum.ONLINESITE
        ))
    .pciadc(PciadcEnum.NO)
    .pcidssValidated(PcidssValidatedEnum.NO)
    .surroundingArea(SurroundingAreaEnum.COMMERCIAL)
    .productServiceSold("Food")
    .ownAddYears(2)
    .seasonal(SeasonalEnum.YES)
    .activeMonths(Arrays.asList(
            ActiveMonthEnum.JAN,
            ActiveMonthEnum.FEB,
            ActiveMonthEnum.MAR
        ))
    .warranty(WarrantyEnum.ENUM_1_YEAR)
    .returnPolicy(ReturnPolicyEnum.ENUM_30_DAY)
    .govOwnedMerchantCountry("US")
    .build(),
    new TransactionInfo1.Builder(
        20000.12D,
        82
    )
    .averageTicket(2.3D)
    .highestTicket(32.41D)
    .currentProcessor("Global Payments")
    .acceptChargebacks(AcceptChargebacksEnum.NO)
    .chargebackPercent(0)
    .returnPercent(10)
    .cardNotPresentPercent(20)
    .businessToBusinessPercent(20)
    .internetTransactionPercent(10)
    .inPersonTransactionPercent(10)
    .motoTransactionPercent(10)
    .annualCreditSalesVolume(123.32D)
    .annualDebitSalesVolume(32.23D)
    .annualAmexVolume(10000D)
    .amexAverageTicket(2.3D)
    .averageNumberofDays(10)
    .needsProcessingBy(DateTimeHelper.fromSimpleDate("2022-11-01"))
    .build(),
    Arrays.asList(
        new AuthorizedSigner1.Builder(
            RoleName1Enum.MERCHANT,
            SigningExperienceEnum.EMAIL,
            "2",
            "Todd",
            "Davis",
            "5131234567",
            "test@gmail.com",
            "123456789",
            DateTimeHelper.fromSimpleDate("2000-03-23"),
            "4355 N Coalwhipe St.",
            "Denver",
            State1Enum.CO,
            "United States",
            "12345"
        )
        .title("President")
        .middleInitial("M")
        .phoneNumberExt("1234")
        .phoneType(PhoneTypeEnum.MOBILE)
        .alternatePhone("5131234567")
        .alternatePhoneType(AlternatePhoneTypeEnum.HOME)
        .faxNumber("5131234567")
        .addressLine2("suite 104")
        .postalCodeExtension("1234")
        .build()
    ),
    Arrays.asList(
        new Contact1.Builder(
            Type4Enum.ENUM_PRIMARY_CONTACT,
            "Todd",
            "Davis",
            "5131234567",
            "test@gmail.com"
        )
        .title("President")
        .middleInitial("M")
        .ssn("123456789")
        .birthDate(DateTimeHelper.fromSimpleDate("2000-03-23"))
        .phoneNumberExt("1234")
        .phoneType(PhoneTypeEnum.MOBILE)
        .alternatePhone("5131234567")
        .alternatePhoneType(AlternatePhoneTypeEnum.HOME)
        .faxNumber("5131234567")
        .build()
    ),
    Arrays.asList(
        new Address1.Builder(
            AddressTypeEnum.ENUM_MAILING_ADDRESS,
            "1234 W Tester Ave.",
            "City Town",
            State1Enum.CO,
            "United States",
            "80123"
        )
        .postalCodeExtension("1234")
        .build(),
        new Address1.Builder(
            AddressTypeEnum.ENUM_PHYSICAL_ADDRESS,
            "1234 W Tester Ave.",
            "City Town",
            State1Enum.CO,
            "United States",
            "80123"
        )
        .postalCodeExtension("1234")
        .build(),
        new Address1.Builder(
            AddressTypeEnum.ENUM_SHIPPING_ADDRESS,
            "1234 W Tester Ave.",
            "City Town",
            State1Enum.CO,
            "United States",
            "80123"
        )
        .postalCodeExtension("1234")
        .build()
    )
)
.clientTrackingId("1341341234132412341")
.leadSource("LP Connect API")
.build();

UUID vCorrelationId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");
ContentTypeEnum contentType = ContentTypeEnum.ENUM_APPLICATIONJSON;

initiateBoardingApplicationController.newApplicationAsync(body, vCorrelationId, contentType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

