
# Inline Response 200 Equipment

## Structure

`InlineResponse200Equipment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Optional | - | String getId() | setId(String id) |
| `Name` | `String` | Optional | - | String getName() | setName(String name) |
| `LogicalApplicationId` | `String` | Optional | - | String getLogicalApplicationId() | setLogicalApplicationId(String logicalApplicationId) |
| `Environment` | `String` | Optional | - | String getEnvironment() | setEnvironment(String environment) |

## Example (as JSON)

```json
{
  "id": "1",
  "name": "Verifone LX570",
  "logicalApplicationId": "1073",
  "environment": "Retail"
}
```

