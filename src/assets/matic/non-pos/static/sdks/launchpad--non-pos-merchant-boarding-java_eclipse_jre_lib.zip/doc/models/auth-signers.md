
# Auth Signers

## Structure

`AuthSigners`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FirstName` | `String` | Optional | First name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `15`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` | String getFirstName() | setFirstName(String firstName) |
| `MiddleInitial` | `String` | Optional | Middle initial.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` | String getMiddleInitial() | setMiddleInitial(String middleInitial) |
| `LastName` | `String` | Optional | Last name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `25`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` | String getLastName() | setLastName(String lastName) |
| `Email` | `String` | Optional | Email address of the contact. Must have @ and a .<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64`, *Pattern*: `\b[A-Za-z0-9._%+-]+@(?:[A-Za-z0-9-]+\.)+[A-Za-z0-9]{2,}` | String getEmail() | setEmail(String email) |
| `Status` | `String` | Optional | Status of the signer | String getStatus() | setStatus(String status) |
| `LastUpdated` | `LocalDateTime` | Optional | Date contract was last updated | LocalDateTime getLastUpdated() | setLastUpdated(LocalDateTime lastUpdated) |
| `DateSubmitted` | `LocalDateTime` | Optional | Date contract was last updated | LocalDateTime getDateSubmitted() | setDateSubmitted(LocalDateTime dateSubmitted) |
| `DateSent` | `LocalDateTime` | Optional | Date contract was sent | LocalDateTime getDateSent() | setDateSent(LocalDateTime dateSent) |
| `DateDelivered` | `LocalDateTime` | Optional | Date contract was delivered | LocalDateTime getDateDelivered() | setDateDelivered(LocalDateTime dateDelivered) |
| `DateSigned` | `LocalDateTime` | Optional | Date contract was signed | LocalDateTime getDateSigned() | setDateSigned(LocalDateTime dateSigned) |
| `SignerRoleName` | `String` | Optional | Role of the signer | String getSignerRoleName() | setSignerRoleName(String signerRoleName) |
| `SignerExperience` | `String` | Optional | Method of sign | String getSignerExperience() | setSignerExperience(String signerExperience) |

## Example (as JSON)

```json
{
  "firstName": "Todd",
  "middleInitial": "M",
  "lastName": "Davis",
  "email": "test@gmail.com",
  "status": "sent",
  "signerRoleName": "Merchant",
  "signerExperience": "wet"
}
```

