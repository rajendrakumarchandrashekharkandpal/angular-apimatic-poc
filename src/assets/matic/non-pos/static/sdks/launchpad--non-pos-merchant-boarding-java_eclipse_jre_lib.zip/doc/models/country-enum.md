
# Country Enum

Only United States is allowed.

## Enumeration

`CountryEnum`

## Fields

| Name |
|  --- |
| `EnumUnitedStates` |

