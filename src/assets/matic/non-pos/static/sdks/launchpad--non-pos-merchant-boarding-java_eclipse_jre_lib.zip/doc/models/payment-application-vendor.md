
# Payment Application Vendor

A payment application is installed software developed for processing various payments types: Credit, Debit, Gift, Checks, etc. and can be integrated with a POS system or used in a standalone manner.

## Structure

`PaymentApplicationVendor`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PaymentApplicationId` | `String` | Optional | Payment application ID | String getPaymentApplicationId() | setPaymentApplicationId(String paymentApplicationId) |
| `PaymentApplicationName` | `String` | Optional | - | String getPaymentApplicationName() | setPaymentApplicationName(String paymentApplicationName) |
| `VendorId` | `String` | Optional | Vendor ID for the payment application. | String getVendorId() | setVendorId(String vendorId) |
| `Version` | `String` | Optional | Payment application version. | String getVersion() | setVersion(String version) |
| `Reseller` | `String` | Optional | Reseller | String getReseller() | setReseller(String reseller) |
| `LastUpgradeDate` | `LocalDateTime` | Optional | Last date payment application was upgraded. | LocalDateTime getLastUpgradeDate() | setLastUpgradeDate(LocalDateTime lastUpgradeDate) |
| `Notes` | `String` | Optional | Custom notes can go here. | String getNotes() | setNotes(String notes) |

## Example (as JSON)

```json
{
  "paymentApplicationId": "9",
  "paymentApplicationName": "PurchaseExpress",
  "vendorId": "4",
  "version": "1",
  "reseller": "Agilysys Inc",
  "lastUpgradeDate": "02/18/2012 00:00:00",
  "notes": "Paymetric Gateway v3"
}
```

