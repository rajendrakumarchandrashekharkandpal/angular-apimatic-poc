
# Sales Agent 1

The agent who is submitting the deal. It is an optional object. It becomes required, when  partner wants to route deals to their own sales rep. Please work with your integration specialist for route to sales rep functionality.

## Structure

`SalesAgent1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Optional | Id for the Sales Contact.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `15` | String getId() | setId(String id) |
| `FirstName` | `String` | Required | Sales agent's first name.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `15` | String getFirstName() | setFirstName(String firstName) |
| `LastName` | `String` | Required | Sales agent's last name.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `25` | String getLastName() | setLastName(String lastName) |
| `MobilePhoneNumber` | `String` | Optional | Sales agent's 10-digit phone number of the format 5131234567.<br>**Constraints**: *Pattern*: `^[0-9]{10}$` | String getMobilePhoneNumber() | setMobilePhoneNumber(String mobilePhoneNumber) |
| `Email` | `String` | Required | Sales agent's email address.  Must have @ and a .<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64`, *Pattern*: `(\\b[A-Za-z0-9._%+-]+@(?:[A-Za-z0-9-]+\\.)+[A-Za-z0-9]{2,}\\b{0,64})` | String getEmail() | setEmail(String email) |

## Example (as JSON)

```json
{
  "id": "U15315",
  "firstName": "John",
  "lastName": "Doe",
  "mobilePhoneNumber": "1234567890",
  "email": "email4"
}
```

