
# Return Policy Enum

The business's return policy.

## Enumeration

`ReturnPolicyEnum`

## Fields

| Name |
|  --- |
| `Enum3Day` |
| `Enum30Day` |
| `Enum60Day` |
| `Enum60Day1` |
| `EnumALLSALESFINAL` |
| `EnumEXCHANGEONLYSTORECREDIT` |
| `EnumNORETURNPOLICY` |

## Example

```
30 Day
```

