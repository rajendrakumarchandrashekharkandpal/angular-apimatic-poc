
# Terminal Supply

## Structure

`TerminalSupply`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `SupplyType` | `String` | Required | - | String getSupplyType() | setSupplyType(String supplyType) |
| `Name` | `String` | Optional | Supply name | String getName() | setName(String name) |
| `Quantity` | `Integer` | Optional | Supply quantity | Integer getQuantity() | setQuantity(Integer quantity) |
| `Total` | `String` | Optional | Total Supplies. Valid values are 0.00<br><br>- 9999999999.99."<br>**Constraints**: *Pattern*: `(^\d{1,10}([.]\d{1,2})?)$` | String getTotal() | setTotal(String total) |

## Example (as JSON)

```json
{
  "supplyType": "supplyType2",
  "quantity": 2,
  "total": "220.21",
  "name": "name6"
}
```

