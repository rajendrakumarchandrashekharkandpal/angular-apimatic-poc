
# Additional Configuration Peripheral

## Structure

`AdditionalConfigurationPeripheral`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PeripheralId` | `String` | Optional | Peripheral IDs are internally populated. | String getPeripheralId() | setPeripheralId(String peripheralId) |
| `Model` | `String` | Optional | Peripheral Name | String getModel() | setModel(String model) |
| `ShortDescription` | `String` | Optional | Description of the peripheral | String getShortDescription() | setShortDescription(String shortDescription) |
| `LongDescription` | `String` | Optional | Verbose description of the peripheral | String getLongDescription() | setLongDescription(String longDescription) |
| `IsEMVCertified` | `Boolean` | Optional | Whether peripheral is EMV certified | Boolean getIsEMVCertified() | setIsEMVCertified(Boolean isEMVCertified) |
| `IsEMVCapable` | `Boolean` | Optional | Whether peripheral is EMV Capable | Boolean getIsEMVCapable() | setIsEMVCapable(Boolean isEMVCapable) |
| `ActivePeripheralFlag` | `String` | Optional | - | String getActivePeripheralFlag() | setActivePeripheralFlag(String activePeripheralFlag) |
| `PurchasePrice` | `String` | Optional | purchase price of the peripheral | String getPurchasePrice() | setPurchasePrice(String purchasePrice) |
| `LeasePrice` | `String` | Optional | lease price of the peripheral | String getLeasePrice() | setLeasePrice(String leasePrice) |
| `RentalPrice` | `String` | Optional | rental price of the peripheral | String getRentalPrice() | setRentalPrice(String rentalPrice) |
| `HardwareCost` | `String` | Optional | hardware cost of the terminal | String getHardwareCost() | setHardwareCost(String hardwareCost) |

## Example (as JSON)

```json
{
  "peripheralId": "35",
  "model": "Pin Pad 1000 SE",
  "shortDescription": "PP1S",
  "longDescription": "PPAD",
  "isEMVCertified": true,
  "isEMVCapable": true,
  "activePeripheralFlag": "Y",
  "purchasePrice": "168.12",
  "leasePrice": "100.12",
  "rentalPrice": "90",
  "hardwareCost": "50.75"
}
```

