# Check Launchpadhealth

```java
CheckLaunchpadhealthController checkLaunchpadhealthController = client.getCheckLaunchpadhealthController();
```

## Class Name

`CheckLaunchpadhealthController`


# Gethealth

Checks the the health of Launchpad and its dependent down streams systems like CPQ, Sales Force, XAA and Jigsaw at regular intervals to check the system is up or down.

```java
CompletableFuture<InlineResponse2001> gethealthAsync(
    final UUID vCorrelationId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vCorrelationId` | `UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`InlineResponse2001`](../../doc/models/inline-response-2001.md)

## Example Usage

```java
UUID vCorrelationId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");

checkLaunchpadhealthController.gethealthAsync(vCorrelationId).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

