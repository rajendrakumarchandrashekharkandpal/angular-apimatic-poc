
# Additional Information Object

Required for some partners. Work with your Developer Integrations specialist for more information.

## Structure

`AdditionalInformationObject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Key` | [`KeyEnum`](../../doc/models/key-enum.md) | Optional | - | KeyEnum getKey() | setKey(KeyEnum key) |
| `Value` | `String` | Optional | - | String getValue() | setValue(String value) |

## Example (as JSON)

```json
{
  "key": "partnerEmployeeId",
  "value": "4656"
}
```

