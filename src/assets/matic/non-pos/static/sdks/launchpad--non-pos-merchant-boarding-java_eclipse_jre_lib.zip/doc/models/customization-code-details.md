
# Customization Code Details

## Structure

`CustomizationCodeDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Value` | `String` | Optional | customization code | String getValue() | setValue(String value) |
| `ShortDescription` | `String` | Optional | short description of the customization code | String getShortDescription() | setShortDescription(String shortDescription) |
| `LongDescription` | `String` | Optional | long description of the customization code | String getLongDescription() | setLongDescription(String longDescription) |

## Example (as JSON)

```json
{
  "value": "H",
  "shortDescription": "Host Auto Close",
  "longDescription": "Host Auto Close"
}
```

