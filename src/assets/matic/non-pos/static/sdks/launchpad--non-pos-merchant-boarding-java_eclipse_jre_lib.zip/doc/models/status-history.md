
# Status History

## Structure

`StatusHistory`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `StatusSeqNumber` | `Integer` | Optional | - | Integer getStatusSeqNumber() | setStatusSeqNumber(Integer statusSeqNumber) |
| `DetailStatus` | `String` | Optional | - | String getDetailStatus() | setDetailStatus(String detailStatus) |
| `SummaryStatus` | `String` | Optional | - | String getSummaryStatus() | setSummaryStatus(String summaryStatus) |
| `StatusCategory` | `String` | Optional | - | String getStatusCategory() | setStatusCategory(String statusCategory) |
| `StatusDateTime` | `LocalDateTime` | Optional | - | LocalDateTime getStatusDateTime() | setStatusDateTime(LocalDateTime statusDateTime) |

## Example (as JSON)

```json
{
  "statusSeqNumber": 2200,
  "detailStatus": "Contract Signed",
  "summaryStatus": "App Submitted",
  "statusCategory": "Contract",
  "statusDateTime": "2016-03-13T12:52:32.123Z"
}
```

