
# Surrounding Area Enum

Type of area surroundning the business.

## Enumeration

`SurroundingAreaEnum`

## Fields

| Name |
|  --- |
| `Commercial` |
| `Industrial` |
| `Residential` |

## Example

```
Commercial
```

