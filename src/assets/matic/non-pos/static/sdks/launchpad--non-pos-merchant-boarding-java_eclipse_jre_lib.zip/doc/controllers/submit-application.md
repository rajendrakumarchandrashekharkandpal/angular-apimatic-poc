# Submit Application

```java
SubmitApplicationController submitApplicationController = client.getSubmitApplicationController();
```

## Class Name

`SubmitApplicationController`

## Methods

* [Validate Board](../../doc/controllers/submit-application.md#validate-board)
* [Inititate Board](../../doc/controllers/submit-application.md#inititate-board)


# Validate Board

Begins the merchant validation process before boarding after all necessary information has been submitted to the API. Please see the reference guide for specific boarding requirements.

```java
CompletableFuture<Void> validateBoardAsync(
    final UUID externalRefId,
    final UUID vCorrelationId,
    final ContentTypeEnum contentType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

`void`

## Example Usage

```java
UUID externalRefId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");
UUID vCorrelationId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");
ContentTypeEnum contentType = ContentTypeEnum.ENUM_APPLICATIONJSON;

submitApplicationController.validateBoardAsync(externalRefId, vCorrelationId, contentType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Inititate Board

Begins the merchant boarding process after all necessary information has been submitted to the API. Please see the reference guide for specific boarding requirements.

```java
CompletableFuture<Void> inititateBoardAsync(
    final UUID externalRefId,
    final UUID vCorrelationId,
    final ContentTypeEnum contentType,
    final String threatmetrixId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `threatmetrixId` | `String` | Header, Optional | A unique session id |

## Response Type

`void`

## Example Usage

```java
UUID externalRefId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");
UUID vCorrelationId = UUID.fromString("3fcb1437-4e52-4946-9ae1-e618351b6d16");
ContentTypeEnum contentType = ContentTypeEnum.ENUM_APPLICATIONJSON;

submitApplicationController.inititateBoardAsync(externalRefId, vCorrelationId, contentType, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

