
# Peripheral

## Structure

`Peripheral`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PeripheralId` | `String` | Optional | Peripheral IDs are internally populated. | String getPeripheralId() | setPeripheralId(String peripheralId) |
| `PeripheralType` | `String` | Optional | Peripheral type | String getPeripheralType() | setPeripheralType(String peripheralType) |
| `Model` | `String` | Optional | - | String getModel() | setModel(String model) |
| `LeaseId` | `String` | Optional | Lease ID for the peripheral | String getLeaseId() | setLeaseId(String leaseId) |
| `LeaseTermLength` | [`LeaseTermLengthEnum`](../../doc/models/lease-term-length-enum.md) | Optional | Lease term for the peripheral | LeaseTermLengthEnum getLeaseTermLength() | setLeaseTermLength(LeaseTermLengthEnum leaseTermLength) |
| `PaymentMethod` | [`PaymentMethod1Enum`](../../doc/models/payment-method-1-enum.md) | Optional | Payment method for the selected peripheral. | PaymentMethod1Enum getPaymentMethod() | setPaymentMethod(PaymentMethod1Enum paymentMethod) |
| `Amount` | `String` | Optional | "Payment Amount for the peripheral. Valid values are 0.00<br><br>- 9999999999.99."<br>**Constraints**: *Pattern*: `(^\d{1,10}([.]\d{1,2})?)$` | String getAmount() | setAmount(String amount) |
| `PaymentConfirmationNumber` | `String` | Optional | Payment confirmation number for the peripheral.<br>**Constraints**: *Pattern*: `[0-9a-zA-Z]{6}\|` | String getPaymentConfirmationNumber() | setPaymentConfirmationNumber(String paymentConfirmationNumber) |

## Example (as JSON)

```json
{
  "peripheralId": "231",
  "peripheralType": "PPAD",
  "model": "Magtek Check Reader",
  "leaseId": "18",
  "leaseTermLength": "24",
  "paymentMethod": "PURCHASE / SALE",
  "amount": "220.21",
  "paymentConfirmationNumber": "123456"
}
```

