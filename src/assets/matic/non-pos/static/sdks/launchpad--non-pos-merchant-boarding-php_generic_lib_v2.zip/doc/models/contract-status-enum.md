
# Contract Status Enum

## Enumeration

`ContractStatusEnum`

## Fields

| Name |
|  --- |
| `COMPLETE` |
| `ENUM_IN_PROGRESS` |
| `ERROR` |
| `PENDING` |

