
# Schema

## Structure

`Schema`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |

## Example (as JSON)

```json
{
  "id": 82
}
```

