
# Transaction Info 1

## Structure

`TransactionInfo1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `annualSalesVolume` | `float` | Required | Projected annual sales volume.<br>**Constraints**: `>= 0`, `<= 9999999999999.99` | getAnnualSalesVolume(): float | setAnnualSalesVolume(float annualSalesVolume): void |
| `percentRetailSwipedTransactions` | `int` | Required | Projected Percentage of daily card-present transactions.<br>**Constraints**: `>= 0`, `<= 100` | getPercentRetailSwipedTransactions(): int | setPercentRetailSwipedTransactions(int percentRetailSwipedTransactions): void |
| `averageTicket` | `?float` | Optional | Average ticket dollar amount.<br>**Constraints**: `>= 0`, `<= 9999999.99` | getAverageTicket(): ?float | setAverageTicket(?float averageTicket): void |
| `highestTicket` | `?float` | Optional | Highest ticket dollar amount.<br>**Constraints**: `>= 0`, `<= 9999999.99` | getHighestTicket(): ?float | setHighestTicket(?float highestTicket): void |
| `currentProcessor` | `?string` | Optional | the current processor | getCurrentProcessor(): ?string | setCurrentProcessor(?string currentProcessor): void |
| `acceptChargebacks` | [`?string(AcceptChargebacksEnum)`](../../doc/models/accept-chargebacks-enum.md) | Optional | Do you have more than 25 chargeback accepted in the last 12 months? | getAcceptChargebacks(): ?string | setAcceptChargebacks(?string acceptChargebacks): void |
| `chargebackPercent` | `?int` | Optional | Projected chargeback percentage.<br><br>`Required when acceptChargebacks is 'Yes'`<br><br>`Optional when acceptChargebacks is null or 'No'.`<br>**Constraints**: `>= 0`, `<= 100` | getChargebackPercent(): ?int | setChargebackPercent(?int chargebackPercent): void |
| `returnPercent` | `?int` | Optional | Projected return percent of  goods sold<br>**Constraints**: `>= 0`, `<= 100` | getReturnPercent(): ?int | setReturnPercent(?int returnPercent): void |
| `cardNotPresentPercent` | `?int` | Optional | Percent of card not present transactions.<br>**Constraints**: `>= 0`, `<= 100` | getCardNotPresentPercent(): ?int | setCardNotPresentPercent(?int cardNotPresentPercent): void |
| `businessToBusinessPercent` | `?int` | Optional | Percent of business-to-business transactions.<br>**Constraints**: `>= 0`, `<= 100` | getBusinessToBusinessPercent(): ?int | setBusinessToBusinessPercent(?int businessToBusinessPercent): void |
| `internetTransactionPercent` | `?int` | Optional | Percent of internet transactions.<br>**Constraints**: `>= 0`, `<= 100` | getInternetTransactionPercent(): ?int | setInternetTransactionPercent(?int internetTransactionPercent): void |
| `inPersonTransactionPercent` | `?int` | Optional | Percent of in person transactions.<br>**Constraints**: `>= 0`, `<= 100` | getInPersonTransactionPercent(): ?int | setInPersonTransactionPercent(?int inPersonTransactionPercent): void |
| `motoTransactionPercent` | `?int` | Optional | Percent of mail or phone order transactions.<br>**Constraints**: `>= 0`, `<= 100` | getMotoTransactionPercent(): ?int | setMotoTransactionPercent(?int motoTransactionPercent): void |
| `annualCreditSalesVolume` | `?float` | Optional | Projected annual credit card sales volume.<br>**Constraints**: `>= 0`, `<= 999999999.99` | getAnnualCreditSalesVolume(): ?float | setAnnualCreditSalesVolume(?float annualCreditSalesVolume): void |
| `annualDebitSalesVolume` | `?float` | Optional | Projected annual debit card sales volume.<br>**Constraints**: `>= 0`, `<= 999999999.99` | getAnnualDebitSalesVolume(): ?float | setAnnualDebitSalesVolume(?float annualDebitSalesVolume): void |
| `annualAmexVolume` | `?float` | Optional | Projected annual Amex volume. `This field is required when you opt-in for Amex`<br>**Constraints**: `>= 0`, `<= 999999999.99` | getAnnualAmexVolume(): ?float | setAnnualAmexVolume(?float annualAmexVolume): void |
| `amexAverageTicket` | `?float` | Optional | AverageTicket dollar amount for Amex.<br>`This field is required when you opt-in for Amex`<br>**Constraints**: `>= 0`, `<= 9999999.99` | getAmexAverageTicket(): ?float | setAmexAverageTicket(?float amexAverageTicket): void |
| `averageNumberofDays` | `?int` | Optional | Average number of days from when cardholder is charged & when products or services are received IN FULL by cardholder.<br>**Constraints**: `>= 0`, `<= 365` | getAverageNumberofDays(): ?int | setAverageNumberofDays(?int averageNumberofDays): void |
| `needsProcessingBy` | `?DateTime` | Optional | Date (CCYY-MM-DD) by which the Equipment needs to be setup. This field may be required for a given partner. | getNeedsProcessingBy(): ?\DateTime | setNeedsProcessingBy(?\DateTime needsProcessingBy): void |

## Example (as JSON)

```json
{
  "annualSalesVolume": 20000.12,
  "percentRetailSwipedTransactions": 82,
  "averageTicket": 2.3,
  "highestTicket": 32.41,
  "currentProcessor": "Global Payments",
  "acceptChargebacks": "No",
  "chargebackPercent": 0,
  "returnPercent": 10,
  "cardNotPresentPercent": 20,
  "businessToBusinessPercent": 20,
  "internetTransactionPercent": 10,
  "inPersonTransactionPercent": 10,
  "motoTransactionPercent": 10,
  "annualCreditSalesVolume": 123.32,
  "annualDebitSalesVolume": 32.23,
  "annualAmexVolume": 10000,
  "amexAverageTicket": 2.3,
  "averageNumberofDays": 10,
  "needsProcessingBy": "2022-11-01"
}
```

