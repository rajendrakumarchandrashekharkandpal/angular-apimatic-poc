
# Bank Account

## Structure

`BankAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ddaType` | [`?string(DdaTypeEnum)`](../../doc/models/dda-type-enum.md) | Optional | Direct deposit account type. | getDdaType(): ?string | setDdaType(?string ddaType): void |
| `achType` | [`?string(AchTypeEnum)`](../../doc/models/ach-type-enum.md) | Optional | Check deposit type | getAchType(): ?string | setAchType(?string achType): void |
| `accountNumber` | `?string` | Optional | Direct deposit account number.  Maximum 17 characters.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `17` | getAccountNumber(): ?string | setAccountNumber(?string accountNumber): void |
| `routingNumber` | `?string` | Optional | Bank routing number. Must be 9 characters and pass ACH Mod-10 validation.<br>**Constraints**: *Minimum Length*: `9`, *Maximum Length*: `9` | getRoutingNumber(): ?string | setRoutingNumber(?string routingNumber): void |
| `bankName` | `?string` | Optional | Bank name used for credit card processing services. | getBankName(): ?string | setBankName(?string bankName): void |

## Example (as JSON)

```json
{
  "ddaType": "Checking",
  "achType": "Commercial Checking",
  "accountNumber": "011401545",
  "routingNumber": "102000076",
  "bankName": "Bank name"
}
```

