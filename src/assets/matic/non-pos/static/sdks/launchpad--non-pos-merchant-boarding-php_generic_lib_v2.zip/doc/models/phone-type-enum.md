
# Phone Type Enum

Phone type.

## Enumeration

`PhoneTypeEnum`

## Fields

| Name |
|  --- |
| `MOBILE` |
| `HOME` |

## Example

```
mobile
```

