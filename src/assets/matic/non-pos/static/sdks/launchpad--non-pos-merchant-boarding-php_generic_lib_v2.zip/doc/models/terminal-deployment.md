
# Terminal Deployment

## Structure

`TerminalDeployment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `equipmentUpdateDeploy` | [`string(EquipmentUpdateDeployEnum)`](../../doc/models/equipment-update-deploy-enum.md) | Required | - | getEquipmentUpdateDeploy(): string | setEquipmentUpdateDeploy(string equipmentUpdateDeploy): void |
| `terminalBuildFlag` | `?bool` | Optional | - | getTerminalBuildFlag(): ?bool | setTerminalBuildFlag(?bool terminalBuildFlag): void |
| `frontEndBuildFlag` | `?bool` | Optional | - | getFrontEndBuildFlag(): ?bool | setFrontEndBuildFlag(?bool frontEndBuildFlag): void |
| `sicMerchantFlag` | `?bool` | Optional | - | getSicMerchantFlag(): ?bool | setSicMerchantFlag(?bool sicMerchantFlag): void |
| `specialInstructions` | `?string` | Optional | Special instructions for terminal deployment.<br>**Constraints**: *Maximum Length*: `255` | getSpecialInstructions(): ?string | setSpecialInstructions(?string specialInstructions): void |

## Example (as JSON)

```json
{
  "equipmentUpdateDeploy": "M",
  "terminalBuildFlag": true,
  "frontEndBuildFlag": true,
  "sicMerchantFlag": false,
  "specialInstructions": "Retail - H52460A (SP)"
}
```

