
# Tax Exempt Enum

## Enumeration

`TaxExemptEnum`

## Fields

| Name |
|  --- |
| `TRUE` |
| `FALSE` |

