# Check Launchpadhealth

```php
$checkLaunchpadhealthController = $client->getCheckLaunchpadhealthController();
```

## Class Name

`CheckLaunchpadhealthController`


# Gethealth

Checks the the health of Launchpad and its dependent down streams systems like CPQ, Sales Force, XAA and Jigsaw at regular intervals to check the system is up or down.

```php
function gethealth(?string $vCorrelationId = null): InlineResponse2001
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vCorrelationId` | `?string` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`InlineResponse2001`](../../doc/models/inline-response-2001.md)

## Example Usage

```php
$vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$result = $checkLaunchpadHealthController->gethealth($vCorrelationId);
```

