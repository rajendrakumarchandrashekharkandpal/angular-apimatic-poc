
# Payment Acceptance Method Enum

## Enumeration

`PaymentAcceptanceMethodEnum`

## Fields

| Name |
|  --- |
| `INPERSON` |
| `ONLINESITE` |
| `PHONEORMAILORDER` |

