# Initiate Boarding Application

```php
$initiateBoardingApplicationController = $client->getInitiateBoardingApplicationController();
```

## Class Name

`InitiateBoardingApplicationController`

## Methods

* [Fetch Application](../../doc/controllers/initiate-boarding-application.md#fetch-application)
* [Exisiting Application](../../doc/controllers/initiate-boarding-application.md#exisiting-application)
* [New Application](../../doc/controllers/initiate-boarding-application.md#new-application)


# Fetch Application

Retrieves existing application data.

```php
function fetchApplication(string $externalRefId, ?string $vCorrelationId = null): ExistingApplication
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `?string` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`ExistingApplication`](../../doc/models/existing-application.md)

## Example Usage

```php
$externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$result = $initiateBoardingApplicationController->fetchApplication(
    $externalRefId,
    $vCorrelationId
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Exisiting Application

This endpoint allows merchants to update an existing application with new information.

```php
function exisitingApplication(
    ExistingApplication1 $body,
    ?string $vCorrelationId = null,
    ?string $contentType = ContentTypeEnum::ENUM_APPLICATIONJSON
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ExistingApplication1`](../../doc/models/existing-application-1.md) | Body, Required | - |
| `vCorrelationId` | `?string` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`?string(ContentTypeEnum)`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

`void`

## Example Usage

```php
$body = ExistingApplication1Builder::init(
    'df8a6d82-3bb4-4f3b-ba18-57a5981ede8e',
    BusinessInfo1Builder::init(
        'The DBA Name',
        'legalName8',
        OwnershipTypeEnum::LLC,
        '5812'
    )
        ->businessEstablishedDate(DateTimeHelper::fromSimpleDate('2000-03-23'))
        ->websiteUrl('www.thefoodplace.com')
        ->numberOfLocation(2)
        ->federalTaxId('123456781')
        ->paymentAcceptanceMethod(
            [
                PaymentAcceptanceMethodEnum::INPERSON,
                PaymentAcceptanceMethodEnum::ONLINESITE
            ]
        )
        ->pciadc(PciadcEnum::NO)
        ->pcidssValidated(PcidssValidatedEnum::NO)
        ->surroundingArea(SurroundingAreaEnum::COMMERCIAL)
        ->productServiceSold('Food')
        ->ownAddYears(2)
        ->seasonal(SeasonalEnum::YES)
        ->activeMonths(
            [
                ActiveMonthEnum::JAN,
                ActiveMonthEnum::FEB,
                ActiveMonthEnum::MAR
            ]
        )
        ->warranty(WarrantyEnum::ENUM_1_YEAR)
        ->returnPolicy(ReturnPolicyEnum::ENUM_30_DAY)
        ->govOwnedMerchantCountry('US')
        ->build(),
    TransactionInfo1Builder::init(
        20000.12,
        82
    )
        ->averageTicket(2.3)
        ->highestTicket(32.41)
        ->currentProcessor('Global Payments')
        ->acceptChargebacks(AcceptChargebacksEnum::NO)
        ->chargebackPercent(0)
        ->returnPercent(10)
        ->cardNotPresentPercent(20)
        ->businessToBusinessPercent(20)
        ->internetTransactionPercent(10)
        ->inPersonTransactionPercent(10)
        ->motoTransactionPercent(10)
        ->annualCreditSalesVolume(123.32)
        ->annualDebitSalesVolume(32.23)
        ->annualAmexVolume(10000)
        ->amexAverageTicket(2.3)
        ->averageNumberofDays(10)
        ->needsProcessingBy(DateTimeHelper::fromSimpleDate('2022-11-01'))
        ->build()
)
    ->leadSource('Activate')
    ->addresses(
        [
            Address1Builder::init(
                AddressTypeEnum::ENUM_MAILING_ADDRESS,
                '1234 W Tester Ave.',
                'City Town',
                State1Enum::CO,
                '80123'
            )
                ->postalCodeExtension('1234')
                ->build(),
            Address1Builder::init(
                AddressTypeEnum::ENUM_PHYSICAL_ADDRESS,
                '1234 W Tester Ave.',
                'City Town',
                State1Enum::CO,
                '80123'
            )
                ->postalCodeExtension('1234')
                ->build()
        ]
    )
    ->routeToSalesRep(false)
    ->build();

$vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$contentType = ContentTypeEnum::ENUM_APPLICATIONJSON;

$initiateBoardingApplicationController->exisitingApplication(
    $body,
    $vCorrelationId,
    $contentType
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# New Application

Use this endpoint to collect the merchant information needed to initiate a new contract.

```php
function newApplication(
    Application $body,
    ?string $vCorrelationId = null,
    ?string $contentType = ContentTypeEnum::ENUM_APPLICATIONJSON
): ApplicationResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Application`](../../doc/models/application.md) | Body, Required | - |
| `vCorrelationId` | `?string` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`?string(ContentTypeEnum)`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

[`ApplicationResponse`](../../doc/models/application-response.md)

## Example Usage

```php
$body = ApplicationBuilder::init(
    BusinessInfo1Builder::init(
        'The DBA Name',
        'legalName8',
        OwnershipTypeEnum::LLC,
        '5812'
    )
        ->businessEstablishedDate(DateTimeHelper::fromSimpleDate('2000-03-23'))
        ->websiteUrl('www.thefoodplace.com')
        ->numberOfLocation(2)
        ->federalTaxId('123456781')
        ->paymentAcceptanceMethod(
            [
                PaymentAcceptanceMethodEnum::INPERSON,
                PaymentAcceptanceMethodEnum::ONLINESITE
            ]
        )
        ->pciadc(PciadcEnum::NO)
        ->pcidssValidated(PcidssValidatedEnum::NO)
        ->surroundingArea(SurroundingAreaEnum::COMMERCIAL)
        ->productServiceSold('Food')
        ->ownAddYears(2)
        ->seasonal(SeasonalEnum::YES)
        ->activeMonths(
            [
                ActiveMonthEnum::JAN,
                ActiveMonthEnum::FEB,
                ActiveMonthEnum::MAR
            ]
        )
        ->warranty(WarrantyEnum::ENUM_1_YEAR)
        ->returnPolicy(ReturnPolicyEnum::ENUM_30_DAY)
        ->govOwnedMerchantCountry('US')
        ->build(),
    TransactionInfo1Builder::init(
        20000.12,
        82
    )
        ->averageTicket(2.3)
        ->highestTicket(32.41)
        ->currentProcessor('Global Payments')
        ->acceptChargebacks(AcceptChargebacksEnum::NO)
        ->chargebackPercent(0)
        ->returnPercent(10)
        ->cardNotPresentPercent(20)
        ->businessToBusinessPercent(20)
        ->internetTransactionPercent(10)
        ->inPersonTransactionPercent(10)
        ->motoTransactionPercent(10)
        ->annualCreditSalesVolume(123.32)
        ->annualDebitSalesVolume(32.23)
        ->annualAmexVolume(10000)
        ->amexAverageTicket(2.3)
        ->averageNumberofDays(10)
        ->needsProcessingBy(DateTimeHelper::fromSimpleDate('2022-11-01'))
        ->build(),
    [
        AuthorizedSigner1Builder::init(
            RoleName1Enum::MERCHANT,
            SigningExperienceEnum::EMAIL,
            '2',
            'Todd',
            'Davis',
            '5131234567',
            'test@gmail.com',
            '123456789',
            DateTimeHelper::fromSimpleDateRequired('2000-03-23'),
            '4355 N Coalwhipe St.',
            'Denver',
            State1Enum::CO,
            '12345'
        )
            ->title('President')
            ->middleInitial('M')
            ->phoneNumberExt('1234')
            ->phoneType(PhoneTypeEnum::MOBILE)
            ->alternatePhone('5131234567')
            ->alternatePhoneType(AlternatePhoneTypeEnum::HOME)
            ->faxNumber('5131234567')
            ->addressLine2('suite 104')
            ->postalCodeExtension('1234')
            ->build()
    ],
    [
        Contact1Builder::init(
            Type4Enum::ENUM_PRIMARY_CONTACT,
            'Todd',
            'Davis',
            '5131234567',
            'test@gmail.com'
        )
            ->title('President')
            ->middleInitial('M')
            ->ssn('123456789')
            ->birthDate(DateTimeHelper::fromSimpleDate('2000-03-23'))
            ->phoneNumberExt('1234')
            ->phoneType(PhoneTypeEnum::MOBILE)
            ->alternatePhone('5131234567')
            ->alternatePhoneType(AlternatePhoneTypeEnum::HOME)
            ->faxNumber('5131234567')
            ->build()
    ],
    [
        Address1Builder::init(
            AddressTypeEnum::ENUM_MAILING_ADDRESS,
            '1234 W Tester Ave.',
            'City Town',
            State1Enum::CO,
            '80123'
        )
            ->postalCodeExtension('1234')
            ->build(),
        Address1Builder::init(
            AddressTypeEnum::ENUM_PHYSICAL_ADDRESS,
            '1234 W Tester Ave.',
            'City Town',
            State1Enum::CO,
            '80123'
        )
            ->postalCodeExtension('1234')
            ->build(),
        Address1Builder::init(
            AddressTypeEnum::ENUM_SHIPPING_ADDRESS,
            '1234 W Tester Ave.',
            'City Town',
            State1Enum::CO,
            '80123'
        )
            ->postalCodeExtension('1234')
            ->build()
    ]
)
    ->clientTrackingId('1341341234132412341')
    ->leadSource('LP Connect API')
    ->build();

$vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$contentType = ContentTypeEnum::ENUM_APPLICATIONJSON;

$result = $initiateBoardingApplicationController->newApplication(
    $body,
    $vCorrelationId,
    $contentType
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

