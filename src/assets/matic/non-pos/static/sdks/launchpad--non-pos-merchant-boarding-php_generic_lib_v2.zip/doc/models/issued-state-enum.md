
# Issued State Enum

Valid state code where ID was issued.

## Enumeration

`IssuedStateEnum`

## Fields

| Name |
|  --- |
| `AK` |
| `AL` |
| `AR` |
| `AS_` |
| `AZ` |
| `CA` |
| `CO` |
| `CT` |
| `DC` |
| `DE` |
| `FL` |
| `FM` |
| `GA` |
| `GU` |
| `HI` |
| `IA` |
| `ID` |
| `IL` |
| `IN` |
| `KS` |
| `KY` |
| `LA` |
| `MA` |
| `MD` |
| `ME` |
| `MH` |
| `MI` |
| `MN` |
| `MO` |
| `MP` |
| `MS` |
| `MT` |
| `NC` |
| `ND` |
| `NE` |
| `NH` |
| `NJ` |
| `NM` |
| `NV` |
| `NY` |
| `OH` |
| `OK` |
| `OR_` |
| `PA` |
| `PR` |
| `PW` |
| `RI` |
| `SC` |
| `SD` |
| `TN` |
| `TX` |
| `UT` |
| `VA` |
| `VI` |
| `VT` |
| `WA` |
| `WI` |
| `WV` |
| `WY` |

## Example

```
CO
```

