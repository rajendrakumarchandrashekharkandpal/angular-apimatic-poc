
# Identification

## Structure

`Identification`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `idType` | [`string(IdTypeEnum)`](../../doc/models/id-type-enum.md) | Required | Type of ID provided by the owner. | getIdType(): string | setIdType(string idType): void |
| `idNumber` | `string` | Required | Owner's ID number.<br>**Constraints**: *Maximum Length*: `40` | getIdNumber(): string | setIdNumber(string idNumber): void |
| `issuedCity` | `?string` | Optional | City in which ID was issued.<br>**Constraints**: *Maximum Length*: `28` | getIssuedCity(): ?string | setIssuedCity(?string issuedCity): void |
| `issuedState` | [`?string(IssuedStateEnum)`](../../doc/models/issued-state-enum.md) | Optional | Valid state code where ID was issued.<br>**Constraints**: *Maximum Length*: `2` | getIssuedState(): ?string | setIssuedState(?string issuedState): void |
| `issuedCountry` | `?string` | Optional | Country where ID was issued.<br>**Constraints**: *Maximum Length*: `2` | getIssuedCountry(): ?string | setIssuedCountry(?string issuedCountry): void |
| `dateIssued` | `?DateTime` | Optional | Date ID was issued (CCYY-MM-DD). | getDateIssued(): ?\DateTime | setDateIssued(?\DateTime dateIssued): void |
| `dateExpires` | `?DateTime` | Optional | Date ID expires (CCYY-MM-DD). | getDateExpires(): ?\DateTime | setDateExpires(?\DateTime dateExpires): void |

## Example (as JSON)

```json
{
  "idType": "PASSPORT",
  "idNumber": "312312341",
  "issuedCity": "City Town",
  "issuedState": "CO",
  "issuedCountry": "US",
  "dateIssued": "1999-01-30",
  "dateExpires": "2020-02-11"
}
```

