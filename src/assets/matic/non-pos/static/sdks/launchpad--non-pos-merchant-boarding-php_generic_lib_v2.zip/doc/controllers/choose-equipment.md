# Choose Equipment

```php
$chooseEquipmentController = $client->getChooseEquipmentController();
```

## Class Name

`ChooseEquipmentController`

## Methods

* [Get Terminal Info](../../doc/controllers/choose-equipment.md#get-terminal-info)
* [Update Terminal](../../doc/controllers/choose-equipment.md#update-terminal)
* [Config Standalone Terminal](../../doc/controllers/choose-equipment.md#config-standalone-terminal)


# Get Terminal Info

Gets the terminal configuration information for a specific partner.

```php
function getTerminalInfo(
    string $externalRefId,
    ?string $vCorrelationId = null,
    ?string $contentType = ContentTypeEnum::ENUM_APPLICATIONJSON,
    ?string $locationId = null,
    ?string $merchantId = null
): EquipmentSetup
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `?string` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`?string(ContentTypeEnum)`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `locationId` | `?string` | Header, Optional | The locationId returned from POST /locations call. |
| `merchantId` | `?string` | Header, Optional | The merchantId returned from POST /merchants call. |

## Response Type

[`EquipmentSetup`](../../doc/models/equipment-setup.md)

## Example Usage

```php
$externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$contentType = ContentTypeEnum::ENUM_APPLICATIONJSON;

$result = $chooseEquipmentController->getTerminalInfo(
    $externalRefId,
    $vCorrelationId,
    $contentType
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Update Terminal

Updates terminal configurations.

```php
function updateTerminal(
    string $externalRefId,
    EquipmentSetup $body,
    ?string $vCorrelationId = null,
    ?string $contentType = ContentTypeEnum::ENUM_APPLICATIONJSON,
    ?string $locationId = null,
    ?string $merchantId = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `body` | [`EquipmentSetup`](../../doc/models/equipment-setup.md) | Body, Required | - |
| `vCorrelationId` | `?string` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`?string(ContentTypeEnum)`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `locationId` | `?string` | Header, Optional | The locationId returned from POST /locations call. |
| `merchantId` | `?string` | Header, Optional | The merchantId returned from POST /merchants call. |

## Response Type

`void`

## Example Usage

```php
$externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$body = EquipmentSetupBuilder::init()
    ->shippingOption(ShippingOptionEnum::ENUM_NEXT_DAY)
    ->terminals(
        [
            TerminalBuilder::init(
                TerminalConfigBuilder::init(
                    '67',
                    187.99,
                    1,
                    '194',
                    'SSL',
                    PaymentMethodEnum::ENUM_PURCHASE_SALE,
                    'Restaurant'
                )
                    ->requestId('41231')
                    ->terminalModel('VAR - Xpient Solutions')
                    ->build(),
                [
                    ProductBuilder::init()
                        ->productId('1')
                        ->productName('Credit')
                        ->build()
                ]
            )->build()
        ]
    )->build();

$chooseEquipmentController->updateTerminal(
    $externalRefId,
    $body
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Config Standalone Terminal

Sets up terminal configurations.

```php
function configStandaloneTerminal(
    string $externalRefId,
    EquipmentSetup $body,
    ?string $vCorrelationId = null,
    ?string $contentType = ContentTypeEnum::ENUM_APPLICATIONJSON,
    ?string $locationId = null,
    ?string $merchantId = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `body` | [`EquipmentSetup`](../../doc/models/equipment-setup.md) | Body, Required | - |
| `vCorrelationId` | `?string` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`?string(ContentTypeEnum)`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `locationId` | `?string` | Header, Optional | The locationId returned from POST /locations call. |
| `merchantId` | `?string` | Header, Optional | The merchantId returned from POST /merchants call. |

## Response Type

`void`

## Example Usage

```php
$externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$body = EquipmentSetupBuilder::init()
    ->shippingOption(ShippingOptionEnum::ENUM_NEXT_DAY)
    ->terminals(
        [
            TerminalBuilder::init(
                TerminalConfigBuilder::init(
                    '67',
                    187.99,
                    1,
                    '194',
                    'SSL',
                    PaymentMethodEnum::ENUM_PURCHASE_SALE,
                    'Restaurant'
                )
                    ->requestId('41231')
                    ->terminalModel('VAR - Xpient Solutions')
                    ->build(),
                [
                    ProductBuilder::init()
                        ->productId('1')
                        ->productName('Credit')
                        ->build()
                ]
            )->build()
        ]
    )->build();

$chooseEquipmentController->configStandaloneTerminal(
    $externalRefId,
    $body
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

