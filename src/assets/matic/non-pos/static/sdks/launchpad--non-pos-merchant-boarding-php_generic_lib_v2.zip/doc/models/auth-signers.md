
# Auth Signers

## Structure

`AuthSigners`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `firstName` | `?string` | Optional | First name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `15`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` | getFirstName(): ?string | setFirstName(?string firstName): void |
| `middleInitial` | `?string` | Optional | Middle initial.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` | getMiddleInitial(): ?string | setMiddleInitial(?string middleInitial): void |
| `lastName` | `?string` | Optional | Last name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `25`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` | getLastName(): ?string | setLastName(?string lastName): void |
| `email` | `?string` | Optional | Email address of the contact. Must have @ and a .<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64`, *Pattern*: `\b[A-Za-z0-9._%+-]+@(?:[A-Za-z0-9-]+\.)+[A-Za-z0-9]{2,}` | getEmail(): ?string | setEmail(?string email): void |
| `status` | `?string` | Optional | Status of the signer | getStatus(): ?string | setStatus(?string status): void |
| `lastUpdated` | `?DateTime` | Optional | Date contract was last updated | getLastUpdated(): ?\DateTime | setLastUpdated(?\DateTime lastUpdated): void |
| `dateSubmitted` | `?DateTime` | Optional | Date contract was last updated | getDateSubmitted(): ?\DateTime | setDateSubmitted(?\DateTime dateSubmitted): void |
| `dateSent` | `?DateTime` | Optional | Date contract was sent | getDateSent(): ?\DateTime | setDateSent(?\DateTime dateSent): void |
| `dateDelivered` | `?DateTime` | Optional | Date contract was delivered | getDateDelivered(): ?\DateTime | setDateDelivered(?\DateTime dateDelivered): void |
| `dateSigned` | `?DateTime` | Optional | Date contract was signed | getDateSigned(): ?\DateTime | setDateSigned(?\DateTime dateSigned): void |
| `signerRoleName` | `?string` | Optional | Role of the signer | getSignerRoleName(): ?string | setSignerRoleName(?string signerRoleName): void |
| `signerExperience` | `?string` | Optional | Method of sign | getSignerExperience(): ?string | setSignerExperience(?string signerExperience): void |

## Example (as JSON)

```json
{
  "firstName": "Todd",
  "middleInitial": "M",
  "lastName": "Davis",
  "email": "test@gmail.com",
  "status": "sent",
  "signerRoleName": "Merchant",
  "signerExperience": "wet"
}
```

