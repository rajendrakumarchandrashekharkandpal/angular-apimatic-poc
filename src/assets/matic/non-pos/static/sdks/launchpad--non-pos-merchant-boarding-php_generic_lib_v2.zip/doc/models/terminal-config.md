
# Terminal Config

## Structure

`TerminalConfig`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `requestId` | `?string` | Optional | Partner assigned unique request ID for terminal setup. | getRequestId(): ?string | setRequestId(?string requestId): void |
| `terminalId` | `string` | Required | Terminal ID number. | getTerminalId(): string | setTerminalId(string terminalId): void |
| `terminalModel` | `?string` | Optional | The model name of the terminal in use. | getTerminalModel(): ?string | setTerminalModel(?string terminalModel): void |
| `price` | `float` | Required | Terminal price | getPrice(): float | setPrice(float price): void |
| `quantity` | `int` | Required | - | getQuantity(): int | setQuantity(int quantity): void |
| `logicalApplicationId` | `string` | Required | Logical application ID. | getLogicalApplicationId(): string | setLogicalApplicationId(string logicalApplicationId): void |
| `accessMethod` | `string` | Required | Methods of terminal access. | getAccessMethod(): string | setAccessMethod(string accessMethod): void |
| `paymentMethod` | [`string(PaymentMethodEnum)`](../../doc/models/payment-method-enum.md) | Required | Payment method for the selected terminal. | getPaymentMethod(): string | setPaymentMethod(string paymentMethod): void |
| `environmentName` | `string` | Required | Environment name | getEnvironmentName(): string | setEnvironmentName(string environmentName): void |
| `isVar` | `?bool` | Optional | The value added reseller. Default value is false.<br>**Default**: `false` | getIsVar(): ?bool | setIsVar(?bool isVar): void |
| `emvCapable` | `?bool` | Optional | Is it EMV capabale?<br>**Default**: `false` | getEmvCapable(): ?bool | setEmvCapable(?bool emvCapable): void |
| `leaseId` | `?string` | Optional | Lease ID. Required when PaymentMethod is selected as lease. | getLeaseId(): ?string | setLeaseId(?string leaseId): void |
| `leaseTermLength` | [`?string(LeaseTermLengthEnum)`](../../doc/models/lease-term-length-enum.md) | Optional | Lease term for the peripheral | getLeaseTermLength(): ?string | setLeaseTermLength(?string leaseTermLength): void |
| `terminalSequenceNumber` | `?string` | Optional | Terminal sequence number. If not sent, the API will autogenerate a number.<br>**Constraints**: *Pattern*: `^[0-9]` | getTerminalSequenceNumber(): ?string | setTerminalSequenceNumber(?string terminalSequenceNumber): void |
| `specialCustomizations` | `?string` | Optional | Any customization request for a terminal configuration.<br>**Constraints**: *Maximum Length*: `255` | getSpecialCustomizations(): ?string | setSpecialCustomizations(?string specialCustomizations): void |

## Example (as JSON)

```json
{
  "requestId": "41231",
  "terminalId": "iCT220",
  "terminalModel": "Ingenico iCT220 CTLS 3.X Dial",
  "price": 187.99,
  "quantity": 1,
  "logicalApplicationId": "MONE510",
  "accessMethod": "SSL",
  "paymentMethod": "PURCHASE / SALE",
  "environmentName": "Retail",
  "isVar": false,
  "emvCapable": true,
  "leaseId": "12",
  "leaseTermLength": "24",
  "terminalSequenceNumber": "14",
  "specialCustomizations": "Mulitple merchant setup is Yes"
}
```

