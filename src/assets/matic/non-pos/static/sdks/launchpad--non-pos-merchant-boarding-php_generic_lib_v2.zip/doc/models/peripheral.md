
# Peripheral

## Structure

`Peripheral`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `peripheralId` | `?string` | Optional | Peripheral IDs are internally populated. | getPeripheralId(): ?string | setPeripheralId(?string peripheralId): void |
| `peripheralType` | `?string` | Optional | Peripheral type | getPeripheralType(): ?string | setPeripheralType(?string peripheralType): void |
| `model` | `?string` | Optional | - | getModel(): ?string | setModel(?string model): void |
| `leaseId` | `?string` | Optional | Lease ID for the peripheral | getLeaseId(): ?string | setLeaseId(?string leaseId): void |
| `leaseTermLength` | [`?string(LeaseTermLengthEnum)`](../../doc/models/lease-term-length-enum.md) | Optional | Lease term for the peripheral | getLeaseTermLength(): ?string | setLeaseTermLength(?string leaseTermLength): void |
| `paymentMethod` | [`?string(PaymentMethod1Enum)`](../../doc/models/payment-method-1-enum.md) | Optional | Payment method for the selected peripheral. | getPaymentMethod(): ?string | setPaymentMethod(?string paymentMethod): void |
| `amount` | `?string` | Optional | "Payment Amount for the peripheral. Valid values are 0.00<br><br>- 9999999999.99."<br>**Constraints**: *Pattern*: `(^\d{1,10}([.]\d{1,2})?)$` | getAmount(): ?string | setAmount(?string amount): void |
| `paymentConfirmationNumber` | `?string` | Optional | Payment confirmation number for the peripheral.<br>**Constraints**: *Pattern*: `[0-9a-zA-Z]{6}\|` | getPaymentConfirmationNumber(): ?string | setPaymentConfirmationNumber(?string paymentConfirmationNumber): void |

## Example (as JSON)

```json
{
  "peripheralId": "231",
  "peripheralType": "PPAD",
  "model": "Magtek Check Reader",
  "leaseId": "18",
  "leaseTermLength": "24",
  "paymentMethod": "PURCHASE / SALE",
  "amount": "220.21",
  "paymentConfirmationNumber": "123456"
}
```

