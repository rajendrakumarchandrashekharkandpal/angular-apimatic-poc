# Check Application Status

```php
$checkApplicationStatusController = $client->getCheckApplicationStatusController();
```

## Class Name

`CheckApplicationStatusController`

## Methods

* [Get Application Status](../../doc/controllers/check-application-status.md#get-application-status)
* [Fetch Application Status History](../../doc/controllers/check-application-status.md#fetch-application-status-history)
* [Fetch Signer Status](../../doc/controllers/check-application-status.md#fetch-signer-status)


# Get Application Status

Retrieves the status of a contract when passed with an externalRefID. Both the externalRefID and authorization header are required.

```php
function getApplicationStatus(string $externalRefId, ?string $vCorrelationId = null): ApplicationStatus
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `?string` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`ApplicationStatus`](../../doc/models/application-status.md)

## Example Usage

```php
$externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$result = $checkApplicationStatusController->getApplicationStatus(
    $externalRefId,
    $vCorrelationId
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Fetch Application Status History

Use this endpoint to get a application's status history.

```php
function fetchApplicationStatusHistory(
    string $externalRefId,
    ?string $vCorrelationId = null
): StatusHistoryResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `?string` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`StatusHistoryResponse`](../../doc/models/status-history-response.md)

## Example Usage

```php
$externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$result = $checkApplicationStatusController->fetchApplicationStatusHistory(
    $externalRefId,
    $vCorrelationId
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Fetch Signer Status

Use this endpoint to get signer status

```php
function fetchSignerStatus(
    string $externalRefId,
    ?string $vCorrelationId = null,
    ?string $contentType = ContentTypeEnum::ENUM_APPLICATIONJSON
): SignerStatus
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `?string` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`?string(ContentTypeEnum)`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

[`SignerStatus`](../../doc/models/signer-status.md)

## Example Usage

```php
$externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$contentType = ContentTypeEnum::ENUM_APPLICATIONJSON;

$result = $checkApplicationStatusController->fetchSignerStatus(
    $externalRefId,
    $vCorrelationId,
    $contentType
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

