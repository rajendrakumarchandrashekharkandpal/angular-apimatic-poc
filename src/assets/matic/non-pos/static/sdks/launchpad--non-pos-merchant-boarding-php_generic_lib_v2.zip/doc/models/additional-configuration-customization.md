
# Additional Configuration Customization

## Structure

`AdditionalConfigurationCustomization`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `customizationId` | `?string` | Optional | Customization Id is internally populated from a master list. | getCustomizationId(): ?string | setCustomizationId(?string customizationId): void |
| `customizationType` | `?string` | Optional | type of customization | getCustomizationType(): ?string | setCustomizationType(?string customizationType): void |
| `useProductMatrix` | `?string` | Optional | Whether or not used in product matrix | getUseProductMatrix(): ?string | setUseProductMatrix(?string useProductMatrix): void |
| `productId` | `?string` | Optional | unique ID for the product | getProductId(): ?string | setProductId(?string productId): void |
| `code` | `?string` | Optional | product code | getCode(): ?string | setCode(?string code): void |
| `customizationCodeDetails` | [`?(CustomizationCodeDetails[])`](../../doc/models/customization-code-details.md) | Optional | - | getCustomizationCodeDetails(): ?array | setCustomizationCodeDetails(?array customizationCodeDetails): void |
| `customizationValue` | `?string` | Optional | Actual Customization Value | getCustomizationValue(): ?string | setCustomizationValue(?string customizationValue): void |
| `customizationFieldLength` | `?string` | Optional | Length of the customization value | getCustomizationFieldLength(): ?string | setCustomizationFieldLength(?string customizationFieldLength): void |
| `customizationDecimalPlace` | `?string` | Optional | Number of decimal places | getCustomizationDecimalPlace(): ?string | setCustomizationDecimalPlace(?string customizationDecimalPlace): void |
| `customizationMinValue` | `?string` | Optional | Minimum Value. Only applicable if the customization value is a number | getCustomizationMinValue(): ?string | setCustomizationMinValue(?string customizationMinValue): void |
| `customizationMaxValue` | `?string` | Optional | Maximum Value. Only applicable if the customization value is a number | getCustomizationMaxValue(): ?string | setCustomizationMaxValue(?string customizationMaxValue): void |
| `charactersAllowed` | `?string` | Optional | All characters allowed for customization. Only applicable if the customization value is a string. | getCharactersAllowed(): ?string | setCharactersAllowed(?string charactersAllowed): void |
| `rule` | `?string` | Optional | customization rule | getRule(): ?string | setRule(?string rule): void |
| `regex` | `?string` | Optional | Regular expression to validate the customization value | getRegex(): ?string | setRegex(?string regex): void |
| `multiMerchantFlag` | `?bool` | Optional | Applicable in a multiple merchant situation<br>**Default**: `false` | getMultiMerchantFlag(): ?bool | setMultiMerchantFlag(?bool multiMerchantFlag): void |
| `shortDescription` | `?string` | Optional | Description of the customization | getShortDescription(): ?string | setShortDescription(?string shortDescription): void |
| `longDescription` | `?string` | Optional | Verbose description of the customiztion | getLongDescription(): ?string | setLongDescription(?string longDescription): void |

## Example (as JSON)

```json
{
  "customizationId": "1",
  "customizationType": "time",
  "useProductMatrix": "N",
  "productId": "12",
  "code": "CST01",
  "customizationValue": "H",
  "customizationFieldLength": "1",
  "customizationDecimalPlace": "0",
  "customizationMinValue": "0",
  "customizationMaxValue": "6",
  "charactersAllowed": "abcdefghijklmnopqrstuvwxyz",
  "regex": "^[a-z]{1}",
  "multiMerchantFlag": false,
  "shortDescription": "CVV_PROMPTING",
  "longDescription": "CVV_PROMPTING"
}
```

