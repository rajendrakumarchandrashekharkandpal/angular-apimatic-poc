# Submit Application

```php
$submitApplicationController = $client->getSubmitApplicationController();
```

## Class Name

`SubmitApplicationController`

## Methods

* [Validate Board](../../doc/controllers/submit-application.md#validate-board)
* [Inititate Board](../../doc/controllers/submit-application.md#inititate-board)


# Validate Board

Begins the merchant validation process before boarding after all necessary information has been submitted to the API. Please see the reference guide for specific boarding requirements.

```php
function validateBoard(
    string $externalRefId,
    ?string $vCorrelationId = null,
    ?string $contentType = ContentTypeEnum::ENUM_APPLICATIONJSON
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `?string` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`?string(ContentTypeEnum)`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

`void`

## Example Usage

```php
$externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$contentType = ContentTypeEnum::ENUM_APPLICATIONJSON;

$submitApplicationController->validateBoard(
    $externalRefId,
    $vCorrelationId,
    $contentType
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Inititate Board

Begins the merchant boarding process after all necessary information has been submitted to the API. Please see the reference guide for specific boarding requirements.

```php
function inititateBoard(
    string $externalRefId,
    ?string $vCorrelationId = null,
    ?string $contentType = ContentTypeEnum::ENUM_APPLICATIONJSON,
    ?string $threatmetrixId = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `?string` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`?string(ContentTypeEnum)`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `threatmetrixId` | `?string` | Header, Optional | A unique session id |

## Response Type

`void`

## Example Usage

```php
$externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

$contentType = ContentTypeEnum::ENUM_APPLICATIONJSON;

$submitApplicationController->inititateBoard(
    $externalRefId,
    $vCorrelationId,
    $contentType
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

