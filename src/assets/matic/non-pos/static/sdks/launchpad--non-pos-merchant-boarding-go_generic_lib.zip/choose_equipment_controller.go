package launchpadnonposmerchantboarding

import (
    "context"
    "github.com/apimatic/go-core-runtime/https"
    "github.com/apimatic/go-core-runtime/utilities"
    "github.com/google/uuid"
    "launchpadnonposmerchantboarding/errors"
    "launchpadnonposmerchantboarding/models"
    "net/http"
)

// ChooseEquipmentController represents a controller struct.
type ChooseEquipmentController struct {
    baseController
}

// NewChooseEquipmentController creates a new instance of ChooseEquipmentController.
// It takes a baseController as a parameter and returns a pointer to the ChooseEquipmentController.
func NewChooseEquipmentController(baseController baseController) *ChooseEquipmentController {
    chooseEquipmentController := ChooseEquipmentController{baseController: baseController}
    return &chooseEquipmentController
}

// GetTerminalInfo takes context, externalRefId, vCorrelationId, contentType, locationId, merchantId as parameters and
// returns an models.ApiResponse with models.EquipmentSetup data and
// an error if there was an issue with the request or response.
// Gets the terminal configuration information for a specific partner.
func (c *ChooseEquipmentController) GetTerminalInfo(
    ctx context.Context,
    externalRefId uuid.UUID,
    vCorrelationId *uuid.UUID,
    contentType *models.ContentTypeEnum,
    locationId *string,
    merchantId *string) (
    models.ApiResponse[models.EquipmentSetup],
    error) {
    req := c.prepareRequest(ctx, "GET", "/equipment/terminal-var")
    req.Authenticate(NewAuth("api_key"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "0": {Message: "Default errors", Unmarshaller: errors.NewErrorResponse},
    })
    req.Header("externalRefId", externalRefId)
    if vCorrelationId != nil {
        req.Header("v-correlation-id", *vCorrelationId)
    }
    if contentType != nil {
        req.Header("Content-Type", *contentType)
    }
    if locationId != nil {
        req.Header("locationId", *locationId)
    }
    if merchantId != nil {
        req.Header("merchantId", *merchantId)
    }
    var result models.EquipmentSetup
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[models.EquipmentSetup](decoder)
    return models.NewApiResponse(result, resp), err
}

// UpdateTerminal takes context, externalRefId, body, vCorrelationId, contentType, locationId, merchantId as parameters and
// returns an models.ApiResponse with  data and
// an error if there was an issue with the request or response.
// Updates terminal configurations.
func (c *ChooseEquipmentController) UpdateTerminal(
    ctx context.Context,
    externalRefId uuid.UUID,
    body models.EquipmentSetup,
    vCorrelationId *uuid.UUID,
    contentType *models.ContentTypeEnum,
    locationId *string,
    merchantId *string) (
    *http.Response,
    error) {
    req := c.prepareRequest(ctx, "PUT", "/equipment/terminal-var")
    req.Authenticate(NewAuth("api_key"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "0": {Message: "Default errors", Unmarshaller: errors.NewErrorResponse},
    })
    req.Header("externalRefId", externalRefId)
    if vCorrelationId != nil {
        req.Header("v-correlation-id", *vCorrelationId)
    }
    if contentType != nil {
        req.Header("Content-Type", *contentType)
    }
    if locationId != nil {
        req.Header("locationId", *locationId)
    }
    if merchantId != nil {
        req.Header("merchantId", *merchantId)
    }
    req.Json(&body)
    context, err := req.Call()
    if err != nil {
        return context.Response, err
    }
    return context.Response, err
}

// ConfigStandaloneTerminal takes context, externalRefId, body, vCorrelationId, contentType, locationId, merchantId as parameters and
// returns an models.ApiResponse with  data and
// an error if there was an issue with the request or response.
// Sets up terminal configurations.
func (c *ChooseEquipmentController) ConfigStandaloneTerminal(
    ctx context.Context,
    externalRefId uuid.UUID,
    body models.EquipmentSetup,
    vCorrelationId *uuid.UUID,
    contentType *models.ContentTypeEnum,
    locationId *string,
    merchantId *string) (
    *http.Response,
    error) {
    req := c.prepareRequest(ctx, "POST", "/equipment/terminal-var")
    req.Authenticate(NewAuth("api_key"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "0": {Message: "Default errors", Unmarshaller: errors.NewErrorResponse},
    })
    req.Header("externalRefId", externalRefId)
    if vCorrelationId != nil {
        req.Header("v-correlation-id", *vCorrelationId)
    }
    if contentType != nil {
        req.Header("Content-Type", *contentType)
    }
    if locationId != nil {
        req.Header("locationId", *locationId)
    }
    if merchantId != nil {
        req.Header("merchantId", *merchantId)
    }
    req.Json(&body)
    context, err := req.Call()
    if err != nil {
        return context.Response, err
    }
    return context.Response, err
}
