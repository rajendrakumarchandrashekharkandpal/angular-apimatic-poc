
# Shipping Option Enum

The speed you would like the equipment to be shipped.

## Enumeration

`ShippingOptionEnum`

## Fields

| Name |
|  --- |
| `GROUND` |
| `ENUMNEXTDAY` |
| `ENUM2NDDAY` |

## Example

```
next day
```

