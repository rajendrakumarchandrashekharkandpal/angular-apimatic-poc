
# Gateway

A gateway is a hosted payment processing application provided by a service provider and accessed through an internet connection.

## Structure

`Gateway`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `GatewayId` | `*string` | Optional | Internally-generated gateway ID. |
| `GatewayName` | `*string` | Optional | - |
| `Notes` | `*string` | Optional | Add any custom notes here. |

## Example (as JSON)

```json
{
  "gatewayId": "15",
  "gatewayName": "Paymetric Gateway",
  "notes": "Paymetric Gateway v3"
}
```

