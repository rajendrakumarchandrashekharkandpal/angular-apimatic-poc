
# Contract Status Enum

## Enumeration

`ContractStatusEnum`

## Fields

| Name |
|  --- |
| `COMPLETE` |
| `ENUMINPROGRESS` |
| `ERROR` |
| `PENDING` |

