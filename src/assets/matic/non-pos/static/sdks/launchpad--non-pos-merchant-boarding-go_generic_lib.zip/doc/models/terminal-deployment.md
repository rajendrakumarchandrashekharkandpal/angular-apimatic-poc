
# Terminal Deployment

## Structure

`TerminalDeployment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `EquipmentUpdateDeploy` | [`models.EquipmentUpdateDeployEnum`](../../doc/models/equipment-update-deploy-enum.md) | Required | - |
| `TerminalBuildFlag` | `*bool` | Optional | - |
| `FrontEndBuildFlag` | `*bool` | Optional | - |
| `SicMerchantFlag` | `*bool` | Optional | - |
| `SpecialInstructions` | `*string` | Optional | Special instructions for terminal deployment.<br>**Constraints**: *Maximum Length*: `255` |

## Example (as JSON)

```json
{
  "equipmentUpdateDeploy": "M",
  "terminalBuildFlag": true,
  "frontEndBuildFlag": true,
  "sicMerchantFlag": false,
  "specialInstructions": "Retail - H52460A (SP)"
}
```

