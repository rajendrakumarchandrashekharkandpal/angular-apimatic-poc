
# Additional Configurations Response

## Structure

`AdditionalConfigurationsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Customizations` | [`[]models.AdditionalConfigurationCustomization`](../../doc/models/additional-configuration-customization.md) | Optional | - |
| `Peripherals` | [`[]models.AdditionalConfigurationPeripheral`](../../doc/models/additional-configuration-peripheral.md) | Optional | - |

## Example (as JSON)

```json
{
  "customizations": [
    {
      "customizationId": "customizationId0",
      "customizationType": "customizationType8",
      "useProductMatrix": "useProductMatrix8",
      "productId": "productId4",
      "code": "code0"
    },
    {
      "customizationId": "customizationId0",
      "customizationType": "customizationType8",
      "useProductMatrix": "useProductMatrix8",
      "productId": "productId4",
      "code": "code0"
    },
    {
      "customizationId": "customizationId0",
      "customizationType": "customizationType8",
      "useProductMatrix": "useProductMatrix8",
      "productId": "productId4",
      "code": "code0"
    }
  ],
  "peripherals": [
    {
      "peripheralId": "peripheralId2",
      "model": "model4",
      "shortDescription": "shortDescription8",
      "longDescription": "longDescription6",
      "isEMVCertified": false
    },
    {
      "peripheralId": "peripheralId2",
      "model": "model4",
      "shortDescription": "shortDescription8",
      "longDescription": "longDescription6",
      "isEMVCertified": false
    }
  ]
}
```

