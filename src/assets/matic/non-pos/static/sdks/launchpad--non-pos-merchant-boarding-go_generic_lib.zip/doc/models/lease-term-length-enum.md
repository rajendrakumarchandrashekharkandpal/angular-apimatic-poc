
# Lease Term Length Enum

Lease term for the peripheral

## Enumeration

`LeaseTermLengthEnum`

## Fields

| Name |
|  --- |
| `ENUM24` |
| `ENUM36` |
| `ENUM48` |
| `ENUM60` |

## Example

```
24
```

