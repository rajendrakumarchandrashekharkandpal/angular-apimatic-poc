
# Type 3 Enum

## Enumeration

`Type3Enum`

## Fields

| Name |
|  --- |
| `ENUMGUARANTOR1CONTACT` |
| `ENUMGUARANTOR2CONTACT` |
| `ENUMGUARANTOR3CONTACT` |
| `ENUMGUARANTOR4CONTACT` |

## Example

```
Guarantor 1 Contact
```

