
# Product

## Structure

`Product`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductId` | `*string` | Optional | Product ID is populated internally. |
| `ProductName` | `*string` | Optional | Payment method associated with the internally-populated ID. |

## Example (as JSON)

```json
{
  "productId": "1",
  "productName": "Debit"
}
```

