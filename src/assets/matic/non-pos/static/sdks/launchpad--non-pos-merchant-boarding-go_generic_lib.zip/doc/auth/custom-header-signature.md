
# Custom Header Signature



Documentation for accessing and setting credentials for api_key.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| Authorization | `string` | `License format is WORLDPAY license='xxxx'` | `WithAuthorization` | `Authorization` |



**Note:** Required auth credentials can be set using `WithCustomHeaderAuthenticationCredentials()` by providing a credentials instance with `NewCustomHeaderAuthenticationCredentials()` in the configuration initialization and accessed using the `CustomHeaderAuthenticationCredentials()` method in the configuration instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```go
client := launchpadnonposmerchantboarding.NewClient(
    launchpadnonposmerchantboarding.CreateConfiguration(
        launchpadnonposmerchantboarding.WithCustomHeaderAuthenticationCredentials(
            launchpadnonposmerchantboarding.NewCustomHeaderAuthenticationCredentials("Authorization"),
        ),
    ),
)
```


