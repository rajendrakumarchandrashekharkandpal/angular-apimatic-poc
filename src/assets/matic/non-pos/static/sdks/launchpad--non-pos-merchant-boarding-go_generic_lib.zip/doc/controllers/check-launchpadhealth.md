# Check Launchpadhealth

```go
checkLaunchpadhealthController := client.CheckLaunchpadhealthController()
```

## Class Name

`CheckLaunchpadhealthController`


# Gethealth

Checks the the health of Launchpad and its dependent down streams systems like CPQ, Sales Force, XAA and Jigsaw at regular intervals to check the system is up or down.

```go
Gethealth(
    ctx context.Context,
    vCorrelationId *uuid.UUID) (
    models.ApiResponse[models.InlineResponse2001],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vCorrelationId` | `*uuid.UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`models.InlineResponse2001`](../../doc/models/inline-response-2001.md)

## Example Usage

```go
ctx := context.Background()
vCorrelationId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")

apiResponse, err := checkLaunchpadHealthController.Gethealth(ctx, &vCorrelationId)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

