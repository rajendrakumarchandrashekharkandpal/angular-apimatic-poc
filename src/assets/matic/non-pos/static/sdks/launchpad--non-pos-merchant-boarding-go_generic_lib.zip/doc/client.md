
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `environment` | `Environment` | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| `httpConfiguration` | [`HttpConfiguration`](http-configuration.md) | Configurable http client options like timeout and retries. |
| `customHeaderAuthenticationCredentials` | [`CustomHeaderAuthenticationCredentials`](auth/custom-header-signature.md) | The Credentials Setter for Custom Header Signature |

The API client can be initialized as follows:

```go
client := launchpadnonposmerchantboarding.NewClient(
    launchpadnonposmerchantboarding.CreateConfiguration(
        launchpadnonposmerchantboarding.WithHttpConfiguration(
            launchpadnonposmerchantboarding.CreateHttpConfiguration(
                launchpadnonposmerchantboarding.WithTimeout(0),
            ),
        ),
        launchpadnonposmerchantboarding.WithEnvironment(launchpadnonposmerchantboarding.PRODUCTION),
        launchpadnonposmerchantboarding.WithCustomHeaderAuthenticationCredentials(
            launchpadnonposmerchantboarding.NewCustomHeaderAuthenticationCredentials("Authorization"),
        ),
    ),
)
```

## Launchpad: Non-POS Merchant Boarding Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| initiateBoardingApplication | Gets InitiateBoardingApplicationController |
| equipmentLookup | Gets EquipmentLookupController |
| chooseEquipment | Gets ChooseEquipmentController |
| submitApplication | Gets SubmitApplicationController |
| checkApplicationStatus | Gets CheckApplicationStatusController |
| reviewAndSignContract | Gets ReviewAndSignContractController |
| checkLaunchpadHealth | Gets CheckLaunchpadHealthController |

