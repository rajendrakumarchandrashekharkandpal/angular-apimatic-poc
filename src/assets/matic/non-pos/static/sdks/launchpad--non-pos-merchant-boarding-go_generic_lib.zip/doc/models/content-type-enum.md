
# Content Type Enum

## Enumeration

`ContentTypeEnum`

## Fields

| Name |
|  --- |
| `ENUMAPPLICATIONJSON` |

