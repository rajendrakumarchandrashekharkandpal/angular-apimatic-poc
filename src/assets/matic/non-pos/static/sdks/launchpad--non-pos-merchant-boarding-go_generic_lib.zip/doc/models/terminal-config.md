
# Terminal Config

## Structure

`TerminalConfig`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RequestId` | `*string` | Optional | Partner assigned unique request ID for terminal setup. |
| `TerminalId` | `string` | Required | Terminal ID number. |
| `TerminalModel` | `*string` | Optional | The model name of the terminal in use. |
| `Price` | `float64` | Required | Terminal price |
| `Quantity` | `int` | Required | - |
| `LogicalApplicationId` | `string` | Required | Logical application ID. |
| `AccessMethod` | `string` | Required | Methods of terminal access. |
| `PaymentMethod` | [`models.PaymentMethodEnum`](../../doc/models/payment-method-enum.md) | Required | Payment method for the selected terminal. |
| `EnvironmentName` | `string` | Required | Environment name |
| `IsVar` | `*bool` | Optional | The value added reseller. Default value is false.<br>**Default**: `false` |
| `EmvCapable` | `*bool` | Optional | Is it EMV capabale?<br>**Default**: `false` |
| `LeaseId` | `*string` | Optional | Lease ID. Required when PaymentMethod is selected as lease. |
| `LeaseTermLength` | [`*models.LeaseTermLengthEnum`](../../doc/models/lease-term-length-enum.md) | Optional | Lease term for the peripheral |
| `TerminalSequenceNumber` | `*string` | Optional | Terminal sequence number. If not sent, the API will autogenerate a number.<br>**Constraints**: *Pattern*: `^[0-9]` |
| `SpecialCustomizations` | `*string` | Optional | Any customization request for a terminal configuration.<br>**Constraints**: *Maximum Length*: `255` |

## Example (as JSON)

```json
{
  "requestId": "41231",
  "terminalId": "iCT220",
  "terminalModel": "Ingenico iCT220 CTLS 3.X Dial",
  "price": 187.99,
  "quantity": 1,
  "logicalApplicationId": "MONE510",
  "accessMethod": "SSL",
  "paymentMethod": "PURCHASE / SALE",
  "environmentName": "Retail",
  "isVar": false,
  "emvCapable": true,
  "leaseId": "12",
  "leaseTermLength": "24",
  "terminalSequenceNumber": "14",
  "specialCustomizations": "Mulitple merchant setup is Yes"
}
```

