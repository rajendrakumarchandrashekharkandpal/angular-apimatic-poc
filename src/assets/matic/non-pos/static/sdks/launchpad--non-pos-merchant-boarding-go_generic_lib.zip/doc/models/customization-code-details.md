
# Customization Code Details

## Structure

`CustomizationCodeDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Value` | `*string` | Optional | customization code |
| `ShortDescription` | `*string` | Optional | short description of the customization code |
| `LongDescription` | `*string` | Optional | long description of the customization code |

## Example (as JSON)

```json
{
  "value": "H",
  "shortDescription": "Host Auto Close",
  "longDescription": "Host Auto Close"
}
```

