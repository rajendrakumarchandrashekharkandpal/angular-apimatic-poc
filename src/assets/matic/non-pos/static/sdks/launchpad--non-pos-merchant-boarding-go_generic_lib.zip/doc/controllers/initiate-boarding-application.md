# Initiate Boarding Application

```go
initiateBoardingApplicationController := client.InitiateBoardingApplicationController()
```

## Class Name

`InitiateBoardingApplicationController`

## Methods

* [Fetch Application](../../doc/controllers/initiate-boarding-application.md#fetch-application)
* [Exisiting Application](../../doc/controllers/initiate-boarding-application.md#exisiting-application)
* [New Application](../../doc/controllers/initiate-boarding-application.md#new-application)


# Fetch Application

Retrieves existing application data.

```go
FetchApplication(
    ctx context.Context,
    externalRefId uuid.UUID,
    vCorrelationId *uuid.UUID) (
    models.ApiResponse[models.ExistingApplication],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `uuid.UUID` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `*uuid.UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`models.ExistingApplication`](../../doc/models/existing-application.md)

## Example Usage

```go
ctx := context.Background()
externalRefId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")
vCorrelationId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")

apiResponse, err := initiateBoardingApplicationController.FetchApplication(ctx, externalRefId, &vCorrelationId)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Exisiting Application

This endpoint allows merchants to update an existing application with new information.

```go
ExisitingApplication(
    ctx context.Context,
    body models.ExistingApplication1,
    vCorrelationId *uuid.UUID,
    contentType *models.ContentTypeEnum) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.ExistingApplication1`](../../doc/models/existing-application-1.md) | Body, Required | - |
| `vCorrelationId` | `*uuid.UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`*models.ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

``

## Example Usage

```go
ctx := context.Background()

bodyBusinessInfoBusinessEstablishedDate, err := time.Parse(models.DEFAULT_DATE, "2000-03-23")
if err != nil {
    log.Fatalln(err)
}
bodyBusinessInfo := models.BusinessInfo1{
    DbaName:                 "The DBA Name",
    LegalName:               "legalName8",
    OwnershipType:           models.OwnershipTypeEnum("LLC"),
    MccCode:                 "5812",
    WebsiteUrl:              models.ToPointer("www.thefoodplace.com"),
    NumberOfLocation:        models.ToPointer(2),
    FederalTaxId:            models.ToPointer("123456781"),
    PaymentAcceptanceMethod: []models.PaymentAcceptanceMethodEnum{models.PaymentAcceptanceMethodEnum("inPerson"), models.PaymentAcceptanceMethodEnum("onlineSite")},
    Pciadc:                  models.ToPointer(models.PciadcEnum("No")),
    PcidssValidated:         models.ToPointer(models.PcidssValidatedEnum("No")),
    SurroundingArea:         models.ToPointer(models.SurroundingAreaEnum("Commercial")),
    ProductServiceSold:      models.ToPointer("Food"),
    OwnAddYears:             models.ToPointer(2),
    Seasonal:                models.ToPointer(models.SeasonalEnum("Yes")),
    ActiveMonths:            []models.ActiveMonthEnum{models.ActiveMonthEnum("Jan"), models.ActiveMonthEnum("Feb"), models.ActiveMonthEnum("Mar")},
    Warranty:                models.ToPointer(models.WarrantyEnum("1 YEAR")),
    ReturnPolicy:            models.ToPointer(models.ReturnPolicyEnum("30 Day")),
    GovOwnedMerchantCountry: models.ToPointer("US"),
    BusinessEstablishedDate: models.ToPointer(bodyBusinessInfoBusinessEstablishedDate),
}

bodyTransactionInfoNeedsProcessingBy, err := time.Parse(models.DEFAULT_DATE, "2022-11-01")
if err != nil {
    log.Fatalln(err)
}
bodyTransactionInfo := models.TransactionInfo1{
    AnnualSalesVolume:               float64(20000.12),
    PercentRetailSwipedTransactions: 82,
    AverageTicket:                   models.ToPointer(float64(2.3)),
    HighestTicket:                   models.ToPointer(float64(32.41)),
    CurrentProcessor:                models.ToPointer("Global Payments"),
    AcceptChargebacks:               models.ToPointer(models.AcceptChargebacksEnum("No")),
    ChargebackPercent:               models.ToPointer(0),
    ReturnPercent:                   models.ToPointer(10),
    CardNotPresentPercent:           models.ToPointer(20),
    BusinessToBusinessPercent:       models.ToPointer(20),
    InternetTransactionPercent:      models.ToPointer(10),
    InPersonTransactionPercent:      models.ToPointer(10),
    MotoTransactionPercent:          models.ToPointer(10),
    AnnualCreditSalesVolume:         models.ToPointer(float64(123.32)),
    AnnualDebitSalesVolume:          models.ToPointer(float64(32.23)),
    AnnualAmexVolume:                models.ToPointer(float64(10000)),
    AmexAverageTicket:               models.ToPointer(float64(2.3)),
    AverageNumberofDays:             models.ToPointer(10),
    NeedsProcessingBy:               models.ToPointer(bodyTransactionInfoNeedsProcessingBy),
}

bodyAddresses0 := models.Address1{
    Type:                models.AddressTypeEnum("Mailing Address"),
    AddressLine1:        "1234 W Tester Ave.",
    City:                "City Town",
    State:               models.State1Enum("CO"),
    Country:             "United States",
    PostalCode:          "80123",
    PostalCodeExtension: models.ToPointer("1234"),
}

bodyAddresses1 := models.Address1{
    Type:                models.AddressTypeEnum("Physical Address"),
    AddressLine1:        "1234 W Tester Ave.",
    City:                "City Town",
    State:               models.State1Enum("CO"),
    Country:             "United States",
    PostalCode:          "80123",
    PostalCodeExtension: models.ToPointer("1234"),
}

bodyAddresses := []models.Address1{bodyAddresses0, bodyAddresses1}
body := models.ExistingApplication1{
    ExternalRefId:       "df8a6d82-3bb4-4f3b-ba18-57a5981ede8e",
    LeadSource:          models.ToPointer("Activate"),
    BusinessInfo:        bodyBusinessInfo,
    TransactionInfo:     bodyTransactionInfo,
    Addresses:           bodyAddresses,
}
vCorrelationId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")
contentType := models.ContentTypeEnum("application/json")

resp, err := initiateBoardingApplicationController.ExisitingApplication(ctx, body, &vCorrelationId, &contentType)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# New Application

Use this endpoint to collect the merchant information needed to initiate a new contract.

```go
NewApplication(
    ctx context.Context,
    body models.Application,
    vCorrelationId *uuid.UUID,
    contentType *models.ContentTypeEnum) (
    models.ApiResponse[models.ApplicationResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.Application`](../../doc/models/application.md) | Body, Required | - |
| `vCorrelationId` | `*uuid.UUID` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`*models.ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

[`models.ApplicationResponse`](../../doc/models/application-response.md)

## Example Usage

```go
ctx := context.Background()

bodyBusinessInfoBusinessEstablishedDate, err := time.Parse(models.DEFAULT_DATE, "2000-03-23")
if err != nil {
    log.Fatalln(err)
}
bodyBusinessInfo := models.BusinessInfo1{
    DbaName:                 "The DBA Name",
    LegalName:               "legalName8",
    OwnershipType:           models.OwnershipTypeEnum("LLC"),
    MccCode:                 "5812",
    WebsiteUrl:              models.ToPointer("www.thefoodplace.com"),
    NumberOfLocation:        models.ToPointer(2),
    FederalTaxId:            models.ToPointer("123456781"),
    PaymentAcceptanceMethod: []models.PaymentAcceptanceMethodEnum{models.PaymentAcceptanceMethodEnum("inPerson"), models.PaymentAcceptanceMethodEnum("onlineSite")},
    Pciadc:                  models.ToPointer(models.PciadcEnum("No")),
    PcidssValidated:         models.ToPointer(models.PcidssValidatedEnum("No")),
    SurroundingArea:         models.ToPointer(models.SurroundingAreaEnum("Commercial")),
    ProductServiceSold:      models.ToPointer("Food"),
    OwnAddYears:             models.ToPointer(2),
    Seasonal:                models.ToPointer(models.SeasonalEnum("Yes")),
    ActiveMonths:            []models.ActiveMonthEnum{models.ActiveMonthEnum("Jan"), models.ActiveMonthEnum("Feb"), models.ActiveMonthEnum("Mar")},
    Warranty:                models.ToPointer(models.WarrantyEnum("1 YEAR")),
    ReturnPolicy:            models.ToPointer(models.ReturnPolicyEnum("30 Day")),
    GovOwnedMerchantCountry: models.ToPointer("US"),
    BusinessEstablishedDate: models.ToPointer(bodyBusinessInfoBusinessEstablishedDate),
}

bodyTransactionInfoNeedsProcessingBy, err := time.Parse(models.DEFAULT_DATE, "2022-11-01")
if err != nil {
    log.Fatalln(err)
}
bodyTransactionInfo := models.TransactionInfo1{
    AnnualSalesVolume:               float64(20000.12),
    PercentRetailSwipedTransactions: 82,
    AverageTicket:                   models.ToPointer(float64(2.3)),
    HighestTicket:                   models.ToPointer(float64(32.41)),
    CurrentProcessor:                models.ToPointer("Global Payments"),
    AcceptChargebacks:               models.ToPointer(models.AcceptChargebacksEnum("No")),
    ChargebackPercent:               models.ToPointer(0),
    ReturnPercent:                   models.ToPointer(10),
    CardNotPresentPercent:           models.ToPointer(20),
    BusinessToBusinessPercent:       models.ToPointer(20),
    InternetTransactionPercent:      models.ToPointer(10),
    InPersonTransactionPercent:      models.ToPointer(10),
    MotoTransactionPercent:          models.ToPointer(10),
    AnnualCreditSalesVolume:         models.ToPointer(float64(123.32)),
    AnnualDebitSalesVolume:          models.ToPointer(float64(32.23)),
    AnnualAmexVolume:                models.ToPointer(float64(10000)),
    AmexAverageTicket:               models.ToPointer(float64(2.3)),
    AverageNumberofDays:             models.ToPointer(10),
    NeedsProcessingBy:               models.ToPointer(bodyTransactionInfoNeedsProcessingBy),
}

bodyAuthorizedSigners0Dob, err := time.Parse(models.DEFAULT_DATE, "2000-03-23")
if err != nil {
    log.Fatalln(err)
}
bodyAuthorizedSigners0 := models.AuthorizedSigner1{
    RoleName:            models.RoleName1Enum("Merchant"),
    SigningExperience:   models.SigningExperienceEnum("email"),
    SigningOrder:        "2",
    Title:               models.ToPointer("President"),
    FirstName:           "Todd",
    MiddleInitial:       models.ToPointer("M"),
    LastName:            "Davis",
    PhoneNumber:         "5131234567",
    PhoneNumberExt:      models.ToPointer("1234"),
    PhoneType:           models.ToPointer(models.PhoneTypeEnum("mobile")),
    AlternatePhone:      models.ToPointer("5131234567"),
    AlternatePhoneType:  models.ToPointer(models.AlternatePhoneTypeEnum("home")),
    FaxNumber:           models.ToPointer("5131234567"),
    Email:               "test@gmail.com",
    Ssn:                 "123456789",
    AddressLine1:        "4355 N Coalwhipe St.",
    AddressLine2:        models.ToPointer("suite 104"),
    City:                "Denver",
    State:               models.State1Enum("CO"),
    Country:             "United States",
    PostalCode:          "12345",
    PostalCodeExtension: models.ToPointer("1234"),
    Dob:                 bodyAuthorizedSigners0Dob,
}

bodyAuthorizedSigners := []models.AuthorizedSigner1{bodyAuthorizedSigners0}
bodyContacts0BirthDate, err := time.Parse(models.DEFAULT_DATE, "2000-03-23")
if err != nil {
    log.Fatalln(err)
}
bodyContacts0 := models.Contact1{
    Type:               models.Type4Enum("Primary Contact"),
    Title:              models.ToPointer("President"),
    FirstName:          "Todd",
    MiddleInitial:      models.ToPointer("M"),
    LastName:           "Davis",
    Ssn:                models.ToPointer("123456789"),
    PhoneNumber:        "5131234567",
    PhoneNumberExt:     models.ToPointer("1234"),
    PhoneType:          models.ToPointer(models.PhoneTypeEnum("mobile")),
    AlternatePhone:     models.ToPointer("5131234567"),
    AlternatePhoneType: models.ToPointer(models.AlternatePhoneTypeEnum("home")),
    Email:              "test@gmail.com",
    FaxNumber:          models.ToPointer("5131234567"),
    BirthDate:          models.ToPointer(bodyContacts0BirthDate),
}

bodyContacts := []models.Contact1{bodyContacts0}
bodyAddresses0 := models.Address1{
    Type:                models.AddressTypeEnum("Mailing Address"),
    AddressLine1:        "1234 W Tester Ave.",
    City:                "City Town",
    State:               models.State1Enum("CO"),
    Country:             "United States",
    PostalCode:          "80123",
    PostalCodeExtension: models.ToPointer("1234"),
}

bodyAddresses1 := models.Address1{
    Type:                models.AddressTypeEnum("Physical Address"),
    AddressLine1:        "1234 W Tester Ave.",
    City:                "City Town",
    State:               models.State1Enum("CO"),
    Country:             "United States",
    PostalCode:          "80123",
    PostalCodeExtension: models.ToPointer("1234"),
}

bodyAddresses2 := models.Address1{
    Type:                models.AddressTypeEnum("Shipping Address"),
    AddressLine1:        "1234 W Tester Ave.",
    City:                "City Town",
    State:               models.State1Enum("CO"),
    Country:             "United States",
    PostalCode:          "80123",
    PostalCodeExtension: models.ToPointer("1234"),
}

bodyAddresses := []models.Address1{bodyAddresses0, bodyAddresses1, bodyAddresses2}
body := models.Application{
    ClientTrackingId:      models.ToPointer("1341341234132412341"),
    LeadSource:            models.ToPointer("LP Connect API"),
    BusinessInfo:          bodyBusinessInfo,
    TransactionInfo:       bodyTransactionInfo,
    AuthorizedSigners:     bodyAuthorizedSigners,
    Contacts:              bodyContacts,
    Addresses:             bodyAddresses,
}
vCorrelationId := uuid.MustParse("3fcb1437-4e52-4946-9ae1-e618351b6d16")
contentType := models.ContentTypeEnum("application/json")

apiResponse, err := initiateBoardingApplicationController.NewApplication(ctx, body, &vCorrelationId, &contentType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

