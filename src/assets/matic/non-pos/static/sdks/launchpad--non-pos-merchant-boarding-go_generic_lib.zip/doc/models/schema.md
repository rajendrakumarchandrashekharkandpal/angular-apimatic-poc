
# Schema

## Structure

`Schema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `*int64` | Optional | - |

## Example (as JSON)

```json
{
  "id": 82
}
```

