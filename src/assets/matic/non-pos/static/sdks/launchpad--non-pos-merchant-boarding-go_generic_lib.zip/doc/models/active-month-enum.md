
# Active Month Enum

## Enumeration

`ActiveMonthEnum`

## Fields

| Name |
|  --- |
| `JAN` |
| `FEB` |
| `MAR` |
| `APR` |
| `MAY` |
| `JUN` |
| `JUL` |
| `AUG` |
| `SEP` |
| `OCT` |
| `NOV` |
| `DEC` |

