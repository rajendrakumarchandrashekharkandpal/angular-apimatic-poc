
# Type 4 Enum

Type of merchant contact.

1) Only primary contact
   is mandatory. May be the same as any owner contact information.
2) For primary contact, firstName, lastName, phoneNumber and email are mandatory during POST.
3) For all other contact types, firstName and lastName are mandatory during POST.

## Enumeration

`Type4Enum`

## Fields

| Name |
|  --- |
| `ENUMPRIMARYCONTACT` |
| `ENUMSTOREPRIMARYCONTACT` |
| `ENUMACCOUNTINGCONTACT` |
| `ENUMCUSTOMERSERVICECONTACT` |
| `ENUMSHIPPINGCONTACT` |
| `ENUMTHIRDPARTYCONTACT` |
| `ENUMVENDORCONTACTINFO` |
| `ENUMPCICONTACT` |
| `CORPORATE` |

## Example

```
Primary Contact
```

