
# Payment Method Enum

Payment method for the selected terminal.

## Enumeration

`PaymentMethodEnum`

## Fields

| Name |
|  --- |
| `ENUMPURCHASESALE` |
| `ENUMREPROGRAMOWN` |
| `ENUMMONTHTOMONTHRENTAL` |
| `LEASE` |

## Example

```
PURCHASE / SALE
```

