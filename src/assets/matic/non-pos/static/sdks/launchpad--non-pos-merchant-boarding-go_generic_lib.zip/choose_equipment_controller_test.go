package launchpadnonposmerchantboarding

import (
    "context"
    "encoding/json"
    "github.com/apimatic/go-core-runtime/testHelper"
    "launchpadnonposmerchantboarding/models"
    "testing"
)

// TestChooseEquipmentControllerTestGetTerminalInfo tests the behavior of the ChooseEquipmentController's
func TestChooseEquipmentControllerTestGetTerminalInfo(t *testing.T) {
    ctx := context.Background()
    externalRefId := nil
    vCorrelationId := nil
    contentType := models.ContentTypeEnum("application/json")
    apiResponse, err := chooseEquipmentController.GetTerminalInfo(ctx, externalRefId, &vCorrelationId, &contentType, nil, nil)
    if err != nil {
        t.Errorf("Endpoint call failed: %v", err)
    }
    testHelper.CheckResponseStatusCode(t, apiResponse.Response.StatusCode, 200)
    expectedHeaders:= []testHelper.TestHeader{
        testHelper.NewTestHeader(false,"v-correlation-id",""),
        testHelper.NewTestHeader(true,"Content-Type","application/json"),
    }
    testHelper.CheckResponseHeaders(t, apiResponse.Response.Header, expectedHeaders, true)
}

// TestChooseEquipmentControllerTestUpdateTerminal tests the behavior of the ChooseEquipmentController's
func TestChooseEquipmentControllerTestUpdateTerminal(t *testing.T) {
    ctx := context.Background()
    externalRefId := nil
    var body models.EquipmentSetup
    errBody := json.Unmarshal([]byte(`{"shippingOption":"next day","terminals":[{"terminalConfigs":{"requestId":"41231","terminalId":"67","terminalModel":"VAR - Xpient Solutions","price":187.99,"quantity":1,"logicalApplicationId":"194","accessMethod":"SSL","paymentMethod":"PURCHASE / SALE","environmentName":"Restaurant"},"products":[{"productId":"1","productName":"Credit"}]}]}`), &body)
    if errBody != nil {
        t.Errorf("Cannot parse the model object.")
    }
    vCorrelationId := nil
    contentType := models.ContentTypeEnum("application/json")
    resp, err := chooseEquipmentController.UpdateTerminal(ctx, externalRefId, body, &vCorrelationId, &contentType, nil, nil)
    if err != nil {
        t.Errorf("Endpoint call failed: %v", err)
    }
    testHelper.CheckResponseStatusCode(t, resp.StatusCode, 200)
    expectedHeaders:= []testHelper.TestHeader{
        testHelper.NewTestHeader(false,"v-correlation-id",""),
    }
    testHelper.CheckResponseHeaders(t, resp.Header, expectedHeaders, true)
}

// TestChooseEquipmentControllerTestConfigStandaloneTerminal tests the behavior of the ChooseEquipmentController's
func TestChooseEquipmentControllerTestConfigStandaloneTerminal(t *testing.T) {
    ctx := context.Background()
    externalRefId := nil
    var body models.EquipmentSetup
    errBody := json.Unmarshal([]byte(`{"shippingOption":"next day","terminals":[{"terminalConfigs":{"requestId":"41231","terminalId":"67","terminalModel":"VAR - Xpient Solutions","price":187.99,"quantity":1,"logicalApplicationId":"194","accessMethod":"SSL","paymentMethod":"PURCHASE / SALE","environmentName":"Restaurant"},"products":[{"productId":"1","productName":"Credit"}]}]}`), &body)
    if errBody != nil {
        t.Errorf("Cannot parse the model object.")
    }
    vCorrelationId := nil
    contentType := models.ContentTypeEnum("application/json")
    resp, err := chooseEquipmentController.ConfigStandaloneTerminal(ctx, externalRefId, body, &vCorrelationId, &contentType, nil, nil)
    if err != nil {
        t.Errorf("Endpoint call failed: %v", err)
    }
    testHelper.CheckResponseStatusCode(t, resp.StatusCode, 200)
    expectedHeaders:= []testHelper.TestHeader{
        testHelper.NewTestHeader(false,"v-correlation-id",""),
    }
    testHelper.CheckResponseHeaders(t, resp.Header, expectedHeaders, true)
}
