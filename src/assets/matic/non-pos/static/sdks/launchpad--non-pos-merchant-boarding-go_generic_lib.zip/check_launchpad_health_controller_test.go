package launchpadnonposmerchantboarding

import (
    "context"
    "github.com/apimatic/go-core-runtime/testHelper"
    "testing"
)

// TestCheckLaunchpadHealthControllerTestGethealth tests the behavior of the CheckLaunchpadHealthController's
func TestCheckLaunchpadHealthControllerTestGethealth(t *testing.T) {
    ctx := context.Background()
    vCorrelationId := nil
    apiResponse, err := checkLaunchpadHealthController.Gethealth(ctx, &vCorrelationId)
    if err != nil {
        t.Errorf("Endpoint call failed: %v", err)
    }
    testHelper.CheckResponseStatusCode(t, apiResponse.Response.StatusCode, 200)
    expectedHeaders:= []testHelper.TestHeader{
        testHelper.NewTestHeader(true,"Content-Type","application/json"),
    }
    testHelper.CheckResponseHeaders(t, apiResponse.Response.Header, expectedHeaders, true)
}
