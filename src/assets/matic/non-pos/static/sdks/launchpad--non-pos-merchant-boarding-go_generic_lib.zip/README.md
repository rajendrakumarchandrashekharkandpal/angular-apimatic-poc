
# Getting Started with Launchpad: Non-POS Merchant Boarding

## Introduction

The Launchpads Merchant Boarding API allows Worldpay partners to onboard merchants to Worldpay's Payments Platform. Please see the Getting Started page for more information. </br> </br> To contact our certifications team, please email <a href="mailto:Certification2@fisglobal.com">Certification2@fisglobal.com</a>.   </br> To contact the product team, please email <a href="mailto:APICustomerIntegration@fisglobal.com">APICustomerIntegration@fisglobal.com</a>.

### Requirements

The SDK requires **Go version 1.18 or above**.

## Building

### Install Dependencies

Resolve all the SDK dependencies, using the `go get` command.

## Installation

The following section explains how to use the launchpadnonposmerchantboarding library in a new project.

### 1. Add SDK as a Dependency to the Application

- Add the following lines to your application's `go.mod` file:

```go
replace launchpadnonposmerchantboarding => ".\\launchpad--non-pos-merchant-boarding-go_generic_lib" // local path to the SDK

require launchpadnonposmerchantboarding v0.0.0
```

- Resolve the dependencies in the updated `go.mod` file, using the `go get` command.

## Test the SDK

`Go Testing` is used as the testing framework. To run the unit tests of the SDK, navigate to the root directory of the SDK and run the following command in the terminal:

```bash
$ go test
```

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `environment` | `Environment` | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| `httpConfiguration` | [`HttpConfiguration`](doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| `customHeaderAuthenticationCredentials` | [`CustomHeaderAuthenticationCredentials`](doc/auth/custom-header-signature.md) | The Credentials Setter for Custom Header Signature |

The API client can be initialized as follows:

```go
client := launchpadnonposmerchantboarding.NewClient(
    launchpadnonposmerchantboarding.CreateConfiguration(
        launchpadnonposmerchantboarding.WithHttpConfiguration(
            launchpadnonposmerchantboarding.CreateHttpConfiguration(
                launchpadnonposmerchantboarding.WithTimeout(0),
            ),
        ),
        launchpadnonposmerchantboarding.WithEnvironment(launchpadnonposmerchantboarding.PRODUCTION),
        launchpadnonposmerchantboarding.WithCustomHeaderAuthenticationCredentials(
            launchpadnonposmerchantboarding.NewCustomHeaderAuthenticationCredentials("Authorization"),
        ),
    ),
)
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| production | **Default** |
| environment2 | - |

## Authorization

This API uses the following authentication schemes.

* [`api_key (Custom Header Signature)`](doc/auth/custom-header-signature.md)

## List of APIs

* [Initiate Boarding Application](doc/controllers/initiate-boarding-application.md)
* [Equipment Lookup](doc/controllers/equipment-lookup.md)
* [Choose Equipment](doc/controllers/choose-equipment.md)
* [Submit Application](doc/controllers/submit-application.md)
* [Check Application Status](doc/controllers/check-application-status.md)
* [Reviewand Sign Contract](doc/controllers/reviewand-sign-contract.md)
* [Check Launchpadhealth](doc/controllers/check-launchpadhealth.md)

## Classes Documentation

* [HttpConfiguration](doc/http-configuration.md)
* [RetryConfiguration](doc/retry-configuration.md)

