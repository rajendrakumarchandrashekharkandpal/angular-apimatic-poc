package launchpadnonposmerchantboarding

var initiateBoardingApplicationController InitiateBoardingApplicationController

var equipmentLookupController EquipmentLookupController

var chooseEquipmentController ChooseEquipmentController

var submitApplicationController SubmitApplicationController

var checkApplicationStatusController CheckApplicationStatusController

var reviewAndSignContractController ReviewAndSignContractController

var checkLaunchpadHealthController CheckLaunchpadHealthController

// init is an initialization function that sets up the controllers.
// It creates a configuration from the environment with a specified HTTP configuration and initializes the client.
// Then, it assigns the different controllers from the client to the corresponding variables for further use.
func init() {
    
    config := CreateConfigurationFromEnvironment(
        WithHttpConfiguration(
            CreateHttpConfiguration(
                WithTimeout(30),
            ),
        ),
    )
    
    client := NewClient(config)
    
    initiateBoardingApplicationController = *client.InitiateBoardingApplicationController()
    equipmentLookupController = *client.EquipmentLookupController()
    chooseEquipmentController = *client.ChooseEquipmentController()
    submitApplicationController = *client.SubmitApplicationController()
    checkApplicationStatusController = *client.CheckApplicationStatusController()
    reviewAndSignContractController = *client.ReviewAndSignContractController()
    checkLaunchpadHealthController = *client.CheckLaunchpadHealthController()
}
