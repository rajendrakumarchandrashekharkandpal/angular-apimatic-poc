package launchpadnonposmerchantboarding

import (
    "context"
    "github.com/apimatic/go-core-runtime/testHelper"
    "launchpadnonposmerchantboarding/models"
    "testing"
)

// TestSubmitApplicationControllerTestValidateBoard tests the behavior of the SubmitApplicationController's
func TestSubmitApplicationControllerTestValidateBoard(t *testing.T) {
    ctx := context.Background()
    externalRefId := nil
    vCorrelationId := nil
    contentType := models.ContentTypeEnum("application/json")
    resp, err := submitApplicationController.ValidateBoard(ctx, externalRefId, &vCorrelationId, &contentType)
    if err != nil {
        t.Errorf("Endpoint call failed: %v", err)
    }
    testHelper.CheckResponseStatusCode(t, resp.StatusCode, 200)
    expectedHeaders:= []testHelper.TestHeader{
        testHelper.NewTestHeader(false,"v-correlation-id",""),
    }
    testHelper.CheckResponseHeaders(t, resp.Header, expectedHeaders, true)
}

// TestSubmitApplicationControllerTestInititateBoard tests the behavior of the SubmitApplicationController's
func TestSubmitApplicationControllerTestInititateBoard(t *testing.T) {
    ctx := context.Background()
    externalRefId := nil
    vCorrelationId := nil
    contentType := models.ContentTypeEnum("application/json")
    resp, err := submitApplicationController.InititateBoard(ctx, externalRefId, &vCorrelationId, &contentType, nil)
    if err != nil {
        t.Errorf("Endpoint call failed: %v", err)
    }
    testHelper.CheckResponseStatusCode(t, resp.StatusCode, 200)
    expectedHeaders:= []testHelper.TestHeader{
        testHelper.NewTestHeader(false,"v-correlation-id",""),
    }
    testHelper.CheckResponseHeaders(t, resp.Header, expectedHeaders, true)
}
