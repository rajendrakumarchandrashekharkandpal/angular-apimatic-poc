package launchpadnonposmerchantboarding

import (
    "context"
    "github.com/apimatic/go-core-runtime/https"
    "github.com/google/uuid"
    "launchpadnonposmerchantboarding/errors"
    "launchpadnonposmerchantboarding/models"
    "net/http"
)

// SubmitApplicationController represents a controller struct.
type SubmitApplicationController struct {
    baseController
}

// NewSubmitApplicationController creates a new instance of SubmitApplicationController.
// It takes a baseController as a parameter and returns a pointer to the SubmitApplicationController.
func NewSubmitApplicationController(baseController baseController) *SubmitApplicationController {
    submitApplicationController := SubmitApplicationController{baseController: baseController}
    return &submitApplicationController
}

// ValidateBoard takes context, externalRefId, vCorrelationId, contentType as parameters and
// returns an models.ApiResponse with  data and
// an error if there was an issue with the request or response.
// Begins the merchant validation process before boarding after all necessary information has been submitted to the API. Please see the reference guide for specific boarding requirements.
func (s *SubmitApplicationController) ValidateBoard(
    ctx context.Context,
    externalRefId uuid.UUID,
    vCorrelationId *uuid.UUID,
    contentType *models.ContentTypeEnum) (
    *http.Response,
    error) {
    req := s.prepareRequest(ctx, "PUT", "/applications/validate")
    req.Authenticate(NewAuth("api_key"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "0": {Message: "Default errors", Unmarshaller: errors.NewErrorResponse},
    })
    req.Header("externalRefId", externalRefId)
    if vCorrelationId != nil {
        req.Header("v-correlation-id", *vCorrelationId)
    }
    if contentType != nil {
        req.Header("Content-Type", *contentType)
    }
    context, err := req.Call()
    if err != nil {
        return context.Response, err
    }
    return context.Response, err
}

// InititateBoard takes context, externalRefId, vCorrelationId, contentType, threatmetrixId as parameters and
// returns an models.ApiResponse with  data and
// an error if there was an issue with the request or response.
// Begins the merchant boarding process after all necessary information has been submitted to the API. Please see the reference guide for specific boarding requirements.
func (s *SubmitApplicationController) InititateBoard(
    ctx context.Context,
    externalRefId uuid.UUID,
    vCorrelationId *uuid.UUID,
    contentType *models.ContentTypeEnum,
    threatmetrixId *string) (
    *http.Response,
    error) {
    req := s.prepareRequest(ctx, "PUT", "/applications/board")
    req.Authenticate(NewAuth("api_key"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "0": {Message: "Default errors", Unmarshaller: errors.NewErrorResponse},
    })
    req.Header("externalRefId", externalRefId)
    if vCorrelationId != nil {
        req.Header("v-correlation-id", *vCorrelationId)
    }
    if contentType != nil {
        req.Header("Content-Type", *contentType)
    }
    if threatmetrixId != nil {
        req.Header("threatmetrixId", *threatmetrixId)
    }
    context, err := req.Call()
    if err != nil {
        return context.Response, err
    }
    return context.Response, err
}
