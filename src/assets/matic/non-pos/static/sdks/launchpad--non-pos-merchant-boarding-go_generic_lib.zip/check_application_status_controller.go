package launchpadnonposmerchantboarding

import (
    "context"
    "github.com/apimatic/go-core-runtime/https"
    "github.com/apimatic/go-core-runtime/utilities"
    "github.com/google/uuid"
    "launchpadnonposmerchantboarding/errors"
    "launchpadnonposmerchantboarding/models"
)

// CheckApplicationStatusController represents a controller struct.
type CheckApplicationStatusController struct {
    baseController
}

// NewCheckApplicationStatusController creates a new instance of CheckApplicationStatusController.
// It takes a baseController as a parameter and returns a pointer to the CheckApplicationStatusController.
func NewCheckApplicationStatusController(baseController baseController) *CheckApplicationStatusController {
    checkApplicationStatusController := CheckApplicationStatusController{baseController: baseController}
    return &checkApplicationStatusController
}

// GetApplicationStatus takes context, externalRefId, vCorrelationId as parameters and
// returns an models.ApiResponse with models.ApplicationStatus data and
// an error if there was an issue with the request or response.
// Retrieves the status of a contract when passed with an externalRefID. Both the externalRefID and authorization header are required.
func (c *CheckApplicationStatusController) GetApplicationStatus(
    ctx context.Context,
    externalRefId uuid.UUID,
    vCorrelationId *uuid.UUID) (
    models.ApiResponse[models.ApplicationStatus],
    error) {
    req := c.prepareRequest(ctx, "GET", "/applications/status")
    req.Authenticate(NewAuth("api_key"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "0": {Message: "Default errors", Unmarshaller: errors.NewErrorResponse},
    })
    req.Header("externalRefId", externalRefId)
    if vCorrelationId != nil {
        req.Header("v-correlation-id", *vCorrelationId)
    }
    var result models.ApplicationStatus
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[models.ApplicationStatus](decoder)
    return models.NewApiResponse(result, resp), err
}

// FetchApplicationStatusHistory takes context, externalRefId, vCorrelationId as parameters and
// returns an models.ApiResponse with models.StatusHistoryResponse data and
// an error if there was an issue with the request or response.
// Use this endpoint to get a application's status history.
func (c *CheckApplicationStatusController) FetchApplicationStatusHistory(
    ctx context.Context,
    externalRefId uuid.UUID,
    vCorrelationId *uuid.UUID) (
    models.ApiResponse[models.StatusHistoryResponse],
    error) {
    req := c.prepareRequest(ctx, "GET", "/applications/status/history")
    req.Authenticate(NewAuth("api_key"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "0": {Message: "Default errors", Unmarshaller: errors.NewErrorResponse},
    })
    req.Header("externalRefId", externalRefId)
    if vCorrelationId != nil {
        req.Header("v-correlation-id", *vCorrelationId)
    }
    var result models.StatusHistoryResponse
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[models.StatusHistoryResponse](decoder)
    return models.NewApiResponse(result, resp), err
}

// FetchSignerStatus takes context, externalRefId, vCorrelationId, contentType as parameters and
// returns an models.ApiResponse with models.SignerStatus data and
// an error if there was an issue with the request or response.
// Use this endpoint to get signer status
func (c *CheckApplicationStatusController) FetchSignerStatus(
    ctx context.Context,
    externalRefId uuid.UUID,
    vCorrelationId *uuid.UUID,
    contentType *models.ContentTypeEnum) (
    models.ApiResponse[models.SignerStatus],
    error) {
    req := c.prepareRequest(ctx, "GET", "/applications/status/signers")
    req.Authenticate(NewAuth("api_key"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "0": {Message: "Default errors", Unmarshaller: errors.NewErrorResponse},
    })
    req.Header("externalRefId", externalRefId)
    if vCorrelationId != nil {
        req.Header("v-correlation-id", *vCorrelationId)
    }
    if contentType != nil {
        req.Header("Content-Type", *contentType)
    }
    var result models.SignerStatus
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[models.SignerStatus](decoder)
    return models.NewApiResponse(result, resp), err
}
