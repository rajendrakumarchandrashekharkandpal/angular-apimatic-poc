package models

import (
    "encoding/json"
    "errors"
    "log"
    "strings"
    "time"
)

// Contact1 represents a Contact1 struct.
type Contact1 struct {
    // Type of merchant contact.   
    //  1) Only primary contact
    //       is mandatory. May be the same as any owner contact information. 
    //  2) For primary contact, firstName, lastName, phoneNumber and email are mandatory during POST.  
    //  3) For all other contact types, firstName and lastName are mandatory during POST.
    Type               Type4Enum               `json:"type"`
    // Required for AMEX acquired merchants otherwise optional.
    Title              *string                 `json:"title,omitempty"`
    // First name. Region based validations will be applied to this field.
    FirstName          string                  `json:"firstName"`
    // Middle initial.
    MiddleInitial      *string                 `json:"middleInitial,omitempty"`
    // Last name. Region based validations will be applied to this field.
    LastName           string                  `json:"lastName"`
    // Social security number. Do not include dashes.The full list of restricted SSN is- “000000001” “000000002” “000000003” “000000004” “000000005” “000000006” “000000007” “000000008” “000000009" "111111110" “111111111” "111111112" "111111113" "111111114" "111111115" "111111116" "111111117" "111111118" "111111119" "222222220" "222222221" “222222222” "222222223" "222222224" "222222225" "222222226" "222222227" "222222228" "222222229" "333333330" "333333331" "333333332" “333333333” "333333334" "333333335" "333333336" "333333337" "333333338" "333333339"  "444444440" "444444441" "444444442" "444444443" “444444444” "444444445" "444444446" "444444447" "444444448" "444444449" "555555550" "555555551" "555555552" "555555553" "555555554" “555555555” "555555556" "555555557" "555555558" "555555559"  "666666660" "666666661" "666666662" "666666663" "666666664" "666666665" “666666666" "666666667" "666666668" "666666669" "777777770" "777777771” "777777772" "777777773" "777777774" "777777775" "777777776" “777777777” "777777778" "777777779" "888888880" "888888881" "888888882" "888888883" "888888884" "888888885" "888888886" "888888887" “888888888” "888888889"  "999999990" "999999991" "999999992" "999999993" "999999994" "999999995" "99999996"   "999999997" "999999998" “999999999”  "123456780" to "123456789" "123123123"
    Ssn                *string                 `json:"ssn,omitempty"`
    // Date of Birth (CCYY-MM-DD). Must be at least 18 years old.
    BirthDate          *time.Time              `json:"birthDate,omitempty"`
    // 10-digit phone number of the format  5131234567.
    PhoneNumber        string                  `json:"phoneNumber"`
    // Phone number extension. Up to 8 digits of the format 12345678.
    PhoneNumberExt     *string                 `json:"phoneNumberExt,omitempty"`
    // Phone type.
    PhoneType          *PhoneTypeEnum          `json:"phoneType,omitempty"`
    // 10-digit alternate phone number of the format  5131234567.
    AlternatePhone     *string                 `json:"alternatePhone,omitempty"`
    // Alternate phone type.
    AlternatePhoneType *AlternatePhoneTypeEnum `json:"alternatePhoneType,omitempty"`
    // Email address of the contact. Must have @ and a .
    Email              string                  `json:"email"`
    // 10-digit fax number of the format 5131234567
    FaxNumber          *string                 `json:"faxNumber,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for Contact1.
// It customizes the JSON marshaling process for Contact1 objects.
func (c *Contact1) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(c.toMap())
}

// toMap converts the Contact1 object to a map representation for JSON marshaling.
func (c *Contact1) toMap() map[string]any {
    structMap := make(map[string]any)
    structMap["type"] = c.Type
    if c.Title != nil {
        structMap["title"] = c.Title
    }
    structMap["firstName"] = c.FirstName
    if c.MiddleInitial != nil {
        structMap["middleInitial"] = c.MiddleInitial
    }
    structMap["lastName"] = c.LastName
    if c.Ssn != nil {
        structMap["ssn"] = c.Ssn
    }
    if c.BirthDate != nil {
        structMap["birthDate"] = c.BirthDate.Format(DEFAULT_DATE)
    }
    structMap["phoneNumber"] = c.PhoneNumber
    if c.PhoneNumberExt != nil {
        structMap["phoneNumberExt"] = c.PhoneNumberExt
    }
    if c.PhoneType != nil {
        structMap["phoneType"] = c.PhoneType
    }
    if c.AlternatePhone != nil {
        structMap["alternatePhone"] = c.AlternatePhone
    }
    if c.AlternatePhoneType != nil {
        structMap["alternatePhoneType"] = c.AlternatePhoneType
    }
    structMap["email"] = c.Email
    if c.FaxNumber != nil {
        structMap["faxNumber"] = c.FaxNumber
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for Contact1.
// It customizes the JSON unmarshaling process for Contact1 objects.
func (c *Contact1) UnmarshalJSON(input []byte) error {
    var temp contact1
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    err = temp.validate()
    if err != nil {
    	return err
    }
    
    c.Type = *temp.Type
    c.Title = temp.Title
    c.FirstName = *temp.FirstName
    c.MiddleInitial = temp.MiddleInitial
    c.LastName = *temp.LastName
    c.Ssn = temp.Ssn
    if temp.BirthDate != nil {
        BirthDateVal, err := time.Parse(DEFAULT_DATE, *temp.BirthDate)
        if err != nil {
            log.Fatalf("Cannot Parse birthDate as % s format.", DEFAULT_DATE)
        }
        c.BirthDate = &BirthDateVal
    }
    c.PhoneNumber = *temp.PhoneNumber
    c.PhoneNumberExt = temp.PhoneNumberExt
    c.PhoneType = temp.PhoneType
    c.AlternatePhone = temp.AlternatePhone
    c.AlternatePhoneType = temp.AlternatePhoneType
    c.Email = *temp.Email
    c.FaxNumber = temp.FaxNumber
    return nil
}

// TODO
type contact1  struct {
    Type               *Type4Enum              `json:"type"`
    Title              *string                 `json:"title,omitempty"`
    FirstName          *string                 `json:"firstName"`
    MiddleInitial      *string                 `json:"middleInitial,omitempty"`
    LastName           *string                 `json:"lastName"`
    Ssn                *string                 `json:"ssn,omitempty"`
    BirthDate          *string                 `json:"birthDate,omitempty"`
    PhoneNumber        *string                 `json:"phoneNumber"`
    PhoneNumberExt     *string                 `json:"phoneNumberExt,omitempty"`
    PhoneType          *PhoneTypeEnum          `json:"phoneType,omitempty"`
    AlternatePhone     *string                 `json:"alternatePhone,omitempty"`
    AlternatePhoneType *AlternatePhoneTypeEnum `json:"alternatePhoneType,omitempty"`
    Email              *string                 `json:"email"`
    FaxNumber          *string                 `json:"faxNumber,omitempty"`
}

func (c *contact1) validate() error {
    var errs []string
    if c.Type == nil {
        errs = append(errs, "required field `type` is missing for type `Contact_1`")
    }
    if c.FirstName == nil {
        errs = append(errs, "required field `firstName` is missing for type `Contact_1`")
    }
    if c.LastName == nil {
        errs = append(errs, "required field `lastName` is missing for type `Contact_1`")
    }
    if c.PhoneNumber == nil {
        errs = append(errs, "required field `phoneNumber` is missing for type `Contact_1`")
    }
    if c.Email == nil {
        errs = append(errs, "required field `email` is missing for type `Contact_1`")
    }
    if len(errs) == 0 {
        return nil
    }
    return errors.New(strings.Join(errs, "\n"))
}
