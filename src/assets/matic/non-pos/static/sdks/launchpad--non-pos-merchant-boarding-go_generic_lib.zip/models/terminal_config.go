package models

import (
    "encoding/json"
    "errors"
    "strings"
)

// TerminalConfig represents a TerminalConfig struct.
type TerminalConfig struct {
    // Partner assigned unique request ID for terminal setup.
    RequestId              *string              `json:"requestId,omitempty"`
    // Terminal ID number.
    TerminalId             string               `json:"terminalId"`
    // The model name of the terminal in use.
    TerminalModel          *string              `json:"terminalModel,omitempty"`
    // Terminal price
    Price                  float64              `json:"price"`
    Quantity               int                  `json:"quantity"`
    // Logical application ID.
    LogicalApplicationId   string               `json:"logicalApplicationId"`
    // Methods of terminal access.
    AccessMethod           string               `json:"accessMethod"`
    // Payment method for the selected terminal.
    PaymentMethod          PaymentMethodEnum    `json:"paymentMethod"`
    // Environment name
    EnvironmentName        string               `json:"environmentName"`
    // The value added reseller. Default value is false.
    IsVar                  *bool                `json:"isVar,omitempty"`
    // Is it EMV capabale?
    EmvCapable             *bool                `json:"emvCapable,omitempty"`
    // Lease ID. Required when PaymentMethod is selected as lease.
    LeaseId                *string              `json:"leaseId,omitempty"`
    // Lease term for the peripheral
    LeaseTermLength        *LeaseTermLengthEnum `json:"leaseTermLength,omitempty"`
    // Terminal sequence number. If not sent, the API will autogenerate a number.
    TerminalSequenceNumber *string              `json:"terminalSequenceNumber,omitempty"`
    // Any customization request for a terminal configuration.
    SpecialCustomizations  *string              `json:"specialCustomizations,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for TerminalConfig.
// It customizes the JSON marshaling process for TerminalConfig objects.
func (t *TerminalConfig) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(t.toMap())
}

// toMap converts the TerminalConfig object to a map representation for JSON marshaling.
func (t *TerminalConfig) toMap() map[string]any {
    structMap := make(map[string]any)
    if t.RequestId != nil {
        structMap["requestId"] = t.RequestId
    }
    structMap["terminalId"] = t.TerminalId
    if t.TerminalModel != nil {
        structMap["terminalModel"] = t.TerminalModel
    }
    structMap["price"] = t.Price
    structMap["quantity"] = t.Quantity
    structMap["logicalApplicationId"] = t.LogicalApplicationId
    structMap["accessMethod"] = t.AccessMethod
    structMap["paymentMethod"] = t.PaymentMethod
    structMap["environmentName"] = t.EnvironmentName
    if t.IsVar != nil {
        structMap["isVar"] = t.IsVar
    }
    if t.EmvCapable != nil {
        structMap["emvCapable"] = t.EmvCapable
    }
    if t.LeaseId != nil {
        structMap["leaseId"] = t.LeaseId
    }
    if t.LeaseTermLength != nil {
        structMap["leaseTermLength"] = t.LeaseTermLength
    }
    if t.TerminalSequenceNumber != nil {
        structMap["terminalSequenceNumber"] = t.TerminalSequenceNumber
    }
    if t.SpecialCustomizations != nil {
        structMap["specialCustomizations"] = t.SpecialCustomizations
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for TerminalConfig.
// It customizes the JSON unmarshaling process for TerminalConfig objects.
func (t *TerminalConfig) UnmarshalJSON(input []byte) error {
    var temp terminalConfig
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    err = temp.validate()
    if err != nil {
    	return err
    }
    
    t.RequestId = temp.RequestId
    t.TerminalId = *temp.TerminalId
    t.TerminalModel = temp.TerminalModel
    t.Price = *temp.Price
    t.Quantity = *temp.Quantity
    t.LogicalApplicationId = *temp.LogicalApplicationId
    t.AccessMethod = *temp.AccessMethod
    t.PaymentMethod = *temp.PaymentMethod
    t.EnvironmentName = *temp.EnvironmentName
    t.IsVar = temp.IsVar
    t.EmvCapable = temp.EmvCapable
    t.LeaseId = temp.LeaseId
    t.LeaseTermLength = temp.LeaseTermLength
    t.TerminalSequenceNumber = temp.TerminalSequenceNumber
    t.SpecialCustomizations = temp.SpecialCustomizations
    return nil
}

// TODO
type terminalConfig  struct {
    RequestId              *string              `json:"requestId,omitempty"`
    TerminalId             *string              `json:"terminalId"`
    TerminalModel          *string              `json:"terminalModel,omitempty"`
    Price                  *float64             `json:"price"`
    Quantity               *int                 `json:"quantity"`
    LogicalApplicationId   *string              `json:"logicalApplicationId"`
    AccessMethod           *string              `json:"accessMethod"`
    PaymentMethod          *PaymentMethodEnum   `json:"paymentMethod"`
    EnvironmentName        *string              `json:"environmentName"`
    IsVar                  *bool                `json:"isVar,omitempty"`
    EmvCapable             *bool                `json:"emvCapable,omitempty"`
    LeaseId                *string              `json:"leaseId,omitempty"`
    LeaseTermLength        *LeaseTermLengthEnum `json:"leaseTermLength,omitempty"`
    TerminalSequenceNumber *string              `json:"terminalSequenceNumber,omitempty"`
    SpecialCustomizations  *string              `json:"specialCustomizations,omitempty"`
}

func (t *terminalConfig) validate() error {
    var errs []string
    if t.TerminalId == nil {
        errs = append(errs, "required field `terminalId` is missing for type `TerminalConfig`")
    }
    if t.Price == nil {
        errs = append(errs, "required field `price` is missing for type `TerminalConfig`")
    }
    if t.Quantity == nil {
        errs = append(errs, "required field `quantity` is missing for type `TerminalConfig`")
    }
    if t.LogicalApplicationId == nil {
        errs = append(errs, "required field `logicalApplicationId` is missing for type `TerminalConfig`")
    }
    if t.AccessMethod == nil {
        errs = append(errs, "required field `accessMethod` is missing for type `TerminalConfig`")
    }
    if t.PaymentMethod == nil {
        errs = append(errs, "required field `paymentMethod` is missing for type `TerminalConfig`")
    }
    if t.EnvironmentName == nil {
        errs = append(errs, "required field `environmentName` is missing for type `TerminalConfig`")
    }
    if len(errs) == 0 {
        return nil
    }
    return errors.New(strings.Join(errs, "\n"))
}
