package models

import (
    "encoding/json"
    "errors"
    "strings"
)

// InstallationContact represents a InstallationContact struct.
// The Technical Agent who is going to do setup.
type InstallationContact struct {
    // Id for Technical Contact
    Id                *string `json:"id,omitempty"`
    // Contact's first name.
    FirstName         string  `json:"firstName"`
    // Contact's last name.
    LastName          string  `json:"lastName"`
    // Contact's 10-digit phone number of the format 5131234567.
    MobilePhoneNumber *string `json:"mobilePhoneNumber,omitempty"`
    // Contact's email address. Must have @ and a .
    Email             string  `json:"email"`
}

// MarshalJSON implements the json.Marshaler interface for InstallationContact.
// It customizes the JSON marshaling process for InstallationContact objects.
func (i *InstallationContact) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(i.toMap())
}

// toMap converts the InstallationContact object to a map representation for JSON marshaling.
func (i *InstallationContact) toMap() map[string]any {
    structMap := make(map[string]any)
    if i.Id != nil {
        structMap["id"] = i.Id
    }
    structMap["firstName"] = i.FirstName
    structMap["lastName"] = i.LastName
    if i.MobilePhoneNumber != nil {
        structMap["mobilePhoneNumber"] = i.MobilePhoneNumber
    }
    structMap["email"] = i.Email
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for InstallationContact.
// It customizes the JSON unmarshaling process for InstallationContact objects.
func (i *InstallationContact) UnmarshalJSON(input []byte) error {
    var temp installationContact
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    err = temp.validate()
    if err != nil {
    	return err
    }
    
    i.Id = temp.Id
    i.FirstName = *temp.FirstName
    i.LastName = *temp.LastName
    i.MobilePhoneNumber = temp.MobilePhoneNumber
    i.Email = *temp.Email
    return nil
}

// TODO
type installationContact  struct {
    Id                *string `json:"id,omitempty"`
    FirstName         *string `json:"firstName"`
    LastName          *string `json:"lastName"`
    MobilePhoneNumber *string `json:"mobilePhoneNumber,omitempty"`
    Email             *string `json:"email"`
}

func (i *installationContact) validate() error {
    var errs []string
    if i.FirstName == nil {
        errs = append(errs, "required field `firstName` is missing for type `InstallationContact`")
    }
    if i.LastName == nil {
        errs = append(errs, "required field `lastName` is missing for type `InstallationContact`")
    }
    if i.Email == nil {
        errs = append(errs, "required field `email` is missing for type `InstallationContact`")
    }
    if len(errs) == 0 {
        return nil
    }
    return errors.New(strings.Join(errs, "\n"))
}
