package models

import (
    "encoding/json"
    "log"
    "time"
)

// AuthSigners represents a AuthSigners struct.
type AuthSigners struct {
    // First name. Region based validations will be applied to this field.
    FirstName        *string    `json:"firstName,omitempty"`
    // Middle initial.
    MiddleInitial    *string    `json:"middleInitial,omitempty"`
    // Last name. Region based validations will be applied to this field.
    LastName         *string    `json:"lastName,omitempty"`
    // Email address of the contact. Must have @ and a .
    Email            *string    `json:"email,omitempty"`
    // Status of the signer
    Status           *string    `json:"status,omitempty"`
    // Date contract was last updated
    LastUpdated      *time.Time `json:"lastUpdated,omitempty"`
    // Date contract was last updated
    DateSubmitted    *time.Time `json:"dateSubmitted,omitempty"`
    // Date contract was sent
    DateSent         *time.Time `json:"dateSent,omitempty"`
    // Date contract was delivered
    DateDelivered    *time.Time `json:"dateDelivered,omitempty"`
    // Date contract was signed
    DateSigned       *time.Time `json:"dateSigned,omitempty"`
    // Role of the signer
    SignerRoleName   *string    `json:"signerRoleName,omitempty"`
    // Method of sign
    SignerExperience *string    `json:"signerExperience,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for AuthSigners.
// It customizes the JSON marshaling process for AuthSigners objects.
func (a *AuthSigners) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(a.toMap())
}

// toMap converts the AuthSigners object to a map representation for JSON marshaling.
func (a *AuthSigners) toMap() map[string]any {
    structMap := make(map[string]any)
    if a.FirstName != nil {
        structMap["firstName"] = a.FirstName
    }
    if a.MiddleInitial != nil {
        structMap["middleInitial"] = a.MiddleInitial
    }
    if a.LastName != nil {
        structMap["lastName"] = a.LastName
    }
    if a.Email != nil {
        structMap["email"] = a.Email
    }
    if a.Status != nil {
        structMap["status"] = a.Status
    }
    if a.LastUpdated != nil {
        structMap["lastUpdated"] = a.LastUpdated.Format(time.RFC3339)
    }
    if a.DateSubmitted != nil {
        structMap["dateSubmitted"] = a.DateSubmitted.Format(time.RFC3339)
    }
    if a.DateSent != nil {
        structMap["dateSent"] = a.DateSent.Format(time.RFC3339)
    }
    if a.DateDelivered != nil {
        structMap["dateDelivered"] = a.DateDelivered.Format(time.RFC3339)
    }
    if a.DateSigned != nil {
        structMap["dateSigned"] = a.DateSigned.Format(time.RFC3339)
    }
    if a.SignerRoleName != nil {
        structMap["signerRoleName"] = a.SignerRoleName
    }
    if a.SignerExperience != nil {
        structMap["signerExperience"] = a.SignerExperience
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for AuthSigners.
// It customizes the JSON unmarshaling process for AuthSigners objects.
func (a *AuthSigners) UnmarshalJSON(input []byte) error {
    var temp authSigners
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    a.FirstName = temp.FirstName
    a.MiddleInitial = temp.MiddleInitial
    a.LastName = temp.LastName
    a.Email = temp.Email
    a.Status = temp.Status
    if temp.LastUpdated != nil {
        LastUpdatedVal, err := time.Parse(time.RFC3339, *temp.LastUpdated)
        if err != nil {
            log.Fatalf("Cannot Parse lastUpdated as % s format.", time.RFC3339)
        }
        a.LastUpdated = &LastUpdatedVal
    }
    if temp.DateSubmitted != nil {
        DateSubmittedVal, err := time.Parse(time.RFC3339, *temp.DateSubmitted)
        if err != nil {
            log.Fatalf("Cannot Parse dateSubmitted as % s format.", time.RFC3339)
        }
        a.DateSubmitted = &DateSubmittedVal
    }
    if temp.DateSent != nil {
        DateSentVal, err := time.Parse(time.RFC3339, *temp.DateSent)
        if err != nil {
            log.Fatalf("Cannot Parse dateSent as % s format.", time.RFC3339)
        }
        a.DateSent = &DateSentVal
    }
    if temp.DateDelivered != nil {
        DateDeliveredVal, err := time.Parse(time.RFC3339, *temp.DateDelivered)
        if err != nil {
            log.Fatalf("Cannot Parse dateDelivered as % s format.", time.RFC3339)
        }
        a.DateDelivered = &DateDeliveredVal
    }
    if temp.DateSigned != nil {
        DateSignedVal, err := time.Parse(time.RFC3339, *temp.DateSigned)
        if err != nil {
            log.Fatalf("Cannot Parse dateSigned as % s format.", time.RFC3339)
        }
        a.DateSigned = &DateSignedVal
    }
    a.SignerRoleName = temp.SignerRoleName
    a.SignerExperience = temp.SignerExperience
    return nil
}

// TODO
type authSigners  struct {
    FirstName        *string `json:"firstName,omitempty"`
    MiddleInitial    *string `json:"middleInitial,omitempty"`
    LastName         *string `json:"lastName,omitempty"`
    Email            *string `json:"email,omitempty"`
    Status           *string `json:"status,omitempty"`
    LastUpdated      *string `json:"lastUpdated,omitempty"`
    DateSubmitted    *string `json:"dateSubmitted,omitempty"`
    DateSent         *string `json:"dateSent,omitempty"`
    DateDelivered    *string `json:"dateDelivered,omitempty"`
    DateSigned       *string `json:"dateSigned,omitempty"`
    SignerRoleName   *string `json:"signerRoleName,omitempty"`
    SignerExperience *string `json:"signerExperience,omitempty"`
}
