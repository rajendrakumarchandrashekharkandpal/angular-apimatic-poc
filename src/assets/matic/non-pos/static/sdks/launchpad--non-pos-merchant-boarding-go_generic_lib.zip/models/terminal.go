package models

import (
    "encoding/json"
    "errors"
    "strings"
)

// Terminal represents a Terminal struct.
type Terminal struct {
    TerminalConfigs TerminalConfig             `json:"terminalConfigs"`
    Customizations  []TerminalCustomization    `json:"customizations,omitempty"`
    Products        []Product                  `json:"products"`
    Peripherals     []Peripheral               `json:"peripherals,omitempty"`
    Vendors         []PaymentApplicationVendor `json:"vendors,omitempty"`
    Gateways        []Gateway                  `json:"gateways,omitempty"`
    Supply          []TerminalSupply           `json:"supply,omitempty"`
    Deployment      *TerminalDeployment        `json:"deployment,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for Terminal.
// It customizes the JSON marshaling process for Terminal objects.
func (t *Terminal) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(t.toMap())
}

// toMap converts the Terminal object to a map representation for JSON marshaling.
func (t *Terminal) toMap() map[string]any {
    structMap := make(map[string]any)
    structMap["terminalConfigs"] = t.TerminalConfigs.toMap()
    if t.Customizations != nil {
        structMap["customizations"] = t.Customizations
    }
    structMap["products"] = t.Products
    if t.Peripherals != nil {
        structMap["peripherals"] = t.Peripherals
    }
    if t.Vendors != nil {
        structMap["vendors"] = t.Vendors
    }
    if t.Gateways != nil {
        structMap["gateways"] = t.Gateways
    }
    if t.Supply != nil {
        structMap["supply"] = t.Supply
    }
    if t.Deployment != nil {
        structMap["deployment"] = t.Deployment.toMap()
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for Terminal.
// It customizes the JSON unmarshaling process for Terminal objects.
func (t *Terminal) UnmarshalJSON(input []byte) error {
    var temp terminal
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    err = temp.validate()
    if err != nil {
    	return err
    }
    
    t.TerminalConfigs = *temp.TerminalConfigs
    t.Customizations = temp.Customizations
    t.Products = *temp.Products
    t.Peripherals = temp.Peripherals
    t.Vendors = temp.Vendors
    t.Gateways = temp.Gateways
    t.Supply = temp.Supply
    t.Deployment = temp.Deployment
    return nil
}

// TODO
type terminal  struct {
    TerminalConfigs *TerminalConfig            `json:"terminalConfigs"`
    Customizations  []TerminalCustomization    `json:"customizations,omitempty"`
    Products        *[]Product                 `json:"products"`
    Peripherals     []Peripheral               `json:"peripherals,omitempty"`
    Vendors         []PaymentApplicationVendor `json:"vendors,omitempty"`
    Gateways        []Gateway                  `json:"gateways,omitempty"`
    Supply          []TerminalSupply           `json:"supply,omitempty"`
    Deployment      *TerminalDeployment        `json:"deployment,omitempty"`
}

func (t *terminal) validate() error {
    var errs []string
    if t.TerminalConfigs == nil {
        errs = append(errs, "required field `terminalConfigs` is missing for type `Terminal`")
    }
    if t.Products == nil {
        errs = append(errs, "required field `products` is missing for type `Terminal`")
    }
    if len(errs) == 0 {
        return nil
    }
    return errors.New(strings.Join(errs, "\n"))
}
