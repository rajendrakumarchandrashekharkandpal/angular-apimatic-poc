package models

import (
    "encoding/json"
    "errors"
    "strings"
)

// TerminalDeployment represents a TerminalDeployment struct.
type TerminalDeployment struct {
    EquipmentUpdateDeploy EquipmentUpdateDeployEnum `json:"equipmentUpdateDeploy"`
    TerminalBuildFlag     *bool                     `json:"terminalBuildFlag,omitempty"`
    FrontEndBuildFlag     *bool                     `json:"frontEndBuildFlag,omitempty"`
    SicMerchantFlag       *bool                     `json:"sicMerchantFlag,omitempty"`
    // Special instructions for terminal deployment.
    SpecialInstructions   *string                   `json:"specialInstructions,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for TerminalDeployment.
// It customizes the JSON marshaling process for TerminalDeployment objects.
func (t *TerminalDeployment) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(t.toMap())
}

// toMap converts the TerminalDeployment object to a map representation for JSON marshaling.
func (t *TerminalDeployment) toMap() map[string]any {
    structMap := make(map[string]any)
    structMap["equipmentUpdateDeploy"] = t.EquipmentUpdateDeploy
    if t.TerminalBuildFlag != nil {
        structMap["terminalBuildFlag"] = t.TerminalBuildFlag
    }
    if t.FrontEndBuildFlag != nil {
        structMap["frontEndBuildFlag"] = t.FrontEndBuildFlag
    }
    if t.SicMerchantFlag != nil {
        structMap["sicMerchantFlag"] = t.SicMerchantFlag
    }
    if t.SpecialInstructions != nil {
        structMap["specialInstructions"] = t.SpecialInstructions
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for TerminalDeployment.
// It customizes the JSON unmarshaling process for TerminalDeployment objects.
func (t *TerminalDeployment) UnmarshalJSON(input []byte) error {
    var temp terminalDeployment
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    err = temp.validate()
    if err != nil {
    	return err
    }
    
    t.EquipmentUpdateDeploy = *temp.EquipmentUpdateDeploy
    t.TerminalBuildFlag = temp.TerminalBuildFlag
    t.FrontEndBuildFlag = temp.FrontEndBuildFlag
    t.SicMerchantFlag = temp.SicMerchantFlag
    t.SpecialInstructions = temp.SpecialInstructions
    return nil
}

// TODO
type terminalDeployment  struct {
    EquipmentUpdateDeploy *EquipmentUpdateDeployEnum `json:"equipmentUpdateDeploy"`
    TerminalBuildFlag     *bool                      `json:"terminalBuildFlag,omitempty"`
    FrontEndBuildFlag     *bool                      `json:"frontEndBuildFlag,omitempty"`
    SicMerchantFlag       *bool                      `json:"sicMerchantFlag,omitempty"`
    SpecialInstructions   *string                    `json:"specialInstructions,omitempty"`
}

func (t *terminalDeployment) validate() error {
    var errs []string
    if t.EquipmentUpdateDeploy == nil {
        errs = append(errs, "required field `equipmentUpdateDeploy` is missing for type `TerminalDeployment`")
    }
    if len(errs) == 0 {
        return nil
    }
    return errors.New(strings.Join(errs, "\n"))
}
