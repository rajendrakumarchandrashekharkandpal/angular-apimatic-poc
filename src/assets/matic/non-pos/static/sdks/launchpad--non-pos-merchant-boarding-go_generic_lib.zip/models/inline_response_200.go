package models

import (
    "encoding/json"
)

// InlineResponse200 represents a InlineResponse200 struct.
type InlineResponse200 struct {
    Equipment []InlineResponse200Equipment `json:"equipment,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for InlineResponse200.
// It customizes the JSON marshaling process for InlineResponse200 objects.
func (i *InlineResponse200) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(i.toMap())
}

// toMap converts the InlineResponse200 object to a map representation for JSON marshaling.
func (i *InlineResponse200) toMap() map[string]any {
    structMap := make(map[string]any)
    if i.Equipment != nil {
        structMap["equipment"] = i.Equipment
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for InlineResponse200.
// It customizes the JSON unmarshaling process for InlineResponse200 objects.
func (i *InlineResponse200) UnmarshalJSON(input []byte) error {
    var temp inlineResponse200
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    i.Equipment = temp.Equipment
    return nil
}

// TODO
type inlineResponse200  struct {
    Equipment []InlineResponse200Equipment `json:"equipment,omitempty"`
}
