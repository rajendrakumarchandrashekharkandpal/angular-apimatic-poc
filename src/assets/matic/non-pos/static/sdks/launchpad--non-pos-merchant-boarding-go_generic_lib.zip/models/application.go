package models

import (
    "encoding/json"
    "errors"
    "strings"
)

// Application represents a Application struct.
type Application struct {
    // This is an optional field that can be used by the partners to send a unique Id from their application for reporting purposes.
    ClientTrackingId      *string                       `json:"clientTrackingId,omitempty"`
    BusinessInfo          BusinessInfo1                 `json:"businessInfo"`
    TransactionInfo       TransactionInfo1              `json:"transactionInfo"`
    Owners                []Owner1                      `json:"owners,omitempty"`
    AuthorizedSigners     []AuthorizedSigner1           `json:"authorizedSigners"`
    // Guarantor information. A guarantor is the person whose credit report will be pulled during the underwriting process.
    Guarantors            []Guarantor1                  `json:"guarantors,omitempty"`
    Contacts              []Contact1                    `json:"contacts"`
    Addresses             []Address1                    `json:"addresses"`
    // Bank account collects bank account information from merchant. It is optional till the time of boarding where bank account becomes required along with ddaType, achType, accountNumber, routingNumber & bankName.
    BankAccount           *BankAccount1                 `json:"bankAccount,omitempty"`
    AdvancedSettelment    []AdvancedSettlementInner     `json:"advancedSettelment,omitempty"`
    // The agent who is submitting the deal. It is an optional object. It becomes required, when  partner wants to route deals to their own sales rep. Please work with your integration specialist for route to sales rep functionality.
    SalesAgent            *SalesAgent1                  `json:"salesAgent,omitempty"`
    // The Technical Agent who is going to do setup.
    InstallationContact   *InstallationContact          `json:"installationContact,omitempty"`
    AdditionalInformation []AdditionalInformationObject `json:"additionalInformation,omitempty"`
    // The source of the lead.
    LeadSource            *string                       `json:"leadSource,omitempty"`
    // Used to route a application to a worldpay or partner sales rep.
    RouteToSalesRep       *bool                         `json:"routeToSalesRep,omitempty"`
    ProductsInquiry       []string                      `json:"productsInquiry,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for Application.
// It customizes the JSON marshaling process for Application objects.
func (a *Application) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(a.toMap())
}

// toMap converts the Application object to a map representation for JSON marshaling.
func (a *Application) toMap() map[string]any {
    structMap := make(map[string]any)
    if a.ClientTrackingId != nil {
        structMap["clientTrackingId"] = a.ClientTrackingId
    }
    structMap["businessInfo"] = a.BusinessInfo.toMap()
    structMap["transactionInfo"] = a.TransactionInfo.toMap()
    if a.Owners != nil {
        structMap["owners"] = a.Owners
    }
    structMap["authorizedSigners"] = a.AuthorizedSigners
    if a.Guarantors != nil {
        structMap["guarantors"] = a.Guarantors
    }
    structMap["contacts"] = a.Contacts
    structMap["addresses"] = a.Addresses
    if a.BankAccount != nil {
        structMap["bankAccount"] = a.BankAccount.toMap()
    }
    if a.AdvancedSettelment != nil {
        structMap["advancedSettelment"] = a.AdvancedSettelment
    }
    if a.SalesAgent != nil {
        structMap["salesAgent"] = a.SalesAgent.toMap()
    }
    if a.InstallationContact != nil {
        structMap["installationContact"] = a.InstallationContact.toMap()
    }
    if a.AdditionalInformation != nil {
        structMap["additionalInformation"] = a.AdditionalInformation
    }
    if a.LeadSource != nil {
        structMap["leadSource"] = a.LeadSource
    }
    if a.RouteToSalesRep != nil {
        structMap["routeToSalesRep"] = a.RouteToSalesRep
    }
    if a.ProductsInquiry != nil {
        structMap["productsInquiry"] = a.ProductsInquiry
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for Application.
// It customizes the JSON unmarshaling process for Application objects.
func (a *Application) UnmarshalJSON(input []byte) error {
    var temp application
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    err = temp.validate()
    if err != nil {
    	return err
    }
    
    a.ClientTrackingId = temp.ClientTrackingId
    a.BusinessInfo = *temp.BusinessInfo
    a.TransactionInfo = *temp.TransactionInfo
    a.Owners = temp.Owners
    a.AuthorizedSigners = *temp.AuthorizedSigners
    a.Guarantors = temp.Guarantors
    a.Contacts = *temp.Contacts
    a.Addresses = *temp.Addresses
    a.BankAccount = temp.BankAccount
    a.AdvancedSettelment = temp.AdvancedSettelment
    a.SalesAgent = temp.SalesAgent
    a.InstallationContact = temp.InstallationContact
    a.AdditionalInformation = temp.AdditionalInformation
    a.LeadSource = temp.LeadSource
    a.RouteToSalesRep = temp.RouteToSalesRep
    a.ProductsInquiry = temp.ProductsInquiry
    return nil
}

// TODO
type application  struct {
    ClientTrackingId      *string                       `json:"clientTrackingId,omitempty"`
    BusinessInfo          *BusinessInfo1                `json:"businessInfo"`
    TransactionInfo       *TransactionInfo1             `json:"transactionInfo"`
    Owners                []Owner1                      `json:"owners,omitempty"`
    AuthorizedSigners     *[]AuthorizedSigner1          `json:"authorizedSigners"`
    Guarantors            []Guarantor1                  `json:"guarantors,omitempty"`
    Contacts              *[]Contact1                   `json:"contacts"`
    Addresses             *[]Address1                   `json:"addresses"`
    BankAccount           *BankAccount1                 `json:"bankAccount,omitempty"`
    AdvancedSettelment    []AdvancedSettlementInner     `json:"advancedSettelment,omitempty"`
    SalesAgent            *SalesAgent1                  `json:"salesAgent,omitempty"`
    InstallationContact   *InstallationContact          `json:"installationContact,omitempty"`
    AdditionalInformation []AdditionalInformationObject `json:"additionalInformation,omitempty"`
    LeadSource            *string                       `json:"leadSource,omitempty"`
    RouteToSalesRep       *bool                         `json:"routeToSalesRep,omitempty"`
    ProductsInquiry       []string                      `json:"productsInquiry,omitempty"`
}

func (a *application) validate() error {
    var errs []string
    if a.BusinessInfo == nil {
        errs = append(errs, "required field `businessInfo` is missing for type `Application`")
    }
    if a.TransactionInfo == nil {
        errs = append(errs, "required field `transactionInfo` is missing for type `Application`")
    }
    if a.AuthorizedSigners == nil {
        errs = append(errs, "required field `authorizedSigners` is missing for type `Application`")
    }
    if a.Contacts == nil {
        errs = append(errs, "required field `contacts` is missing for type `Application`")
    }
    if a.Addresses == nil {
        errs = append(errs, "required field `addresses` is missing for type `Application`")
    }
    if len(errs) == 0 {
        return nil
    }
    return errors.New(strings.Join(errs, "\n"))
}
