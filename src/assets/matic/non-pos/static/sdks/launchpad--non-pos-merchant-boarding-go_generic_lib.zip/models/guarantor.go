package models

import (
    "encoding/json"
    "errors"
    "log"
    "strings"
    "time"
)

// Guarantor represents a Guarantor struct.
type Guarantor struct {
    Type                string                  `json:"type"`
    // Required for AMEX acquired merchants otherwise optional.
    Title               *string                 `json:"title,omitempty"`
    // First name. Region based validations will be applied to this field.
    FirstName           string                  `json:"firstName"`
    // Middle initial.
    MiddleInitial       *string                 `json:"middleInitial,omitempty"`
    // Last name. Region based validations will be applied to this field.
    LastName            string                  `json:"lastName"`
    // 10-digit phone number of the format  5131234567.
    PhoneNumber         string                  `json:"phoneNumber"`
    // Phone number extension. Up to 8 digits of the format 12345678.
    PhoneNumberExt      *string                 `json:"phoneNumberExt,omitempty"`
    // Phone type.
    PhoneType           *PhoneTypeEnum          `json:"phoneType,omitempty"`
    // 10-digit alternate phone number of the format  5131234567.
    AlternatePhone      *string                 `json:"alternatePhone,omitempty"`
    // Alternate phone type.
    AlternatePhoneType  *AlternatePhoneTypeEnum `json:"alternatePhoneType,omitempty"`
    // 10-digit fax number of the format 5131234567
    FaxNumber           *string                 `json:"faxNumber,omitempty"`
    // Email address of the contact. Must have @ and a .
    Email               string                  `json:"email"`
    // Ownership stake percentage.
    OwnershipPercentage *int                    `json:"ownershipPercentage,omitempty"`
    // Social security number. Do not include dashes.
    Ssn                 *string                 `json:"ssn,omitempty"`
    // Date of Birth (CCYY-MM-DD). Must be at least 18 years old.
    Dob                 *time.Time              `json:"dob,omitempty"`
    // Address Line 1. Field for house number, street and direction.
    AddressLine1        string                  `json:"addressLine1"`
    // Address Line 2. Field for apartment or suite numbers, etc.
    AddressLine2        *string                 `json:"addressLine2,omitempty"`
    City                string                  `json:"city"`
    // Valid US state, commonwealth, and territory codes are allowed.
    State               StateEnum               `json:"state"`
    // Only United States is allowed.
    Country             string                  `json:"country"`
    // Postal code / zip code. The postal code must be valid for the address' country code.
    PostalCode          string                  `json:"postalCode"`
    // Postal code / zip code extension.  The postal code extension must be valid for the address' country code.
    PostalCodeExtension *string                 `json:"postalCodeExtension,omitempty"`
    // Optional. If any attribute in the identification object is populated then at least idNumber and idType are required.
    Identification      []Identification        `json:"identification,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for Guarantor.
// It customizes the JSON marshaling process for Guarantor objects.
func (g *Guarantor) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(g.toMap())
}

// toMap converts the Guarantor object to a map representation for JSON marshaling.
func (g *Guarantor) toMap() map[string]any {
    structMap := make(map[string]any)
    structMap["type"] = g.Type
    if g.Title != nil {
        structMap["title"] = g.Title
    }
    structMap["firstName"] = g.FirstName
    if g.MiddleInitial != nil {
        structMap["middleInitial"] = g.MiddleInitial
    }
    structMap["lastName"] = g.LastName
    structMap["phoneNumber"] = g.PhoneNumber
    if g.PhoneNumberExt != nil {
        structMap["phoneNumberExt"] = g.PhoneNumberExt
    }
    if g.PhoneType != nil {
        structMap["phoneType"] = g.PhoneType
    }
    if g.AlternatePhone != nil {
        structMap["alternatePhone"] = g.AlternatePhone
    }
    if g.AlternatePhoneType != nil {
        structMap["alternatePhoneType"] = g.AlternatePhoneType
    }
    if g.FaxNumber != nil {
        structMap["faxNumber"] = g.FaxNumber
    }
    structMap["email"] = g.Email
    if g.OwnershipPercentage != nil {
        structMap["ownershipPercentage"] = g.OwnershipPercentage
    }
    if g.Ssn != nil {
        structMap["ssn"] = g.Ssn
    }
    if g.Dob != nil {
        structMap["dob"] = g.Dob.Format(DEFAULT_DATE)
    }
    structMap["addressLine1"] = g.AddressLine1
    if g.AddressLine2 != nil {
        structMap["addressLine2"] = g.AddressLine2
    }
    structMap["city"] = g.City
    structMap["state"] = g.State
    structMap["country"] = g.Country
    structMap["postalCode"] = g.PostalCode
    if g.PostalCodeExtension != nil {
        structMap["postalCodeExtension"] = g.PostalCodeExtension
    }
    if g.Identification != nil {
        structMap["identification"] = g.Identification
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for Guarantor.
// It customizes the JSON unmarshaling process for Guarantor objects.
func (g *Guarantor) UnmarshalJSON(input []byte) error {
    var temp guarantor
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    err = temp.validate()
    if err != nil {
    	return err
    }
    
    g.Type = *temp.Type
    g.Title = temp.Title
    g.FirstName = *temp.FirstName
    g.MiddleInitial = temp.MiddleInitial
    g.LastName = *temp.LastName
    g.PhoneNumber = *temp.PhoneNumber
    g.PhoneNumberExt = temp.PhoneNumberExt
    g.PhoneType = temp.PhoneType
    g.AlternatePhone = temp.AlternatePhone
    g.AlternatePhoneType = temp.AlternatePhoneType
    g.FaxNumber = temp.FaxNumber
    g.Email = *temp.Email
    g.OwnershipPercentage = temp.OwnershipPercentage
    g.Ssn = temp.Ssn
    if temp.Dob != nil {
        DobVal, err := time.Parse(DEFAULT_DATE, *temp.Dob)
        if err != nil {
            log.Fatalf("Cannot Parse dob as % s format.", DEFAULT_DATE)
        }
        g.Dob = &DobVal
    }
    g.AddressLine1 = *temp.AddressLine1
    g.AddressLine2 = temp.AddressLine2
    g.City = *temp.City
    g.State = *temp.State
    g.Country = *temp.Country
    g.PostalCode = *temp.PostalCode
    g.PostalCodeExtension = temp.PostalCodeExtension
    g.Identification = temp.Identification
    return nil
}

// TODO
type guarantor  struct {
    Type                *string                 `json:"type"`
    Title               *string                 `json:"title,omitempty"`
    FirstName           *string                 `json:"firstName"`
    MiddleInitial       *string                 `json:"middleInitial,omitempty"`
    LastName            *string                 `json:"lastName"`
    PhoneNumber         *string                 `json:"phoneNumber"`
    PhoneNumberExt      *string                 `json:"phoneNumberExt,omitempty"`
    PhoneType           *PhoneTypeEnum          `json:"phoneType,omitempty"`
    AlternatePhone      *string                 `json:"alternatePhone,omitempty"`
    AlternatePhoneType  *AlternatePhoneTypeEnum `json:"alternatePhoneType,omitempty"`
    FaxNumber           *string                 `json:"faxNumber,omitempty"`
    Email               *string                 `json:"email"`
    OwnershipPercentage *int                    `json:"ownershipPercentage,omitempty"`
    Ssn                 *string                 `json:"ssn,omitempty"`
    Dob                 *string                 `json:"dob,omitempty"`
    AddressLine1        *string                 `json:"addressLine1"`
    AddressLine2        *string                 `json:"addressLine2,omitempty"`
    City                *string                 `json:"city"`
    State               *StateEnum              `json:"state"`
    Country             *string                 `json:"country"`
    PostalCode          *string                 `json:"postalCode"`
    PostalCodeExtension *string                 `json:"postalCodeExtension,omitempty"`
    Identification      []Identification        `json:"identification,omitempty"`
}

func (g *guarantor) validate() error {
    var errs []string
    if g.Type == nil {
        errs = append(errs, "required field `type` is missing for type `Guarantor`")
    }
    if g.FirstName == nil {
        errs = append(errs, "required field `firstName` is missing for type `Guarantor`")
    }
    if g.LastName == nil {
        errs = append(errs, "required field `lastName` is missing for type `Guarantor`")
    }
    if g.PhoneNumber == nil {
        errs = append(errs, "required field `phoneNumber` is missing for type `Guarantor`")
    }
    if g.Email == nil {
        errs = append(errs, "required field `email` is missing for type `Guarantor`")
    }
    if g.AddressLine1 == nil {
        errs = append(errs, "required field `addressLine1` is missing for type `Guarantor`")
    }
    if g.City == nil {
        errs = append(errs, "required field `city` is missing for type `Guarantor`")
    }
    if g.State == nil {
        errs = append(errs, "required field `state` is missing for type `Guarantor`")
    }
    if g.Country == nil {
        errs = append(errs, "required field `country` is missing for type `Guarantor`")
    }
    if g.PostalCode == nil {
        errs = append(errs, "required field `postalCode` is missing for type `Guarantor`")
    }
    if len(errs) == 0 {
        return nil
    }
    return errors.New(strings.Join(errs, "\n"))
}
