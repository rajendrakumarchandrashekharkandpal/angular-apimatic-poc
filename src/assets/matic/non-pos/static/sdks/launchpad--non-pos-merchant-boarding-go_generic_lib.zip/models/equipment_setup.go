package models

import (
    "encoding/json"
)

// EquipmentSetup represents a EquipmentSetup struct.
type EquipmentSetup struct {
    // The speed you would like the equipment to be shipped.
    ShippingOption *ShippingOptionEnum `json:"shippingOption,omitempty"`
    Terminals      []Terminal          `json:"terminals,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for EquipmentSetup.
// It customizes the JSON marshaling process for EquipmentSetup objects.
func (e *EquipmentSetup) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(e.toMap())
}

// toMap converts the EquipmentSetup object to a map representation for JSON marshaling.
func (e *EquipmentSetup) toMap() map[string]any {
    structMap := make(map[string]any)
    if e.ShippingOption != nil {
        structMap["shippingOption"] = e.ShippingOption
    }
    if e.Terminals != nil {
        structMap["terminals"] = e.Terminals
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for EquipmentSetup.
// It customizes the JSON unmarshaling process for EquipmentSetup objects.
func (e *EquipmentSetup) UnmarshalJSON(input []byte) error {
    var temp equipmentSetup
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    e.ShippingOption = temp.ShippingOption
    e.Terminals = temp.Terminals
    return nil
}

// TODO
type equipmentSetup  struct {
    ShippingOption *ShippingOptionEnum `json:"shippingOption,omitempty"`
    Terminals      []Terminal          `json:"terminals,omitempty"`
}
