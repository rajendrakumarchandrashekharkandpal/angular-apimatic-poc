package models

import (
    "encoding/json"
    "errors"
    "log"
    "strings"
    "time"
)

// BusinessInfo represents a BusinessInfo struct.
type BusinessInfo struct {
    // The merchant name they do business as.  Generally with what their customers know the business.
    DbaName                 string                        `json:"dbaName"`
    // Business Legal Name as filed with the IRS.
    LegalName               string                        `json:"legalName"`
    // Required. OwnershipType defines the type of the Merchant Organization, and drives the requirements for data collections of beneficial and control owners under U.S. Financial Crimes Enforcement Network (FinCEN).
    OwnershipType           OwnershipTypeEnum             `json:"ownershipType"`
    // SIC Code / MCC Code (Merchant Category Code) is the code use to describe what the merchant is selling. Use MCC look up call to search valid codes, with sort and long description to find the MCC that most closely matches what the merchant is selling.
    MccCode                 string                        `json:"mccCode"`
    // Date (CCYY-MM-DD) on which the merchant's business was established.
    BusinessEstablishedDate *time.Time                    `json:"businessEstablishedDate,omitempty"`
    // The URL of the merchant's website.
    WebsiteUrl              *string                       `json:"websiteUrl,omitempty"`
    // Number of current locations.
    NumberOfLocation        *int                          `json:"numberOfLocation,omitempty"`
    // The Federal Tax ID is the business Tax Identification Number (TIN) or Employer Identification Number (EIN). If the business is a sole proprietor they may use the social security number of the sole proprietor.
    FederalTaxId            *string                       `json:"federalTaxId,omitempty"`
    // The ways in which the business is accepting payments. Multiple options may be selected. 'In person', would be card present at a brick and mortar store, 'onlinesite' would be card not present use on an ecommerce website, and 'phoneormailorder' would be card not present used for mail and telephone orders.
    PaymentAcceptanceMethod []PaymentAcceptanceMethodEnum `json:"paymentAcceptanceMethod,omitempty"`
    // Indication if the merchant has had an account data compromise.
    Pciadc                  *PciadcEnum                   `json:"pciadc,omitempty"`
    // Indictor showing if the merchant is compliant or not with the Payment Card Industry Data Security Standards.
    PcidssValidated         *PcidssValidatedEnum          `json:"pcidssValidated,omitempty"`
    // Type of area surroundning the business.
    SurroundingArea         *SurroundingAreaEnum          `json:"surroundingArea,omitempty"`
    // Type of goods or services sold.
    ProductServiceSold      *string                       `json:"productServiceSold,omitempty"`
    // Years the business has been operating in their current location.
    OwnAddYears             *int                          `json:"ownAddYears,omitempty"`
    // Inital contract term in months.
    LengthOfContract        *string                       `json:"lengthOfContract,omitempty"`
    // Does the business operate seasonally?
    Seasonal                *SeasonalEnum                 `json:"seasonal,omitempty"`
    // The months during which the business is actively operating.
    ActiveMonths            []ActiveMonthEnum             `json:"activeMonths,omitempty"`
    // Does the business offer warranties, dues, subscriptions, memberships, or other extended services?
    Warranty                *WarrantyEnum                 `json:"warranty,omitempty"`
    // The business's return policy.
    ReturnPolicy            *ReturnPolicyEnum             `json:"returnPolicy,omitempty"`
    TaxExempt               *TaxExemptEnum                `json:"taxExempt,omitempty"`
    // Does the business accept credit cards?
    AcceptCreditCards       *AcceptCreditCardsEnum        `json:"acceptCreditCards,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for BusinessInfo.
// It customizes the JSON marshaling process for BusinessInfo objects.
func (b *BusinessInfo) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(b.toMap())
}

// toMap converts the BusinessInfo object to a map representation for JSON marshaling.
func (b *BusinessInfo) toMap() map[string]any {
    structMap := make(map[string]any)
    structMap["dbaName"] = b.DbaName
    structMap["legalName"] = b.LegalName
    structMap["ownershipType"] = b.OwnershipType
    structMap["mccCode"] = b.MccCode
    if b.BusinessEstablishedDate != nil {
        structMap["businessEstablishedDate"] = b.BusinessEstablishedDate.Format(DEFAULT_DATE)
    }
    if b.WebsiteUrl != nil {
        structMap["websiteUrl"] = b.WebsiteUrl
    }
    if b.NumberOfLocation != nil {
        structMap["numberOfLocation"] = b.NumberOfLocation
    }
    if b.FederalTaxId != nil {
        structMap["federalTaxId"] = b.FederalTaxId
    }
    if b.PaymentAcceptanceMethod != nil {
        structMap["paymentAcceptanceMethod"] = b.PaymentAcceptanceMethod
    }
    if b.Pciadc != nil {
        structMap["pciadc"] = b.Pciadc
    }
    if b.PcidssValidated != nil {
        structMap["pcidssValidated"] = b.PcidssValidated
    }
    if b.SurroundingArea != nil {
        structMap["surroundingArea"] = b.SurroundingArea
    }
    if b.ProductServiceSold != nil {
        structMap["productServiceSold"] = b.ProductServiceSold
    }
    if b.OwnAddYears != nil {
        structMap["ownAddYears"] = b.OwnAddYears
    }
    if b.LengthOfContract != nil {
        structMap["lengthOfContract"] = b.LengthOfContract
    }
    if b.Seasonal != nil {
        structMap["seasonal"] = b.Seasonal
    }
    if b.ActiveMonths != nil {
        structMap["activeMonths"] = b.ActiveMonths
    }
    if b.Warranty != nil {
        structMap["warranty"] = b.Warranty
    }
    if b.ReturnPolicy != nil {
        structMap["returnPolicy"] = b.ReturnPolicy
    }
    if b.TaxExempt != nil {
        structMap["taxExempt"] = b.TaxExempt
    }
    if b.AcceptCreditCards != nil {
        structMap["acceptCreditCards"] = b.AcceptCreditCards
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for BusinessInfo.
// It customizes the JSON unmarshaling process for BusinessInfo objects.
func (b *BusinessInfo) UnmarshalJSON(input []byte) error {
    var temp businessInfo
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    err = temp.validate()
    if err != nil {
    	return err
    }
    
    b.DbaName = *temp.DbaName
    b.LegalName = *temp.LegalName
    b.OwnershipType = *temp.OwnershipType
    b.MccCode = *temp.MccCode
    if temp.BusinessEstablishedDate != nil {
        BusinessEstablishedDateVal, err := time.Parse(DEFAULT_DATE, *temp.BusinessEstablishedDate)
        if err != nil {
            log.Fatalf("Cannot Parse businessEstablishedDate as % s format.", DEFAULT_DATE)
        }
        b.BusinessEstablishedDate = &BusinessEstablishedDateVal
    }
    b.WebsiteUrl = temp.WebsiteUrl
    b.NumberOfLocation = temp.NumberOfLocation
    b.FederalTaxId = temp.FederalTaxId
    b.PaymentAcceptanceMethod = temp.PaymentAcceptanceMethod
    b.Pciadc = temp.Pciadc
    b.PcidssValidated = temp.PcidssValidated
    b.SurroundingArea = temp.SurroundingArea
    b.ProductServiceSold = temp.ProductServiceSold
    b.OwnAddYears = temp.OwnAddYears
    b.LengthOfContract = temp.LengthOfContract
    b.Seasonal = temp.Seasonal
    b.ActiveMonths = temp.ActiveMonths
    b.Warranty = temp.Warranty
    b.ReturnPolicy = temp.ReturnPolicy
    b.TaxExempt = temp.TaxExempt
    b.AcceptCreditCards = temp.AcceptCreditCards
    return nil
}

// TODO
type businessInfo  struct {
    DbaName                 *string                       `json:"dbaName"`
    LegalName               *string                       `json:"legalName"`
    OwnershipType           *OwnershipTypeEnum            `json:"ownershipType"`
    MccCode                 *string                       `json:"mccCode"`
    BusinessEstablishedDate *string                       `json:"businessEstablishedDate,omitempty"`
    WebsiteUrl              *string                       `json:"websiteUrl,omitempty"`
    NumberOfLocation        *int                          `json:"numberOfLocation,omitempty"`
    FederalTaxId            *string                       `json:"federalTaxId,omitempty"`
    PaymentAcceptanceMethod []PaymentAcceptanceMethodEnum `json:"paymentAcceptanceMethod,omitempty"`
    Pciadc                  *PciadcEnum                   `json:"pciadc,omitempty"`
    PcidssValidated         *PcidssValidatedEnum          `json:"pcidssValidated,omitempty"`
    SurroundingArea         *SurroundingAreaEnum          `json:"surroundingArea,omitempty"`
    ProductServiceSold      *string                       `json:"productServiceSold,omitempty"`
    OwnAddYears             *int                          `json:"ownAddYears,omitempty"`
    LengthOfContract        *string                       `json:"lengthOfContract,omitempty"`
    Seasonal                *SeasonalEnum                 `json:"seasonal,omitempty"`
    ActiveMonths            []ActiveMonthEnum             `json:"activeMonths,omitempty"`
    Warranty                *WarrantyEnum                 `json:"warranty,omitempty"`
    ReturnPolicy            *ReturnPolicyEnum             `json:"returnPolicy,omitempty"`
    TaxExempt               *TaxExemptEnum                `json:"taxExempt,omitempty"`
    AcceptCreditCards       *AcceptCreditCardsEnum        `json:"acceptCreditCards,omitempty"`
}

func (b *businessInfo) validate() error {
    var errs []string
    if b.DbaName == nil {
        errs = append(errs, "required field `dbaName` is missing for type `BusinessInfo`")
    }
    if b.LegalName == nil {
        errs = append(errs, "required field `legalName` is missing for type `BusinessInfo`")
    }
    if b.OwnershipType == nil {
        errs = append(errs, "required field `ownershipType` is missing for type `BusinessInfo`")
    }
    if b.MccCode == nil {
        errs = append(errs, "required field `mccCode` is missing for type `BusinessInfo`")
    }
    if len(errs) == 0 {
        return nil
    }
    return errors.New(strings.Join(errs, "\n"))
}
