package models

import (
    "encoding/json"
)

// AdditionalConfigurationCustomization represents a AdditionalConfigurationCustomization struct.
type AdditionalConfigurationCustomization struct {
    // Customization Id is internally populated from a master list.
    CustomizationId           *string                    `json:"customizationId,omitempty"`
    // type of customization
    CustomizationType         *string                    `json:"customizationType,omitempty"`
    // Whether or not used in product matrix
    UseProductMatrix          *string                    `json:"useProductMatrix,omitempty"`
    // unique ID for the product
    ProductId                 *string                    `json:"productId,omitempty"`
    // product code
    Code                      *string                    `json:"code,omitempty"`
    CustomizationCodeDetails  []CustomizationCodeDetails `json:"customizationCodeDetails,omitempty"`
    // Actual Customization Value
    CustomizationValue        *string                    `json:"customizationValue,omitempty"`
    // Length of the customization value
    CustomizationFieldLength  *string                    `json:"customizationFieldLength,omitempty"`
    // Number of decimal places
    CustomizationDecimalPlace *string                    `json:"customizationDecimalPlace,omitempty"`
    // Minimum Value. Only applicable if the customization value is a number
    CustomizationMinValue     *string                    `json:"customizationMinValue,omitempty"`
    // Maximum Value. Only applicable if the customization value is a number
    CustomizationMaxValue     *string                    `json:"customizationMaxValue,omitempty"`
    // All characters allowed for customization. Only applicable if the customization value is a string.
    CharactersAllowed         *string                    `json:"charactersAllowed,omitempty"`
    // customization rule
    Rule                      *string                    `json:"rule,omitempty"`
    // Regular expression to validate the customization value
    Regex                     *string                    `json:"regex,omitempty"`
    // Applicable in a multiple merchant situation
    MultiMerchantFlag         *bool                      `json:"multiMerchantFlag,omitempty"`
    // Description of the customization
    ShortDescription          *string                    `json:"shortDescription,omitempty"`
    // Verbose description of the customiztion
    LongDescription           *string                    `json:"longDescription,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for AdditionalConfigurationCustomization.
// It customizes the JSON marshaling process for AdditionalConfigurationCustomization objects.
func (a *AdditionalConfigurationCustomization) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(a.toMap())
}

// toMap converts the AdditionalConfigurationCustomization object to a map representation for JSON marshaling.
func (a *AdditionalConfigurationCustomization) toMap() map[string]any {
    structMap := make(map[string]any)
    if a.CustomizationId != nil {
        structMap["customizationId"] = a.CustomizationId
    }
    if a.CustomizationType != nil {
        structMap["customizationType"] = a.CustomizationType
    }
    if a.UseProductMatrix != nil {
        structMap["useProductMatrix"] = a.UseProductMatrix
    }
    if a.ProductId != nil {
        structMap["productId"] = a.ProductId
    }
    if a.Code != nil {
        structMap["code"] = a.Code
    }
    if a.CustomizationCodeDetails != nil {
        structMap["customizationCodeDetails"] = a.CustomizationCodeDetails
    }
    if a.CustomizationValue != nil {
        structMap["customizationValue"] = a.CustomizationValue
    }
    if a.CustomizationFieldLength != nil {
        structMap["customizationFieldLength"] = a.CustomizationFieldLength
    }
    if a.CustomizationDecimalPlace != nil {
        structMap["customizationDecimalPlace"] = a.CustomizationDecimalPlace
    }
    if a.CustomizationMinValue != nil {
        structMap["customizationMinValue"] = a.CustomizationMinValue
    }
    if a.CustomizationMaxValue != nil {
        structMap["customizationMaxValue"] = a.CustomizationMaxValue
    }
    if a.CharactersAllowed != nil {
        structMap["charactersAllowed"] = a.CharactersAllowed
    }
    if a.Rule != nil {
        structMap["rule"] = a.Rule
    }
    if a.Regex != nil {
        structMap["regex"] = a.Regex
    }
    if a.MultiMerchantFlag != nil {
        structMap["multiMerchantFlag"] = a.MultiMerchantFlag
    }
    if a.ShortDescription != nil {
        structMap["shortDescription"] = a.ShortDescription
    }
    if a.LongDescription != nil {
        structMap["longDescription"] = a.LongDescription
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for AdditionalConfigurationCustomization.
// It customizes the JSON unmarshaling process for AdditionalConfigurationCustomization objects.
func (a *AdditionalConfigurationCustomization) UnmarshalJSON(input []byte) error {
    var temp additionalConfigurationCustomization
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    a.CustomizationId = temp.CustomizationId
    a.CustomizationType = temp.CustomizationType
    a.UseProductMatrix = temp.UseProductMatrix
    a.ProductId = temp.ProductId
    a.Code = temp.Code
    a.CustomizationCodeDetails = temp.CustomizationCodeDetails
    a.CustomizationValue = temp.CustomizationValue
    a.CustomizationFieldLength = temp.CustomizationFieldLength
    a.CustomizationDecimalPlace = temp.CustomizationDecimalPlace
    a.CustomizationMinValue = temp.CustomizationMinValue
    a.CustomizationMaxValue = temp.CustomizationMaxValue
    a.CharactersAllowed = temp.CharactersAllowed
    a.Rule = temp.Rule
    a.Regex = temp.Regex
    a.MultiMerchantFlag = temp.MultiMerchantFlag
    a.ShortDescription = temp.ShortDescription
    a.LongDescription = temp.LongDescription
    return nil
}

// TODO
type additionalConfigurationCustomization  struct {
    CustomizationId           *string                    `json:"customizationId,omitempty"`
    CustomizationType         *string                    `json:"customizationType,omitempty"`
    UseProductMatrix          *string                    `json:"useProductMatrix,omitempty"`
    ProductId                 *string                    `json:"productId,omitempty"`
    Code                      *string                    `json:"code,omitempty"`
    CustomizationCodeDetails  []CustomizationCodeDetails `json:"customizationCodeDetails,omitempty"`
    CustomizationValue        *string                    `json:"customizationValue,omitempty"`
    CustomizationFieldLength  *string                    `json:"customizationFieldLength,omitempty"`
    CustomizationDecimalPlace *string                    `json:"customizationDecimalPlace,omitempty"`
    CustomizationMinValue     *string                    `json:"customizationMinValue,omitempty"`
    CustomizationMaxValue     *string                    `json:"customizationMaxValue,omitempty"`
    CharactersAllowed         *string                    `json:"charactersAllowed,omitempty"`
    Rule                      *string                    `json:"rule,omitempty"`
    Regex                     *string                    `json:"regex,omitempty"`
    MultiMerchantFlag         *bool                      `json:"multiMerchantFlag,omitempty"`
    ShortDescription          *string                    `json:"shortDescription,omitempty"`
    LongDescription           *string                    `json:"longDescription,omitempty"`
}
