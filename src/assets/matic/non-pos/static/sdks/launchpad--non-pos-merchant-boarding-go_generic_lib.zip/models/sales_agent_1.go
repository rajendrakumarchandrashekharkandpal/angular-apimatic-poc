package models

import (
    "encoding/json"
    "errors"
    "strings"
)

// SalesAgent1 represents a SalesAgent1 struct.
// The agent who is submitting the deal. It is an optional object. It becomes required, when  partner wants to route deals to their own sales rep. Please work with your integration specialist for route to sales rep functionality.
type SalesAgent1 struct {
    // Id for the Sales Contact.
    Id                *string `json:"id,omitempty"`
    // Sales agent's first name.
    FirstName         string  `json:"firstName"`
    // Sales agent's last name.
    LastName          string  `json:"lastName"`
    // Sales agent's 10-digit phone number of the format 5131234567.
    MobilePhoneNumber *string `json:"mobilePhoneNumber,omitempty"`
    // Sales agent's email address.  Must have @ and a .
    Email             string  `json:"email"`
}

// MarshalJSON implements the json.Marshaler interface for SalesAgent1.
// It customizes the JSON marshaling process for SalesAgent1 objects.
func (s *SalesAgent1) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(s.toMap())
}

// toMap converts the SalesAgent1 object to a map representation for JSON marshaling.
func (s *SalesAgent1) toMap() map[string]any {
    structMap := make(map[string]any)
    if s.Id != nil {
        structMap["id"] = s.Id
    }
    structMap["firstName"] = s.FirstName
    structMap["lastName"] = s.LastName
    if s.MobilePhoneNumber != nil {
        structMap["mobilePhoneNumber"] = s.MobilePhoneNumber
    }
    structMap["email"] = s.Email
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for SalesAgent1.
// It customizes the JSON unmarshaling process for SalesAgent1 objects.
func (s *SalesAgent1) UnmarshalJSON(input []byte) error {
    var temp salesAgent1
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    err = temp.validate()
    if err != nil {
    	return err
    }
    
    s.Id = temp.Id
    s.FirstName = *temp.FirstName
    s.LastName = *temp.LastName
    s.MobilePhoneNumber = temp.MobilePhoneNumber
    s.Email = *temp.Email
    return nil
}

// TODO
type salesAgent1  struct {
    Id                *string `json:"id,omitempty"`
    FirstName         *string `json:"firstName"`
    LastName          *string `json:"lastName"`
    MobilePhoneNumber *string `json:"mobilePhoneNumber,omitempty"`
    Email             *string `json:"email"`
}

func (s *salesAgent1) validate() error {
    var errs []string
    if s.FirstName == nil {
        errs = append(errs, "required field `firstName` is missing for type `SalesAgent_1`")
    }
    if s.LastName == nil {
        errs = append(errs, "required field `lastName` is missing for type `SalesAgent_1`")
    }
    if s.Email == nil {
        errs = append(errs, "required field `email` is missing for type `SalesAgent_1`")
    }
    if len(errs) == 0 {
        return nil
    }
    return errors.New(strings.Join(errs, "\n"))
}
