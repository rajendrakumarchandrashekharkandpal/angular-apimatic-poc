package models

import (
    "encoding/json"
)

// CustomizationCodeDetails represents a CustomizationCodeDetails struct.
type CustomizationCodeDetails struct {
    // customization code
    Value            *string `json:"value,omitempty"`
    // short description of the customization code
    ShortDescription *string `json:"shortDescription,omitempty"`
    // long description of the customization code
    LongDescription  *string `json:"longDescription,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for CustomizationCodeDetails.
// It customizes the JSON marshaling process for CustomizationCodeDetails objects.
func (c *CustomizationCodeDetails) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(c.toMap())
}

// toMap converts the CustomizationCodeDetails object to a map representation for JSON marshaling.
func (c *CustomizationCodeDetails) toMap() map[string]any {
    structMap := make(map[string]any)
    if c.Value != nil {
        structMap["value"] = c.Value
    }
    if c.ShortDescription != nil {
        structMap["shortDescription"] = c.ShortDescription
    }
    if c.LongDescription != nil {
        structMap["longDescription"] = c.LongDescription
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for CustomizationCodeDetails.
// It customizes the JSON unmarshaling process for CustomizationCodeDetails objects.
func (c *CustomizationCodeDetails) UnmarshalJSON(input []byte) error {
    var temp customizationCodeDetails
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    c.Value = temp.Value
    c.ShortDescription = temp.ShortDescription
    c.LongDescription = temp.LongDescription
    return nil
}

// TODO
type customizationCodeDetails  struct {
    Value            *string `json:"value,omitempty"`
    ShortDescription *string `json:"shortDescription,omitempty"`
    LongDescription  *string `json:"longDescription,omitempty"`
}
