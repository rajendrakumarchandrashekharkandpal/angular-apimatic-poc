package models

import (
    "encoding/json"
)

// TerminalCustomization represents a TerminalCustomization struct.
type TerminalCustomization struct {
    // Customization ID is internally populated from a master list.
    CustomizationId         *string `json:"customizationId,omitempty"`
    CustomizationName       *string `json:"customizationName,omitempty"`
    CustomizationFieldValue *string `json:"customizationFieldValue,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for TerminalCustomization.
// It customizes the JSON marshaling process for TerminalCustomization objects.
func (t *TerminalCustomization) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(t.toMap())
}

// toMap converts the TerminalCustomization object to a map representation for JSON marshaling.
func (t *TerminalCustomization) toMap() map[string]any {
    structMap := make(map[string]any)
    if t.CustomizationId != nil {
        structMap["customizationId"] = t.CustomizationId
    }
    if t.CustomizationName != nil {
        structMap["customizationName"] = t.CustomizationName
    }
    if t.CustomizationFieldValue != nil {
        structMap["customizationFieldValue"] = t.CustomizationFieldValue
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for TerminalCustomization.
// It customizes the JSON unmarshaling process for TerminalCustomization objects.
func (t *TerminalCustomization) UnmarshalJSON(input []byte) error {
    var temp terminalCustomization
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    t.CustomizationId = temp.CustomizationId
    t.CustomizationName = temp.CustomizationName
    t.CustomizationFieldValue = temp.CustomizationFieldValue
    return nil
}

// TODO
type terminalCustomization  struct {
    CustomizationId         *string `json:"customizationId,omitempty"`
    CustomizationName       *string `json:"customizationName,omitempty"`
    CustomizationFieldValue *string `json:"customizationFieldValue,omitempty"`
}
