package models

import (
    "encoding/json"
)

// AdditionalConfigurationsResponse represents a AdditionalConfigurationsResponse struct.
type AdditionalConfigurationsResponse struct {
    Customizations []AdditionalConfigurationCustomization `json:"customizations,omitempty"`
    Peripherals    []AdditionalConfigurationPeripheral    `json:"peripherals,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for AdditionalConfigurationsResponse.
// It customizes the JSON marshaling process for AdditionalConfigurationsResponse objects.
func (a *AdditionalConfigurationsResponse) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(a.toMap())
}

// toMap converts the AdditionalConfigurationsResponse object to a map representation for JSON marshaling.
func (a *AdditionalConfigurationsResponse) toMap() map[string]any {
    structMap := make(map[string]any)
    if a.Customizations != nil {
        structMap["customizations"] = a.Customizations
    }
    if a.Peripherals != nil {
        structMap["peripherals"] = a.Peripherals
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for AdditionalConfigurationsResponse.
// It customizes the JSON unmarshaling process for AdditionalConfigurationsResponse objects.
func (a *AdditionalConfigurationsResponse) UnmarshalJSON(input []byte) error {
    var temp additionalConfigurationsResponse
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    a.Customizations = temp.Customizations
    a.Peripherals = temp.Peripherals
    return nil
}

// TODO
type additionalConfigurationsResponse  struct {
    Customizations []AdditionalConfigurationCustomization `json:"customizations,omitempty"`
    Peripherals    []AdditionalConfigurationPeripheral    `json:"peripherals,omitempty"`
}
