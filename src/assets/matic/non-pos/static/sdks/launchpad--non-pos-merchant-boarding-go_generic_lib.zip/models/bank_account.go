package models

import (
    "encoding/json"
)

// BankAccount represents a BankAccount struct.
type BankAccount struct {
    // Direct deposit account type.
    DdaType       *DdaTypeEnum `json:"ddaType,omitempty"`
    // Check deposit type
    AchType       *AchTypeEnum `json:"achType,omitempty"`
    // Direct deposit account number.  Maximum 17 characters.
    AccountNumber *string      `json:"accountNumber,omitempty"`
    // Bank routing number. Must be 9 characters and pass ACH Mod-10 validation.
    RoutingNumber *string      `json:"routingNumber,omitempty"`
    // Bank name used for credit card processing services.
    BankName      *string      `json:"bankName,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for BankAccount.
// It customizes the JSON marshaling process for BankAccount objects.
func (b *BankAccount) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(b.toMap())
}

// toMap converts the BankAccount object to a map representation for JSON marshaling.
func (b *BankAccount) toMap() map[string]any {
    structMap := make(map[string]any)
    if b.DdaType != nil {
        structMap["ddaType"] = b.DdaType
    }
    if b.AchType != nil {
        structMap["achType"] = b.AchType
    }
    if b.AccountNumber != nil {
        structMap["accountNumber"] = b.AccountNumber
    }
    if b.RoutingNumber != nil {
        structMap["routingNumber"] = b.RoutingNumber
    }
    if b.BankName != nil {
        structMap["bankName"] = b.BankName
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for BankAccount.
// It customizes the JSON unmarshaling process for BankAccount objects.
func (b *BankAccount) UnmarshalJSON(input []byte) error {
    var temp bankAccount
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    b.DdaType = temp.DdaType
    b.AchType = temp.AchType
    b.AccountNumber = temp.AccountNumber
    b.RoutingNumber = temp.RoutingNumber
    b.BankName = temp.BankName
    return nil
}

// TODO
type bankAccount  struct {
    DdaType       *DdaTypeEnum `json:"ddaType,omitempty"`
    AchType       *AchTypeEnum `json:"achType,omitempty"`
    AccountNumber *string      `json:"accountNumber,omitempty"`
    RoutingNumber *string      `json:"routingNumber,omitempty"`
    BankName      *string      `json:"bankName,omitempty"`
}
