package models

import (
    "encoding/json"
    "errors"
    "log"
    "strings"
    "time"
)

// AuthorizedSigner represents a AuthorizedSigner struct.
type AuthorizedSigner struct {
    // The role of the signer. Please note the below.
    //  1) Merchant role name is mandatory.
    //  2) Required fields indicated in schema are those required for all role names other than "SalesRep"
    //  3) The "SalesRep" role name only requires the following fields > roleName, signingExperience, signingOrder, firstName, lastName, email
    //  4) The "Signer2" role name is for a Personal Guarantor. This signer must be included if a Personal Guarantor is on the application. Include the Guarnator's information in this object.
    RoleName            RoleNameEnum            `json:"roleName"`
    // Signing ceremony type
    SigningExperience   SigningExperienceEnum   `json:"signingExperience"`
    // Define the signing order for multiple signers
    SigningOrder        string                  `json:"signingOrder"`
    // Required for AMEX acquired merchants otherwise optional.
    Title               *string                 `json:"title,omitempty"`
    // First name. Region based validations will be applied to this field.
    FirstName           string                  `json:"firstName"`
    // Middle initial.
    MiddleInitial       *string                 `json:"middleInitial,omitempty"`
    // Last name. Region based validations will be applied to this field.
    LastName            string                  `json:"lastName"`
    // 10-digit phone number of the format  5131234567.
    PhoneNumber         string                  `json:"phoneNumber"`
    // Phone number extension. Up to 8 digits of the format 12345678.
    PhoneNumberExt      *string                 `json:"phoneNumberExt,omitempty"`
    // Phone type.
    PhoneType           *PhoneTypeEnum          `json:"phoneType,omitempty"`
    // 10-digit alternate phone number of the format  5131234567.
    AlternatePhone      *string                 `json:"alternatePhone,omitempty"`
    // Alternate phone type.
    AlternatePhoneType  *AlternatePhoneTypeEnum `json:"alternatePhoneType,omitempty"`
    // 10-digit fax number of the format 5131234567
    FaxNumber           *string                 `json:"faxNumber,omitempty"`
    // Email address of the contact. Must have @ and a .
    Email               string                  `json:"email"`
    // Social security number. Do not include dashes.
    Ssn                 string                  `json:"ssn"`
    // Date of Birth (CCYY-MM-DD). Must be at least 18 years old.
    Dob                 time.Time               `json:"dob"`
    // Address Line 1. Field for house number, street and direction.
    AddressLine1        string                  `json:"addressLine1"`
    // Address Line 2. Field for apartment or suite numbers, etc.
    AddressLine2        *string                 `json:"addressLine2,omitempty"`
    City                string                  `json:"city"`
    // Valid US state, commonwealth, and territory codes are allowed.
    State               StateEnum               `json:"state"`
    // Only United States is allowed.
    Country             string                  `json:"country"`
    // Postal code / zip code. The postal code must be valid for the address' country code.
    PostalCode          string                  `json:"postalCode"`
    // Postal code / zip code extension.  The postal code extension must be valid for the address' country code.
    PostalCodeExtension *string                 `json:"postalCodeExtension,omitempty"`
    // Optional. If any attribute in the identification object is populated then at least idNumber and idType are required.
    Identification      []Identification        `json:"identification,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for AuthorizedSigner.
// It customizes the JSON marshaling process for AuthorizedSigner objects.
func (a *AuthorizedSigner) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(a.toMap())
}

// toMap converts the AuthorizedSigner object to a map representation for JSON marshaling.
func (a *AuthorizedSigner) toMap() map[string]any {
    structMap := make(map[string]any)
    structMap["roleName"] = a.RoleName
    structMap["signingExperience"] = a.SigningExperience
    structMap["signingOrder"] = a.SigningOrder
    if a.Title != nil {
        structMap["title"] = a.Title
    }
    structMap["firstName"] = a.FirstName
    if a.MiddleInitial != nil {
        structMap["middleInitial"] = a.MiddleInitial
    }
    structMap["lastName"] = a.LastName
    structMap["phoneNumber"] = a.PhoneNumber
    if a.PhoneNumberExt != nil {
        structMap["phoneNumberExt"] = a.PhoneNumberExt
    }
    if a.PhoneType != nil {
        structMap["phoneType"] = a.PhoneType
    }
    if a.AlternatePhone != nil {
        structMap["alternatePhone"] = a.AlternatePhone
    }
    if a.AlternatePhoneType != nil {
        structMap["alternatePhoneType"] = a.AlternatePhoneType
    }
    if a.FaxNumber != nil {
        structMap["faxNumber"] = a.FaxNumber
    }
    structMap["email"] = a.Email
    structMap["ssn"] = a.Ssn
    structMap["dob"] = a.Dob.Format(DEFAULT_DATE)
    structMap["addressLine1"] = a.AddressLine1
    if a.AddressLine2 != nil {
        structMap["addressLine2"] = a.AddressLine2
    }
    structMap["city"] = a.City
    structMap["state"] = a.State
    structMap["country"] = a.Country
    structMap["postalCode"] = a.PostalCode
    if a.PostalCodeExtension != nil {
        structMap["postalCodeExtension"] = a.PostalCodeExtension
    }
    if a.Identification != nil {
        structMap["identification"] = a.Identification
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for AuthorizedSigner.
// It customizes the JSON unmarshaling process for AuthorizedSigner objects.
func (a *AuthorizedSigner) UnmarshalJSON(input []byte) error {
    var temp authorizedSigner
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    err = temp.validate()
    if err != nil {
    	return err
    }
    
    a.RoleName = *temp.RoleName
    a.SigningExperience = *temp.SigningExperience
    a.SigningOrder = *temp.SigningOrder
    a.Title = temp.Title
    a.FirstName = *temp.FirstName
    a.MiddleInitial = temp.MiddleInitial
    a.LastName = *temp.LastName
    a.PhoneNumber = *temp.PhoneNumber
    a.PhoneNumberExt = temp.PhoneNumberExt
    a.PhoneType = temp.PhoneType
    a.AlternatePhone = temp.AlternatePhone
    a.AlternatePhoneType = temp.AlternatePhoneType
    a.FaxNumber = temp.FaxNumber
    a.Email = *temp.Email
    a.Ssn = *temp.Ssn
    DobVal, err := time.Parse(DEFAULT_DATE, *temp.Dob)
    if err != nil {
        log.Fatalf("Cannot Parse dob as % s format.", DEFAULT_DATE)
    }
    a.Dob = DobVal
    a.AddressLine1 = *temp.AddressLine1
    a.AddressLine2 = temp.AddressLine2
    a.City = *temp.City
    a.State = *temp.State
    a.Country = *temp.Country
    a.PostalCode = *temp.PostalCode
    a.PostalCodeExtension = temp.PostalCodeExtension
    a.Identification = temp.Identification
    return nil
}

// TODO
type authorizedSigner  struct {
    RoleName            *RoleNameEnum           `json:"roleName"`
    SigningExperience   *SigningExperienceEnum  `json:"signingExperience"`
    SigningOrder        *string                 `json:"signingOrder"`
    Title               *string                 `json:"title,omitempty"`
    FirstName           *string                 `json:"firstName"`
    MiddleInitial       *string                 `json:"middleInitial,omitempty"`
    LastName            *string                 `json:"lastName"`
    PhoneNumber         *string                 `json:"phoneNumber"`
    PhoneNumberExt      *string                 `json:"phoneNumberExt,omitempty"`
    PhoneType           *PhoneTypeEnum          `json:"phoneType,omitempty"`
    AlternatePhone      *string                 `json:"alternatePhone,omitempty"`
    AlternatePhoneType  *AlternatePhoneTypeEnum `json:"alternatePhoneType,omitempty"`
    FaxNumber           *string                 `json:"faxNumber,omitempty"`
    Email               *string                 `json:"email"`
    Ssn                 *string                 `json:"ssn"`
    Dob                 *string                 `json:"dob"`
    AddressLine1        *string                 `json:"addressLine1"`
    AddressLine2        *string                 `json:"addressLine2,omitempty"`
    City                *string                 `json:"city"`
    State               *StateEnum              `json:"state"`
    Country             *string                 `json:"country"`
    PostalCode          *string                 `json:"postalCode"`
    PostalCodeExtension *string                 `json:"postalCodeExtension,omitempty"`
    Identification      []Identification        `json:"identification,omitempty"`
}

func (a *authorizedSigner) validate() error {
    var errs []string
    if a.RoleName == nil {
        errs = append(errs, "required field `roleName` is missing for type `AuthorizedSigner`")
    }
    if a.SigningExperience == nil {
        errs = append(errs, "required field `signingExperience` is missing for type `AuthorizedSigner`")
    }
    if a.SigningOrder == nil {
        errs = append(errs, "required field `signingOrder` is missing for type `AuthorizedSigner`")
    }
    if a.FirstName == nil {
        errs = append(errs, "required field `firstName` is missing for type `AuthorizedSigner`")
    }
    if a.LastName == nil {
        errs = append(errs, "required field `lastName` is missing for type `AuthorizedSigner`")
    }
    if a.PhoneNumber == nil {
        errs = append(errs, "required field `phoneNumber` is missing for type `AuthorizedSigner`")
    }
    if a.Email == nil {
        errs = append(errs, "required field `email` is missing for type `AuthorizedSigner`")
    }
    if a.Ssn == nil {
        errs = append(errs, "required field `ssn` is missing for type `AuthorizedSigner`")
    }
    if a.Dob == nil {
        errs = append(errs, "required field `dob` is missing for type `AuthorizedSigner`")
    }
    if a.AddressLine1 == nil {
        errs = append(errs, "required field `addressLine1` is missing for type `AuthorizedSigner`")
    }
    if a.City == nil {
        errs = append(errs, "required field `city` is missing for type `AuthorizedSigner`")
    }
    if a.State == nil {
        errs = append(errs, "required field `state` is missing for type `AuthorizedSigner`")
    }
    if a.Country == nil {
        errs = append(errs, "required field `country` is missing for type `AuthorizedSigner`")
    }
    if a.PostalCode == nil {
        errs = append(errs, "required field `postalCode` is missing for type `AuthorizedSigner`")
    }
    if len(errs) == 0 {
        return nil
    }
    return errors.New(strings.Join(errs, "\n"))
}
