package models

import (
    "encoding/json"
)

// Gateway represents a Gateway struct.
// A gateway is a hosted payment processing application provided by a service provider and accessed through an internet connection.
type Gateway struct {
    // Internally-generated gateway ID.
    GatewayId   *string `json:"gatewayId,omitempty"`
    GatewayName *string `json:"gatewayName,omitempty"`
    // Add any custom notes here.
    Notes       *string `json:"notes,omitempty"`
}

// MarshalJSON implements the json.Marshaler interface for Gateway.
// It customizes the JSON marshaling process for Gateway objects.
func (g *Gateway) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(g.toMap())
}

// toMap converts the Gateway object to a map representation for JSON marshaling.
func (g *Gateway) toMap() map[string]any {
    structMap := make(map[string]any)
    if g.GatewayId != nil {
        structMap["gatewayId"] = g.GatewayId
    }
    if g.GatewayName != nil {
        structMap["gatewayName"] = g.GatewayName
    }
    if g.Notes != nil {
        structMap["notes"] = g.Notes
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for Gateway.
// It customizes the JSON unmarshaling process for Gateway objects.
func (g *Gateway) UnmarshalJSON(input []byte) error {
    var temp gateway
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    g.GatewayId = temp.GatewayId
    g.GatewayName = temp.GatewayName
    g.Notes = temp.Notes
    return nil
}

// TODO
type gateway  struct {
    GatewayId   *string `json:"gatewayId,omitempty"`
    GatewayName *string `json:"gatewayName,omitempty"`
    Notes       *string `json:"notes,omitempty"`
}
