package launchpadnonposmerchantboarding

import (
    "context"
    "github.com/apimatic/go-core-runtime/https"
    "github.com/apimatic/go-core-runtime/utilities"
    "github.com/google/uuid"
    "launchpadnonposmerchantboarding/errors"
    "launchpadnonposmerchantboarding/models"
)

// EquipmentLookupController represents a controller struct.
type EquipmentLookupController struct {
    baseController
}

// NewEquipmentLookupController creates a new instance of EquipmentLookupController.
// It takes a baseController as a parameter and returns a pointer to the EquipmentLookupController.
func NewEquipmentLookupController(baseController baseController) *EquipmentLookupController {
    equipmentLookupController := EquipmentLookupController{baseController: baseController}
    return &equipmentLookupController
}

// GetEquipmentSupported takes context, externalRefId, vCorrelationId as parameters and
// returns an models.ApiResponse with models.InlineResponse200 data and
// an error if there was an issue with the request or response.
// Retrieve applicable equipment for an existing application.
func (e *EquipmentLookupController) GetEquipmentSupported(
    ctx context.Context,
    externalRefId uuid.UUID,
    vCorrelationId *uuid.UUID) (
    models.ApiResponse[models.InlineResponse200],
    error) {
    req := e.prepareRequest(ctx, "GET", "/equipment/supported")
    req.Authenticate(NewAuth("api_key"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "0": {Message: "Default errors", Unmarshaller: errors.NewErrorResponse},
    })
    req.Header("externalRefId", externalRefId)
    if vCorrelationId != nil {
        req.Header("v-correlation-id", *vCorrelationId)
    }
    var result models.InlineResponse200
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[models.InlineResponse200](decoder)
    return models.NewApiResponse(result, resp), err
}

// GetAdditionalConfigurations takes context, externalRefId, vCorrelationId, logicalApplicationId as parameters and
// returns an models.ApiResponse with models.AdditionalConfigurationsResponse data and
// an error if there was an issue with the request or response.
// Fetches a list of valid terminal customizations and peripherals, such as electing to password protect a void.
func (e *EquipmentLookupController) GetAdditionalConfigurations(
    ctx context.Context,
    externalRefId uuid.UUID,
    vCorrelationId *uuid.UUID,
    logicalApplicationId *string) (
    models.ApiResponse[models.AdditionalConfigurationsResponse],
    error) {
    req := e.prepareRequest(ctx, "GET", "/terminal/additional-configurations")
    req.Authenticate(NewAuth("api_key"))
    req.AppendErrors(map[string]https.ErrorBuilder[error]{
        "0": {Message: "Default errors", Unmarshaller: errors.NewErrorResponse},
    })
    req.Header("externalRefId", externalRefId)
    if vCorrelationId != nil {
        req.Header("v-correlation-id", *vCorrelationId)
    }
    if logicalApplicationId != nil {
        req.Header("logicalApplicationId", *logicalApplicationId)
    }
    var result models.AdditionalConfigurationsResponse
    decoder, resp, err := req.CallAsJson()
    if err != nil {
        return models.NewApiResponse(result, resp), err
    }
    
    result, err = utilities.DecodeResults[models.AdditionalConfigurationsResponse](decoder)
    return models.NewApiResponse(result, resp), err
}
