# Initiate Boarding Application

```python
initiate_boarding_application_controller = client.initiate_boarding_application
```

## Class Name

`InitiateBoardingApplicationController`

## Methods

* [Fetch Application](../../doc/controllers/initiate-boarding-application.md#fetch-application)
* [Exisiting Application](../../doc/controllers/initiate-boarding-application.md#exisiting-application)
* [New Application](../../doc/controllers/initiate-boarding-application.md#new-application)


# Fetch Application

Retrieves existing application data.

```python
def fetch_application(self,
                     external_ref_id,
                     v_correlation_id=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `uuid\|str` | Header, Required | The externalRefId returned from POST /applications call. |
| `v_correlation_id` | `uuid\|str` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`ExistingApplication`](../../doc/models/existing-application.md)

## Example Usage

```python
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

result = initiate_boarding_application_controller.fetch_application(
    external_ref_id,
    v_correlation_id=v_correlation_id
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Exisiting Application

This endpoint allows merchants to update an existing application with new information.

```python
def exisiting_application(self,
                         body,
                         v_correlation_id=None,
                         content_type='application/json')
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ExistingApplication1`](../../doc/models/existing-application-1.md) | Body, Required | - |
| `v_correlation_id` | `uuid\|str` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `content_type` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

`void`

## Example Usage

```python
body = ExistingApplication1(
    external_ref_id='df8a6d82-3bb4-4f3b-ba18-57a5981ede8e',
    business_info=BusinessInfo1(
        dba_name='The DBA Name',
        legal_name='legalName8',
        ownership_type=OwnershipTypeEnum.LLC,
        mcc_code='5812',
        business_established_date=dateutil.parser.parse('2000-03-23').date(),
        website_url='www.thefoodplace.com',
        number_of_location=2,
        federal_tax_id='123456781',
        payment_acceptance_method=[
            PaymentAcceptanceMethodEnum.INPERSON,
            PaymentAcceptanceMethodEnum.ONLINESITE
        ],
        pciadc=PciadcEnum.NO,
        pcidss_validated=PcidssValidatedEnum.NO,
        surrounding_area=SurroundingAreaEnum.COMMERCIAL,
        product_service_sold='Food',
        own_add_years=2,
        seasonal=SeasonalEnum.YES,
        active_months=[
            ActiveMonthEnum.JAN,
            ActiveMonthEnum.FEB,
            ActiveMonthEnum.MAR
        ],
        warranty=WarrantyEnum.ENUM_1_YEAR,
        return_policy=ReturnPolicyEnum.ENUM_30_DAY,
        gov_owned_merchant_country='US'
    ),
    transaction_info=TransactionInfo1(
        annual_sales_volume=20000.12,
        percent_retail_swiped_transactions=82,
        average_ticket=2.3,
        highest_ticket=32.41,
        current_processor='Global Payments',
        accept_chargebacks=AcceptChargebacksEnum.NO,
        chargeback_percent=0,
        return_percent=10,
        card_not_present_percent=20,
        business_to_business_percent=20,
        internet_transaction_percent=10,
        in_person_transaction_percent=10,
        moto_transaction_percent=10,
        annual_credit_sales_volume=123.32,
        annual_debit_sales_volume=32.23,
        annual_amex_volume=10000,
        amex_average_ticket=2.3,
        average_numberof_days=10,
        needs_processing_by=dateutil.parser.parse('2022-11-01').date()
    ),
    lead_source='Activate',
    addresses=[
        Address1(
            mtype=AddressTypeEnum.ENUM_MAILING_ADDRESS,
            address_line_1='1234 W Tester Ave.',
            city='City Town',
            state=State1Enum.CO,
            country='United States',
            postal_code='80123',
            postal_code_extension='1234'
        ),
        Address1(
            mtype=AddressTypeEnum.ENUM_PHYSICAL_ADDRESS,
            address_line_1='1234 W Tester Ave.',
            city='City Town',
            state=State1Enum.CO,
            country='United States',
            postal_code='80123',
            postal_code_extension='1234'
        )
    ],
    route_to_sales_rep=False
)

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

content_type = ContentTypeEnum.ENUM_APPLICATIONJSON

result = initiate_boarding_application_controller.exisiting_application(
    body,
    v_correlation_id=v_correlation_id,
    content_type=content_type
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# New Application

Use this endpoint to collect the merchant information needed to initiate a new contract.

```python
def new_application(self,
                   body,
                   v_correlation_id=None,
                   content_type='application/json')
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Application`](../../doc/models/application.md) | Body, Required | - |
| `v_correlation_id` | `uuid\|str` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `content_type` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

[`ApplicationResponse`](../../doc/models/application-response.md)

## Example Usage

```python
body = Application(
    business_info=BusinessInfo1(
        dba_name='The DBA Name',
        legal_name='legalName8',
        ownership_type=OwnershipTypeEnum.LLC,
        mcc_code='5812',
        business_established_date=dateutil.parser.parse('2000-03-23').date(),
        website_url='www.thefoodplace.com',
        number_of_location=2,
        federal_tax_id='123456781',
        payment_acceptance_method=[
            PaymentAcceptanceMethodEnum.INPERSON,
            PaymentAcceptanceMethodEnum.ONLINESITE
        ],
        pciadc=PciadcEnum.NO,
        pcidss_validated=PcidssValidatedEnum.NO,
        surrounding_area=SurroundingAreaEnum.COMMERCIAL,
        product_service_sold='Food',
        own_add_years=2,
        seasonal=SeasonalEnum.YES,
        active_months=[
            ActiveMonthEnum.JAN,
            ActiveMonthEnum.FEB,
            ActiveMonthEnum.MAR
        ],
        warranty=WarrantyEnum.ENUM_1_YEAR,
        return_policy=ReturnPolicyEnum.ENUM_30_DAY,
        gov_owned_merchant_country='US'
    ),
    transaction_info=TransactionInfo1(
        annual_sales_volume=20000.12,
        percent_retail_swiped_transactions=82,
        average_ticket=2.3,
        highest_ticket=32.41,
        current_processor='Global Payments',
        accept_chargebacks=AcceptChargebacksEnum.NO,
        chargeback_percent=0,
        return_percent=10,
        card_not_present_percent=20,
        business_to_business_percent=20,
        internet_transaction_percent=10,
        in_person_transaction_percent=10,
        moto_transaction_percent=10,
        annual_credit_sales_volume=123.32,
        annual_debit_sales_volume=32.23,
        annual_amex_volume=10000,
        amex_average_ticket=2.3,
        average_numberof_days=10,
        needs_processing_by=dateutil.parser.parse('2022-11-01').date()
    ),
    authorized_signers=[
        AuthorizedSigner1(
            role_name=RoleName1Enum.MERCHANT,
            signing_experience=SigningExperienceEnum.EMAIL,
            signing_order='2',
            first_name='Todd',
            last_name='Davis',
            phone_number='5131234567',
            email='test@gmail.com',
            ssn='123456789',
            dob=dateutil.parser.parse('2000-03-23').date(),
            address_line_1='4355 N Coalwhipe St.',
            city='Denver',
            state=State1Enum.CO,
            country='United States',
            postal_code='12345',
            title='President',
            middle_initial='M',
            phone_number_ext='1234',
            phone_type=PhoneTypeEnum.MOBILE,
            alternate_phone='5131234567',
            alternate_phone_type=AlternatePhoneTypeEnum.HOME,
            fax_number='5131234567',
            address_line_2='suite 104',
            postal_code_extension='1234'
        )
    ],
    contacts=[
        Contact1(
            mtype=Type4Enum.ENUM_PRIMARY_CONTACT,
            first_name='Todd',
            last_name='Davis',
            phone_number='5131234567',
            email='test@gmail.com',
            title='President',
            middle_initial='M',
            ssn='123456789',
            birth_date=dateutil.parser.parse('2000-03-23').date(),
            phone_number_ext='1234',
            phone_type=PhoneTypeEnum.MOBILE,
            alternate_phone='5131234567',
            alternate_phone_type=AlternatePhoneTypeEnum.HOME,
            fax_number='5131234567'
        )
    ],
    addresses=[
        Address1(
            mtype=AddressTypeEnum.ENUM_MAILING_ADDRESS,
            address_line_1='1234 W Tester Ave.',
            city='City Town',
            state=State1Enum.CO,
            country='United States',
            postal_code='80123',
            postal_code_extension='1234'
        ),
        Address1(
            mtype=AddressTypeEnum.ENUM_PHYSICAL_ADDRESS,
            address_line_1='1234 W Tester Ave.',
            city='City Town',
            state=State1Enum.CO,
            country='United States',
            postal_code='80123',
            postal_code_extension='1234'
        ),
        Address1(
            mtype=AddressTypeEnum.ENUM_SHIPPING_ADDRESS,
            address_line_1='1234 W Tester Ave.',
            city='City Town',
            state=State1Enum.CO,
            country='United States',
            postal_code='80123',
            postal_code_extension='1234'
        )
    ],
    client_tracking_id='1341341234132412341',
    lead_source='LP Connect API'
)

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

content_type = ContentTypeEnum.ENUM_APPLICATIONJSON

result = initiate_boarding_application_controller.new_application(
    body,
    v_correlation_id=v_correlation_id,
    content_type=content_type
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

