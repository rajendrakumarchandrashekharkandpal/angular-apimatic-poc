
# Lease Term Length Enum

Lease term for the peripheral

## Enumeration

`LeaseTermLengthEnum`

## Fields

| Name |
|  --- |
| `ENUM_24` |
| `ENUM_36` |
| `ENUM_48` |
| `ENUM_60` |

## Example

```
24
```

