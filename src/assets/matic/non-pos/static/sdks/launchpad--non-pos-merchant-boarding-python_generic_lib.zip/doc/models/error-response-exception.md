
# Error Response Exception

## Structure

`ErrorResponseException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `http_status_code` | `int` | Optional | - |
| `http_status_message` | `str` | Optional | - |
| `errors` | [`List[Error]`](../../doc/models/error.md) | Optional | - |

## Example (as JSON)

```json
{
  "httpStatusCode": 404,
  "httpStatusMessage": "STATUS-MESSAGE",
  "errors": [
    {
      "errorCode": "errorCode6",
      "errorMessage": "errorMessage8",
      "target": "target2"
    },
    {
      "errorCode": "errorCode6",
      "errorMessage": "errorMessage8",
      "target": "target2"
    },
    {
      "errorCode": "errorCode6",
      "errorMessage": "errorMessage8",
      "target": "target2"
    }
  ]
}
```

