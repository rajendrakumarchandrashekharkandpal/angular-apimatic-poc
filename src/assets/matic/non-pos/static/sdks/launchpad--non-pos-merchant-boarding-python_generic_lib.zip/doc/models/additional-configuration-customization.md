
# Additional Configuration Customization

## Structure

`AdditionalConfigurationCustomization`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customization_id` | `str` | Optional | Customization Id is internally populated from a master list. |
| `customization_type` | `str` | Optional | type of customization |
| `use_product_matrix` | `str` | Optional | Whether or not used in product matrix |
| `product_id` | `str` | Optional | unique ID for the product |
| `code` | `str` | Optional | product code |
| `customization_code_details` | [`List[CustomizationCodeDetails]`](../../doc/models/customization-code-details.md) | Optional | - |
| `customization_value` | `str` | Optional | Actual Customization Value |
| `customization_field_length` | `str` | Optional | Length of the customization value |
| `customization_decimal_place` | `str` | Optional | Number of decimal places |
| `customization_min_value` | `str` | Optional | Minimum Value. Only applicable if the customization value is a number |
| `customization_max_value` | `str` | Optional | Maximum Value. Only applicable if the customization value is a number |
| `characters_allowed` | `str` | Optional | All characters allowed for customization. Only applicable if the customization value is a string. |
| `rule` | `str` | Optional | customization rule |
| `regex` | `str` | Optional | Regular expression to validate the customization value |
| `multi_merchant_flag` | `bool` | Optional | Applicable in a multiple merchant situation<br>**Default**: `False` |
| `short_description` | `str` | Optional | Description of the customization |
| `long_description` | `str` | Optional | Verbose description of the customiztion |

## Example (as JSON)

```json
{
  "customizationId": "1",
  "customizationType": "time",
  "useProductMatrix": "N",
  "productId": "12",
  "code": "CST01",
  "customizationValue": "H",
  "customizationFieldLength": "1",
  "customizationDecimalPlace": "0",
  "customizationMinValue": "0",
  "customizationMaxValue": "6",
  "charactersAllowed": "abcdefghijklmnopqrstuvwxyz",
  "regex": "^[a-z]{1}",
  "multiMerchantFlag": false,
  "shortDescription": "CVV_PROMPTING",
  "longDescription": "CVV_PROMPTING"
}
```

