
# Type 4 Enum

Type of merchant contact.

1) Only primary contact
   is mandatory. May be the same as any owner contact information.
2) For primary contact, firstName, lastName, phoneNumber and email are mandatory during POST.
3) For all other contact types, firstName and lastName are mandatory during POST.

## Enumeration

`Type4Enum`

## Fields

| Name |
|  --- |
| `ENUM_PRIMARY_CONTACT` |
| `ENUM_STORE_PRIMARY_CONTACT` |
| `ENUM_ACCOUNTING_CONTACT` |
| `ENUM_CUSTOMER_SERVICE_CONTACT` |
| `ENUM_SHIPPING_CONTACT` |
| `ENUM_THIRD_PARTY_CONTACT` |
| `ENUM_VENDOR_CONTACT_INFO` |
| `ENUM_PCI_CONTACT` |
| `CORPORATE` |

## Example

```
Primary Contact
```

