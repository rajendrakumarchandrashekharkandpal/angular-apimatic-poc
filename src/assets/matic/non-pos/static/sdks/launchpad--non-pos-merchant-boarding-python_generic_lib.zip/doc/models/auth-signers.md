
# Auth Signers

## Structure

`AuthSigners`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first_name` | `str` | Optional | First name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `15`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `middle_initial` | `str` | Optional | Middle initial.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `last_name` | `str` | Optional | Last name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `25`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `email` | `str` | Optional | Email address of the contact. Must have @ and a .<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64`, *Pattern*: `\b[A-Za-z0-9._%+-]+@(?:[A-Za-z0-9-]+\.)+[A-Za-z0-9]{2,}` |
| `status` | `str` | Optional | Status of the signer |
| `last_updated` | `datetime` | Optional | Date contract was last updated |
| `date_submitted` | `datetime` | Optional | Date contract was last updated |
| `date_sent` | `datetime` | Optional | Date contract was sent |
| `date_delivered` | `datetime` | Optional | Date contract was delivered |
| `date_signed` | `datetime` | Optional | Date contract was signed |
| `signer_role_name` | `str` | Optional | Role of the signer |
| `signer_experience` | `str` | Optional | Method of sign |

## Example (as JSON)

```json
{
  "firstName": "Todd",
  "middleInitial": "M",
  "lastName": "Davis",
  "email": "test@gmail.com",
  "status": "sent",
  "signerRoleName": "Merchant",
  "signerExperience": "wet"
}
```

