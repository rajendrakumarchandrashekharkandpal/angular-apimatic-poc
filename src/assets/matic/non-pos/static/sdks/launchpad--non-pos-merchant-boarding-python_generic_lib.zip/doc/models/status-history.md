
# Status History

## Structure

`StatusHistory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status_seq_number` | `int` | Optional | - |
| `detail_status` | `str` | Optional | - |
| `summary_status` | `str` | Optional | - |
| `status_category` | `str` | Optional | - |
| `status_date_time` | `datetime` | Optional | - |

## Example (as JSON)

```json
{
  "statusSeqNumber": 2200,
  "detailStatus": "Contract Signed",
  "summaryStatus": "App Submitted",
  "statusCategory": "Contract",
  "statusDateTime": "2016-03-13T12:52:32.123Z"
}
```

