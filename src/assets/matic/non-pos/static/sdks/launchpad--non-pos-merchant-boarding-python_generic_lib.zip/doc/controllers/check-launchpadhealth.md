# Check Launchpadhealth

```python
check_launchpadhealth_controller = client.check_launchpadhealth
```

## Class Name

`CheckLaunchpadhealthController`


# Gethealth

Checks the the health of Launchpad and its dependent down streams systems like CPQ, Sales Force, XAA and Jigsaw at regular intervals to check the system is up or down.

```python
def gethealth(self,
             v_correlation_id=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `v_correlation_id` | `uuid\|str` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`InlineResponse2001`](../../doc/models/inline-response-2001.md)

## Example Usage

```python
v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

result = check_launchpad_health_controller.gethealth(
    v_correlation_id=v_correlation_id
)
print(result)
```

