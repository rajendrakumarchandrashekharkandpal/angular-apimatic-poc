
# Payment Method Enum

Payment method for the selected terminal.

## Enumeration

`PaymentMethodEnum`

## Fields

| Name |
|  --- |
| `ENUM_PURCHASE_SALE` |
| `ENUM_REPROGRAM_OWN` |
| `ENUM_MONTHTOMONTH_RENTAL` |
| `LEASE` |

## Example

```
PURCHASE / SALE
```

