
# Additional Configuration Peripheral

## Structure

`AdditionalConfigurationPeripheral`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `peripheral_id` | `str` | Optional | Peripheral IDs are internally populated. |
| `model` | `str` | Optional | Peripheral Name |
| `short_description` | `str` | Optional | Description of the peripheral |
| `long_description` | `str` | Optional | Verbose description of the peripheral |
| `is_emv_certified` | `bool` | Optional | Whether peripheral is EMV certified |
| `is_emv_capable` | `bool` | Optional | Whether peripheral is EMV Capable |
| `active_peripheral_flag` | `str` | Optional | - |
| `purchase_price` | `str` | Optional | purchase price of the peripheral |
| `lease_price` | `str` | Optional | lease price of the peripheral |
| `rental_price` | `str` | Optional | rental price of the peripheral |
| `hardware_cost` | `str` | Optional | hardware cost of the terminal |

## Example (as JSON)

```json
{
  "peripheralId": "35",
  "model": "Pin Pad 1000 SE",
  "shortDescription": "PP1S",
  "longDescription": "PPAD",
  "isEMVCertified": true,
  "isEMVCapable": true,
  "activePeripheralFlag": "Y",
  "purchasePrice": "168.12",
  "leasePrice": "100.12",
  "rentalPrice": "90",
  "hardwareCost": "50.75"
}
```

