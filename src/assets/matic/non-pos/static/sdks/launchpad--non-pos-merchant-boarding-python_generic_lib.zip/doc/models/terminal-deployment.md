
# Terminal Deployment

## Structure

`TerminalDeployment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `equipment_update_deploy` | [`EquipmentUpdateDeployEnum`](../../doc/models/equipment-update-deploy-enum.md) | Required | - |
| `terminal_build_flag` | `bool` | Optional | - |
| `front_end_build_flag` | `bool` | Optional | - |
| `sic_merchant_flag` | `bool` | Optional | - |
| `special_instructions` | `str` | Optional | Special instructions for terminal deployment.<br>**Constraints**: *Maximum Length*: `255` |

## Example (as JSON)

```json
{
  "equipmentUpdateDeploy": "M",
  "terminalBuildFlag": true,
  "frontEndBuildFlag": true,
  "sicMerchantFlag": false,
  "specialInstructions": "Retail - H52460A (SP)"
}
```

