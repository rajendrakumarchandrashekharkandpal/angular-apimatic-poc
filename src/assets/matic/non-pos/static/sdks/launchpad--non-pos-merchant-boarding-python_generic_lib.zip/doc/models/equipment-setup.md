
# Equipment Setup

## Structure

`EquipmentSetup`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shipping_option` | [`ShippingOptionEnum`](../../doc/models/shipping-option-enum.md) | Optional | The speed you would like the equipment to be shipped.<br>**Default**: `'next day'` |
| `terminals` | [`List[Terminal]`](../../doc/models/terminal.md) | Optional | - |

## Example (as JSON)

```json
{
  "shippingOption": "next day",
  "terminals": [
    {
      "terminalConfigs": {
        "requestId": "requestId0",
        "terminalId": "terminalId6",
        "terminalModel": "terminalModel6",
        "price": 129.34,
        "quantity": 206,
        "logicalApplicationId": "logicalApplicationId2",
        "accessMethod": "accessMethod8",
        "paymentMethod": "MONTH-TO-MONTH RENTAL",
        "environmentName": "environmentName6",
        "isVar": false,
        "emvCapable": false,
        "leaseId": "leaseId4"
      },
      "customizations": [
        {
          "customizationId": "customizationId0",
          "customizationName": "customizationName6",
          "customizationFieldValue": "customizationFieldValue8"
        }
      ],
      "products": [
        {
          "productId": "productId4",
          "productName": "productName8"
        },
        {
          "productId": "productId4",
          "productName": "productName8"
        },
        {
          "productId": "productId4",
          "productName": "productName8"
        }
      ],
      "peripherals": [
        {
          "peripheralId": "peripheralId2",
          "peripheralType": "peripheralType6",
          "model": "model4",
          "leaseId": "leaseId2",
          "leaseTermLength": "48"
        },
        {
          "peripheralId": "peripheralId2",
          "peripheralType": "peripheralType6",
          "model": "model4",
          "leaseId": "leaseId2",
          "leaseTermLength": "48"
        },
        {
          "peripheralId": "peripheralId2",
          "peripheralType": "peripheralType6",
          "model": "model4",
          "leaseId": "leaseId2",
          "leaseTermLength": "48"
        }
      ],
      "vendors": [
        {
          "paymentApplicationId": "paymentApplicationId2",
          "paymentApplicationName": "paymentApplicationName6",
          "vendorId": "vendorId0",
          "version": "version4",
          "reseller": "reseller6"
        },
        {
          "paymentApplicationId": "paymentApplicationId2",
          "paymentApplicationName": "paymentApplicationName6",
          "vendorId": "vendorId0",
          "version": "version4",
          "reseller": "reseller6"
        }
      ],
      "gateways": [
        {
          "gatewayId": "gatewayId8",
          "gatewayName": "gatewayName0",
          "notes": "notes4"
        }
      ],
      "supply": [
        {
          "supplyType": "supplyType0",
          "name": "name4",
          "quantity": 240,
          "total": "total6"
        },
        {
          "supplyType": "supplyType0",
          "name": "name4",
          "quantity": 240,
          "total": "total6"
        },
        {
          "supplyType": "supplyType0",
          "name": "name4",
          "quantity": 240,
          "total": "total6"
        }
      ]
    },
    {
      "terminalConfigs": {
        "requestId": "requestId0",
        "terminalId": "terminalId6",
        "terminalModel": "terminalModel6",
        "price": 129.34,
        "quantity": 206,
        "logicalApplicationId": "logicalApplicationId2",
        "accessMethod": "accessMethod8",
        "paymentMethod": "MONTH-TO-MONTH RENTAL",
        "environmentName": "environmentName6",
        "isVar": false,
        "emvCapable": false,
        "leaseId": "leaseId4"
      },
      "customizations": [
        {
          "customizationId": "customizationId0",
          "customizationName": "customizationName6",
          "customizationFieldValue": "customizationFieldValue8"
        }
      ],
      "products": [
        {
          "productId": "productId4",
          "productName": "productName8"
        },
        {
          "productId": "productId4",
          "productName": "productName8"
        },
        {
          "productId": "productId4",
          "productName": "productName8"
        }
      ],
      "peripherals": [
        {
          "peripheralId": "peripheralId2",
          "peripheralType": "peripheralType6",
          "model": "model4",
          "leaseId": "leaseId2",
          "leaseTermLength": "48"
        },
        {
          "peripheralId": "peripheralId2",
          "peripheralType": "peripheralType6",
          "model": "model4",
          "leaseId": "leaseId2",
          "leaseTermLength": "48"
        },
        {
          "peripheralId": "peripheralId2",
          "peripheralType": "peripheralType6",
          "model": "model4",
          "leaseId": "leaseId2",
          "leaseTermLength": "48"
        }
      ],
      "vendors": [
        {
          "paymentApplicationId": "paymentApplicationId2",
          "paymentApplicationName": "paymentApplicationName6",
          "vendorId": "vendorId0",
          "version": "version4",
          "reseller": "reseller6"
        },
        {
          "paymentApplicationId": "paymentApplicationId2",
          "paymentApplicationName": "paymentApplicationName6",
          "vendorId": "vendorId0",
          "version": "version4",
          "reseller": "reseller6"
        }
      ],
      "gateways": [
        {
          "gatewayId": "gatewayId8",
          "gatewayName": "gatewayName0",
          "notes": "notes4"
        }
      ],
      "supply": [
        {
          "supplyType": "supplyType0",
          "name": "name4",
          "quantity": 240,
          "total": "total6"
        },
        {
          "supplyType": "supplyType0",
          "name": "name4",
          "quantity": 240,
          "total": "total6"
        },
        {
          "supplyType": "supplyType0",
          "name": "name4",
          "quantity": 240,
          "total": "total6"
        }
      ]
    },
    {
      "terminalConfigs": {
        "requestId": "requestId0",
        "terminalId": "terminalId6",
        "terminalModel": "terminalModel6",
        "price": 129.34,
        "quantity": 206,
        "logicalApplicationId": "logicalApplicationId2",
        "accessMethod": "accessMethod8",
        "paymentMethod": "MONTH-TO-MONTH RENTAL",
        "environmentName": "environmentName6",
        "isVar": false,
        "emvCapable": false,
        "leaseId": "leaseId4"
      },
      "customizations": [
        {
          "customizationId": "customizationId0",
          "customizationName": "customizationName6",
          "customizationFieldValue": "customizationFieldValue8"
        }
      ],
      "products": [
        {
          "productId": "productId4",
          "productName": "productName8"
        },
        {
          "productId": "productId4",
          "productName": "productName8"
        },
        {
          "productId": "productId4",
          "productName": "productName8"
        }
      ],
      "peripherals": [
        {
          "peripheralId": "peripheralId2",
          "peripheralType": "peripheralType6",
          "model": "model4",
          "leaseId": "leaseId2",
          "leaseTermLength": "48"
        },
        {
          "peripheralId": "peripheralId2",
          "peripheralType": "peripheralType6",
          "model": "model4",
          "leaseId": "leaseId2",
          "leaseTermLength": "48"
        },
        {
          "peripheralId": "peripheralId2",
          "peripheralType": "peripheralType6",
          "model": "model4",
          "leaseId": "leaseId2",
          "leaseTermLength": "48"
        }
      ],
      "vendors": [
        {
          "paymentApplicationId": "paymentApplicationId2",
          "paymentApplicationName": "paymentApplicationName6",
          "vendorId": "vendorId0",
          "version": "version4",
          "reseller": "reseller6"
        },
        {
          "paymentApplicationId": "paymentApplicationId2",
          "paymentApplicationName": "paymentApplicationName6",
          "vendorId": "vendorId0",
          "version": "version4",
          "reseller": "reseller6"
        }
      ],
      "gateways": [
        {
          "gatewayId": "gatewayId8",
          "gatewayName": "gatewayName0",
          "notes": "notes4"
        }
      ],
      "supply": [
        {
          "supplyType": "supplyType0",
          "name": "name4",
          "quantity": 240,
          "total": "total6"
        },
        {
          "supplyType": "supplyType0",
          "name": "name4",
          "quantity": 240,
          "total": "total6"
        },
        {
          "supplyType": "supplyType0",
          "name": "name4",
          "quantity": 240,
          "total": "total6"
        }
      ]
    }
  ]
}
```

