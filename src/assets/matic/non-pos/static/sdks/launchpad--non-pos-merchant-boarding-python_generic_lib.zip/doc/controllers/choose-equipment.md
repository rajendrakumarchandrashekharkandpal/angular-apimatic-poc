# Choose Equipment

```python
choose_equipment_controller = client.choose_equipment
```

## Class Name

`ChooseEquipmentController`

## Methods

* [Get Terminal Info](../../doc/controllers/choose-equipment.md#get-terminal-info)
* [Update Terminal](../../doc/controllers/choose-equipment.md#update-terminal)
* [Config Standalone Terminal](../../doc/controllers/choose-equipment.md#config-standalone-terminal)


# Get Terminal Info

Gets the terminal configuration information for a specific partner.

```python
def get_terminal_info(self,
                     external_ref_id,
                     v_correlation_id=None,
                     content_type='application/json',
                     location_id=None,
                     merchant_id=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `uuid\|str` | Header, Required | The externalRefId returned from POST /applications call. |
| `v_correlation_id` | `uuid\|str` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `content_type` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `location_id` | `str` | Header, Optional | The locationId returned from POST /locations call. |
| `merchant_id` | `str` | Header, Optional | The merchantId returned from POST /merchants call. |

## Response Type

[`EquipmentSetup`](../../doc/models/equipment-setup.md)

## Example Usage

```python
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

v_correlation_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

content_type = ContentTypeEnum.ENUM_APPLICATIONJSON

result = choose_equipment_controller.get_terminal_info(
    external_ref_id,
    v_correlation_id=v_correlation_id,
    content_type=content_type
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Update Terminal

Updates terminal configurations.

```python
def update_terminal(self,
                   external_ref_id,
                   body,
                   v_correlation_id=None,
                   content_type='application/json',
                   location_id=None,
                   merchant_id=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `uuid\|str` | Header, Required | The externalRefId returned from POST /applications call. |
| `body` | [`EquipmentSetup`](../../doc/models/equipment-setup.md) | Body, Required | - |
| `v_correlation_id` | `uuid\|str` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `content_type` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `location_id` | `str` | Header, Optional | The locationId returned from POST /locations call. |
| `merchant_id` | `str` | Header, Optional | The merchantId returned from POST /merchants call. |

## Response Type

`void`

## Example Usage

```python
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

body = EquipmentSetup(
    shipping_option=ShippingOptionEnum.ENUM_NEXT_DAY,
    terminals=[
        Terminal(
            terminal_configs=TerminalConfig(
                terminal_id='67',
                price=187.99,
                quantity=1,
                logical_application_id='194',
                access_method='SSL',
                payment_method=PaymentMethodEnum.ENUM_PURCHASE_SALE,
                environment_name='Restaurant',
                request_id='41231',
                terminal_model='VAR - Xpient Solutions'
            ),
            products=[
                Product(
                    product_id='1',
                    product_name='Credit'
                )
            ]
        )
    ]
)

result = choose_equipment_controller.update_terminal(
    external_ref_id,
    body
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Config Standalone Terminal

Sets up terminal configurations.

```python
def config_standalone_terminal(self,
                              external_ref_id,
                              body,
                              v_correlation_id=None,
                              content_type='application/json',
                              location_id=None,
                              merchant_id=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_ref_id` | `uuid\|str` | Header, Required | The externalRefId returned from POST /applications call. |
| `body` | [`EquipmentSetup`](../../doc/models/equipment-setup.md) | Body, Required | - |
| `v_correlation_id` | `uuid\|str` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `content_type` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `location_id` | `str` | Header, Optional | The locationId returned from POST /locations call. |
| `merchant_id` | `str` | Header, Optional | The merchantId returned from POST /merchants call. |

## Response Type

`void`

## Example Usage

```python
external_ref_id = '3fcb1437-4e52-4946-9ae1-e618351b6d16'

body = EquipmentSetup(
    shipping_option=ShippingOptionEnum.ENUM_NEXT_DAY,
    terminals=[
        Terminal(
            terminal_configs=TerminalConfig(
                terminal_id='67',
                price=187.99,
                quantity=1,
                logical_application_id='194',
                access_method='SSL',
                payment_method=PaymentMethodEnum.ENUM_PURCHASE_SALE,
                environment_name='Restaurant',
                request_id='41231',
                terminal_model='VAR - Xpient Solutions'
            ),
            products=[
                Product(
                    product_id='1',
                    product_name='Credit'
                )
            ]
        )
    ]
)

result = choose_equipment_controller.config_standalone_terminal(
    external_ref_id,
    body
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

