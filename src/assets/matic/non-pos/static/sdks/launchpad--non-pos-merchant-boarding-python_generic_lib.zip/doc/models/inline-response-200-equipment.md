
# Inline Response 200 Equipment

## Structure

`InlineResponse200Equipment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `str` | Optional | - |
| `name` | `str` | Optional | - |
| `logical_application_id` | `str` | Optional | - |
| `environment` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "id": "1",
  "name": "Verifone LX570",
  "logicalApplicationId": "1073",
  "environment": "Retail"
}
```

