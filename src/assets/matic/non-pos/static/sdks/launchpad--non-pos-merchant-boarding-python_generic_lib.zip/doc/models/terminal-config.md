
# Terminal Config

## Structure

`TerminalConfig`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_id` | `str` | Optional | Partner assigned unique request ID for terminal setup. |
| `terminal_id` | `str` | Required | Terminal ID number. |
| `terminal_model` | `str` | Optional | The model name of the terminal in use. |
| `price` | `float` | Required | Terminal price |
| `quantity` | `int` | Required | - |
| `logical_application_id` | `str` | Required | Logical application ID. |
| `access_method` | `str` | Required | Methods of terminal access. |
| `payment_method` | [`PaymentMethodEnum`](../../doc/models/payment-method-enum.md) | Required | Payment method for the selected terminal. |
| `environment_name` | `str` | Required | Environment name |
| `is_var` | `bool` | Optional | The value added reseller. Default value is false.<br>**Default**: `False` |
| `emv_capable` | `bool` | Optional | Is it EMV capabale?<br>**Default**: `False` |
| `lease_id` | `str` | Optional | Lease ID. Required when PaymentMethod is selected as lease. |
| `lease_term_length` | [`LeaseTermLengthEnum`](../../doc/models/lease-term-length-enum.md) | Optional | Lease term for the peripheral |
| `terminal_sequence_number` | `str` | Optional | Terminal sequence number. If not sent, the API will autogenerate a number.<br>**Constraints**: *Pattern*: `^[0-9]` |
| `special_customizations` | `str` | Optional | Any customization request for a terminal configuration.<br>**Constraints**: *Maximum Length*: `255` |

## Example (as JSON)

```json
{
  "requestId": "41231",
  "terminalId": "iCT220",
  "terminalModel": "Ingenico iCT220 CTLS 3.X Dial",
  "price": 187.99,
  "quantity": 1,
  "logicalApplicationId": "MONE510",
  "accessMethod": "SSL",
  "paymentMethod": "PURCHASE / SALE",
  "environmentName": "Retail",
  "isVar": false,
  "emvCapable": true,
  "leaseId": "12",
  "leaseTermLength": "24",
  "terminalSequenceNumber": "14",
  "specialCustomizations": "Mulitple merchant setup is Yes"
}
```

