
# Schema

## Structure

`Schema`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Optional | - |

## Example (as JSON)

```json
{
  "id": 82
}
```

