
# Id Type Enum

Type of ID provided by the owner.

## Enumeration

`IdTypeEnum`

## Fields

| Name |
|  --- |
| `ENUM_ALIEN_ID` |
| `ENUM_CREDIT_BUREAU` |
| `ENUM_DRIVERS_LICENSE` |
| `ENUM_STATE_ID` |
| `ENUM_MEXICAN_CONSULATE` |
| `ENUM_MILITARY_ID` |
| `OTHER` |
| `PASSPORT` |

## Example

```
PASSPORT
```

