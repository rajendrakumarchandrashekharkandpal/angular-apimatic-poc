
# Identification

## Structure

`Identification`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id_type` | [`IdTypeEnum`](../../doc/models/id-type-enum.md) | Required | Type of ID provided by the owner. |
| `id_number` | `str` | Required | Owner's ID number.<br>**Constraints**: *Maximum Length*: `40` |
| `issued_city` | `str` | Optional | City in which ID was issued.<br>**Constraints**: *Maximum Length*: `28` |
| `issued_state` | [`IssuedStateEnum`](../../doc/models/issued-state-enum.md) | Optional | Valid state code where ID was issued.<br>**Constraints**: *Maximum Length*: `2` |
| `issued_country` | `str` | Optional | Country where ID was issued.<br>**Constraints**: *Maximum Length*: `2` |
| `date_issued` | `date` | Optional | Date ID was issued (CCYY-MM-DD). |
| `date_expires` | `date` | Optional | Date ID expires (CCYY-MM-DD). |

## Example (as JSON)

```json
{
  "idType": "PASSPORT",
  "idNumber": "312312341",
  "issuedCity": "City Town",
  "issuedState": "CO",
  "issuedCountry": "US",
  "dateIssued": "1999-01-30",
  "dateExpires": "2020-02-11"
}
```

