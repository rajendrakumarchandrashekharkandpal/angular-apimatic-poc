// <copyright file="Application.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Application.
    /// </summary>
    public class Application
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Application"/> class.
        /// </summary>
        public Application()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Application"/> class.
        /// </summary>
        /// <param name="businessInfo">businessInfo.</param>
        /// <param name="transactionInfo">transactionInfo.</param>
        /// <param name="authorizedSigners">authorizedSigners.</param>
        /// <param name="contacts">contacts.</param>
        /// <param name="addresses">addresses.</param>
        /// <param name="clientTrackingId">clientTrackingId.</param>
        /// <param name="owners">owners.</param>
        /// <param name="guarantors">guarantors.</param>
        /// <param name="bankAccount">bankAccount.</param>
        /// <param name="advancedSettelment">advancedSettelment.</param>
        /// <param name="salesAgent">salesAgent.</param>
        /// <param name="installationContact">installationContact.</param>
        /// <param name="additionalInformation">additionalInformation.</param>
        /// <param name="leadSource">leadSource.</param>
        /// <param name="routeToSalesRep">routeToSalesRep.</param>
        /// <param name="productsInquiry">productsInquiry.</param>
        public Application(
            Models.BusinessInfo1 businessInfo,
            Models.TransactionInfo1 transactionInfo,
            List<Models.AuthorizedSigner1> authorizedSigners,
            List<Models.Contact1> contacts,
            List<Models.Address1> addresses,
            string clientTrackingId = null,
            List<Models.Owner1> owners = null,
            List<Models.Guarantor1> guarantors = null,
            Models.BankAccount1 bankAccount = null,
            List<Models.AdvancedSettlementInner> advancedSettelment = null,
            Models.SalesAgent1 salesAgent = null,
            Models.InstallationContact installationContact = null,
            List<Models.AdditionalInformationObject> additionalInformation = null,
            string leadSource = null,
            bool? routeToSalesRep = null,
            List<string> productsInquiry = null)
        {
            this.ClientTrackingId = clientTrackingId;
            this.BusinessInfo = businessInfo;
            this.TransactionInfo = transactionInfo;
            this.Owners = owners;
            this.AuthorizedSigners = authorizedSigners;
            this.Guarantors = guarantors;
            this.Contacts = contacts;
            this.Addresses = addresses;
            this.BankAccount = bankAccount;
            this.AdvancedSettelment = advancedSettelment;
            this.SalesAgent = salesAgent;
            this.InstallationContact = installationContact;
            this.AdditionalInformation = additionalInformation;
            this.LeadSource = leadSource;
            this.RouteToSalesRep = routeToSalesRep;
            this.ProductsInquiry = productsInquiry;
        }

        /// <summary>
        /// This is an optional field that can be used by the partners to send a unique Id from their application for reporting purposes.
        /// </summary>
        [JsonProperty("clientTrackingId", NullValueHandling = NullValueHandling.Ignore)]
        public string ClientTrackingId { get; set; }

        /// <summary>
        /// Gets or sets BusinessInfo.
        /// </summary>
        [JsonProperty("businessInfo")]
        public Models.BusinessInfo1 BusinessInfo { get; set; }

        /// <summary>
        /// Gets or sets TransactionInfo.
        /// </summary>
        [JsonProperty("transactionInfo")]
        public Models.TransactionInfo1 TransactionInfo { get; set; }

        /// <summary>
        /// Gets or sets Owners.
        /// </summary>
        [JsonProperty("owners", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Owner1> Owners { get; set; }

        /// <summary>
        /// Gets or sets AuthorizedSigners.
        /// </summary>
        [JsonProperty("authorizedSigners")]
        public List<Models.AuthorizedSigner1> AuthorizedSigners { get; set; }

        /// <summary>
        /// Guarantor information. A guarantor is the person whose credit report will be pulled during the underwriting process.
        /// </summary>
        [JsonProperty("guarantors", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Guarantor1> Guarantors { get; set; }

        /// <summary>
        /// Gets or sets Contacts.
        /// </summary>
        [JsonProperty("contacts")]
        public List<Models.Contact1> Contacts { get; set; }

        /// <summary>
        /// Gets or sets Addresses.
        /// </summary>
        [JsonProperty("addresses")]
        public List<Models.Address1> Addresses { get; set; }

        /// <summary>
        /// <![CDATA[
        /// Bank account collects bank account information from merchant. It is optional till the time of boarding where bank account becomes required along with ddaType, achType, accountNumber, routingNumber & bankName.
        /// ]]>
        /// </summary>
        [JsonProperty("bankAccount", NullValueHandling = NullValueHandling.Ignore)]
        public Models.BankAccount1 BankAccount { get; set; }

        /// <summary>
        /// Gets or sets AdvancedSettelment.
        /// </summary>
        [JsonProperty("advancedSettelment", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.AdvancedSettlementInner> AdvancedSettelment { get; set; }

        /// <summary>
        /// The agent who is submitting the deal. It is an optional object. It becomes required, when  partner wants to route deals to their own sales rep. Please work with your integration specialist for route to sales rep functionality.
        /// </summary>
        [JsonProperty("salesAgent", NullValueHandling = NullValueHandling.Ignore)]
        public Models.SalesAgent1 SalesAgent { get; set; }

        /// <summary>
        /// The Technical Agent who is going to do setup.
        /// </summary>
        [JsonProperty("installationContact", NullValueHandling = NullValueHandling.Ignore)]
        public Models.InstallationContact InstallationContact { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInformation.
        /// </summary>
        [JsonProperty("additionalInformation", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.AdditionalInformationObject> AdditionalInformation { get; set; }

        /// <summary>
        /// The source of the lead.
        /// </summary>
        [JsonProperty("leadSource", NullValueHandling = NullValueHandling.Ignore)]
        public string LeadSource { get; set; }

        /// <summary>
        /// Used to route a application to a worldpay or partner sales rep.
        /// </summary>
        [JsonProperty("routeToSalesRep", NullValueHandling = NullValueHandling.Ignore)]
        public bool? RouteToSalesRep { get; set; }

        /// <summary>
        /// Gets or sets ProductsInquiry.
        /// </summary>
        [JsonProperty("productsInquiry", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> ProductsInquiry { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Application : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is Application other &&                ((this.ClientTrackingId == null && other.ClientTrackingId == null) || (this.ClientTrackingId?.Equals(other.ClientTrackingId) == true)) &&
                ((this.BusinessInfo == null && other.BusinessInfo == null) || (this.BusinessInfo?.Equals(other.BusinessInfo) == true)) &&
                ((this.TransactionInfo == null && other.TransactionInfo == null) || (this.TransactionInfo?.Equals(other.TransactionInfo) == true)) &&
                ((this.Owners == null && other.Owners == null) || (this.Owners?.Equals(other.Owners) == true)) &&
                ((this.AuthorizedSigners == null && other.AuthorizedSigners == null) || (this.AuthorizedSigners?.Equals(other.AuthorizedSigners) == true)) &&
                ((this.Guarantors == null && other.Guarantors == null) || (this.Guarantors?.Equals(other.Guarantors) == true)) &&
                ((this.Contacts == null && other.Contacts == null) || (this.Contacts?.Equals(other.Contacts) == true)) &&
                ((this.Addresses == null && other.Addresses == null) || (this.Addresses?.Equals(other.Addresses) == true)) &&
                ((this.BankAccount == null && other.BankAccount == null) || (this.BankAccount?.Equals(other.BankAccount) == true)) &&
                ((this.AdvancedSettelment == null && other.AdvancedSettelment == null) || (this.AdvancedSettelment?.Equals(other.AdvancedSettelment) == true)) &&
                ((this.SalesAgent == null && other.SalesAgent == null) || (this.SalesAgent?.Equals(other.SalesAgent) == true)) &&
                ((this.InstallationContact == null && other.InstallationContact == null) || (this.InstallationContact?.Equals(other.InstallationContact) == true)) &&
                ((this.AdditionalInformation == null && other.AdditionalInformation == null) || (this.AdditionalInformation?.Equals(other.AdditionalInformation) == true)) &&
                ((this.LeadSource == null && other.LeadSource == null) || (this.LeadSource?.Equals(other.LeadSource) == true)) &&
                ((this.RouteToSalesRep == null && other.RouteToSalesRep == null) || (this.RouteToSalesRep?.Equals(other.RouteToSalesRep) == true)) &&
                ((this.ProductsInquiry == null && other.ProductsInquiry == null) || (this.ProductsInquiry?.Equals(other.ProductsInquiry) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientTrackingId = {(this.ClientTrackingId == null ? "null" : this.ClientTrackingId)}");
            toStringOutput.Add($"this.BusinessInfo = {(this.BusinessInfo == null ? "null" : this.BusinessInfo.ToString())}");
            toStringOutput.Add($"this.TransactionInfo = {(this.TransactionInfo == null ? "null" : this.TransactionInfo.ToString())}");
            toStringOutput.Add($"this.Owners = {(this.Owners == null ? "null" : $"[{string.Join(", ", this.Owners)} ]")}");
            toStringOutput.Add($"this.AuthorizedSigners = {(this.AuthorizedSigners == null ? "null" : $"[{string.Join(", ", this.AuthorizedSigners)} ]")}");
            toStringOutput.Add($"this.Guarantors = {(this.Guarantors == null ? "null" : $"[{string.Join(", ", this.Guarantors)} ]")}");
            toStringOutput.Add($"this.Contacts = {(this.Contacts == null ? "null" : $"[{string.Join(", ", this.Contacts)} ]")}");
            toStringOutput.Add($"this.Addresses = {(this.Addresses == null ? "null" : $"[{string.Join(", ", this.Addresses)} ]")}");
            toStringOutput.Add($"this.BankAccount = {(this.BankAccount == null ? "null" : this.BankAccount.ToString())}");
            toStringOutput.Add($"this.AdvancedSettelment = {(this.AdvancedSettelment == null ? "null" : $"[{string.Join(", ", this.AdvancedSettelment)} ]")}");
            toStringOutput.Add($"this.SalesAgent = {(this.SalesAgent == null ? "null" : this.SalesAgent.ToString())}");
            toStringOutput.Add($"this.InstallationContact = {(this.InstallationContact == null ? "null" : this.InstallationContact.ToString())}");
            toStringOutput.Add($"this.AdditionalInformation = {(this.AdditionalInformation == null ? "null" : $"[{string.Join(", ", this.AdditionalInformation)} ]")}");
            toStringOutput.Add($"this.LeadSource = {(this.LeadSource == null ? "null" : this.LeadSource)}");
            toStringOutput.Add($"this.RouteToSalesRep = {(this.RouteToSalesRep == null ? "null" : this.RouteToSalesRep.ToString())}");
            toStringOutput.Add($"this.ProductsInquiry = {(this.ProductsInquiry == null ? "null" : $"[{string.Join(", ", this.ProductsInquiry)} ]")}");
        }
    }
}