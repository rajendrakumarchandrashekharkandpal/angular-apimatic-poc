// <copyright file="ActiveMonthEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// ActiveMonthEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum ActiveMonthEnum
    {
        /// <summary>
        /// Jan.
        /// </summary>
        [EnumMember(Value = "Jan")]
        Jan,

        /// <summary>
        /// Feb.
        /// </summary>
        [EnumMember(Value = "Feb")]
        Feb,

        /// <summary>
        /// Mar.
        /// </summary>
        [EnumMember(Value = "Mar")]
        Mar,

        /// <summary>
        /// Apr.
        /// </summary>
        [EnumMember(Value = "Apr")]
        Apr,

        /// <summary>
        /// May.
        /// </summary>
        [EnumMember(Value = "May")]
        May,

        /// <summary>
        /// Jun.
        /// </summary>
        [EnumMember(Value = "Jun")]
        Jun,

        /// <summary>
        /// Jul.
        /// </summary>
        [EnumMember(Value = "Jul")]
        Jul,

        /// <summary>
        /// Aug.
        /// </summary>
        [EnumMember(Value = "Aug")]
        Aug,

        /// <summary>
        /// Sep.
        /// </summary>
        [EnumMember(Value = "Sep")]
        Sep,

        /// <summary>
        /// Oct.
        /// </summary>
        [EnumMember(Value = "Oct")]
        Oct,

        /// <summary>
        /// Nov.
        /// </summary>
        [EnumMember(Value = "Nov")]
        Nov,

        /// <summary>
        /// Dec.
        /// </summary>
        [EnumMember(Value = "Dec")]
        Dec
    }
}