// <copyright file="Type1Enum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// Type1Enum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum Type1Enum
    {
        /// <summary>
        /// EnumPrimaryContact.
        /// </summary>
        [EnumMember(Value = "Primary Contact")]
        EnumPrimaryContact,

        /// <summary>
        /// EnumAccountingContact.
        /// </summary>
        [EnumMember(Value = "Accounting Contact")]
        EnumAccountingContact,

        /// <summary>
        /// EnumCustomerServiceContact.
        /// </summary>
        [EnumMember(Value = "Customer Service Contact")]
        EnumCustomerServiceContact,

        /// <summary>
        /// EnumShippingContact.
        /// </summary>
        [EnumMember(Value = "Shipping Contact")]
        EnumShippingContact,

        /// <summary>
        /// EnumThirdPartyContact.
        /// </summary>
        [EnumMember(Value = "Third Party Contact")]
        EnumThirdPartyContact,

        /// <summary>
        /// EnumVendorContactInfo.
        /// </summary>
        [EnumMember(Value = "Vendor Contact Info")]
        EnumVendorContactInfo,

        /// <summary>
        /// EnumPCIContact.
        /// </summary>
        [EnumMember(Value = "PCI Contact")]
        EnumPCIContact,

        /// <summary>
        /// Corporate.
        /// </summary>
        [EnumMember(Value = "Corporate")]
        Corporate
    }
}