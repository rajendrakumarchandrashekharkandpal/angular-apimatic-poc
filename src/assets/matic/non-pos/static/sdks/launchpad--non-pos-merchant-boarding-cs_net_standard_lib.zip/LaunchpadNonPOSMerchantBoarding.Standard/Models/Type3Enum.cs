// <copyright file="Type3Enum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// Type3Enum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum Type3Enum
    {
        /// <summary>
        /// EnumGuarantor1Contact.
        /// </summary>
        [EnumMember(Value = "Guarantor 1 Contact")]
        EnumGuarantor1Contact,

        /// <summary>
        /// EnumGuarantor2Contact.
        /// </summary>
        [EnumMember(Value = "Guarantor 2 Contact")]
        EnumGuarantor2Contact,

        /// <summary>
        /// EnumGuarantor3Contact.
        /// </summary>
        [EnumMember(Value = "Guarantor 3 Contact")]
        EnumGuarantor3Contact,

        /// <summary>
        /// EnumGuarantor4Contact.
        /// </summary>
        [EnumMember(Value = "Guarantor 4 Contact")]
        EnumGuarantor4Contact
    }
}