// <copyright file="Identification.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Identification.
    /// </summary>
    public class Identification
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Identification"/> class.
        /// </summary>
        public Identification()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Identification"/> class.
        /// </summary>
        /// <param name="idType">idType.</param>
        /// <param name="idNumber">idNumber.</param>
        /// <param name="issuedCity">issuedCity.</param>
        /// <param name="issuedState">issuedState.</param>
        /// <param name="issuedCountry">issuedCountry.</param>
        /// <param name="dateIssued">dateIssued.</param>
        /// <param name="dateExpires">dateExpires.</param>
        public Identification(
            Models.IdTypeEnum idType,
            string idNumber,
            string issuedCity = null,
            Models.IssuedStateEnum? issuedState = null,
            string issuedCountry = null,
            DateTime? dateIssued = null,
            DateTime? dateExpires = null)
        {
            this.IdType = idType;
            this.IdNumber = idNumber;
            this.IssuedCity = issuedCity;
            this.IssuedState = issuedState;
            this.IssuedCountry = issuedCountry;
            this.DateIssued = dateIssued;
            this.DateExpires = dateExpires;
        }

        /// <summary>
        /// Type of ID provided by the owner.
        /// </summary>
        [JsonProperty("idType")]
        public Models.IdTypeEnum IdType { get; set; }

        /// <summary>
        /// Owner's ID number.
        /// </summary>
        [JsonProperty("idNumber")]
        public string IdNumber { get; set; }

        /// <summary>
        /// City in which ID was issued.
        /// </summary>
        [JsonProperty("issuedCity", NullValueHandling = NullValueHandling.Ignore)]
        public string IssuedCity { get; set; }

        /// <summary>
        /// Valid state code where ID was issued.
        /// </summary>
        [JsonProperty("issuedState", NullValueHandling = NullValueHandling.Ignore)]
        public Models.IssuedStateEnum? IssuedState { get; set; }

        /// <summary>
        /// Country where ID was issued.
        /// </summary>
        [JsonProperty("issuedCountry", NullValueHandling = NullValueHandling.Ignore)]
        public string IssuedCountry { get; set; }

        /// <summary>
        /// Date ID was issued (CCYY-MM-DD).
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("dateIssued", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? DateIssued { get; set; }

        /// <summary>
        /// Date ID expires (CCYY-MM-DD).
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("dateExpires", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? DateExpires { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Identification : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is Identification other &&                this.IdType.Equals(other.IdType) &&
                ((this.IdNumber == null && other.IdNumber == null) || (this.IdNumber?.Equals(other.IdNumber) == true)) &&
                ((this.IssuedCity == null && other.IssuedCity == null) || (this.IssuedCity?.Equals(other.IssuedCity) == true)) &&
                ((this.IssuedState == null && other.IssuedState == null) || (this.IssuedState?.Equals(other.IssuedState) == true)) &&
                ((this.IssuedCountry == null && other.IssuedCountry == null) || (this.IssuedCountry?.Equals(other.IssuedCountry) == true)) &&
                ((this.DateIssued == null && other.DateIssued == null) || (this.DateIssued?.Equals(other.DateIssued) == true)) &&
                ((this.DateExpires == null && other.DateExpires == null) || (this.DateExpires?.Equals(other.DateExpires) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.IdType = {this.IdType}");
            toStringOutput.Add($"this.IdNumber = {(this.IdNumber == null ? "null" : this.IdNumber)}");
            toStringOutput.Add($"this.IssuedCity = {(this.IssuedCity == null ? "null" : this.IssuedCity)}");
            toStringOutput.Add($"this.IssuedState = {(this.IssuedState == null ? "null" : this.IssuedState.ToString())}");
            toStringOutput.Add($"this.IssuedCountry = {(this.IssuedCountry == null ? "null" : this.IssuedCountry)}");
            toStringOutput.Add($"this.DateIssued = {(this.DateIssued == null ? "null" : this.DateIssued.ToString())}");
            toStringOutput.Add($"this.DateExpires = {(this.DateExpires == null ? "null" : this.DateExpires.ToString())}");
        }
    }
}