// <copyright file="EquipmentUpdateDeployEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// EquipmentUpdateDeployEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum EquipmentUpdateDeployEnum
    {
        /// <summary>
        /// M.
        /// </summary>
        [EnumMember(Value = "M")]
        M,

        /// <summary>
        /// D.
        /// </summary>
        [EnumMember(Value = "D")]
        D,

        /// <summary>
        /// N.
        /// </summary>
        [EnumMember(Value = "N")]
        N
    }
}