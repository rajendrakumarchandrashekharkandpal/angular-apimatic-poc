// <copyright file="TypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// TypeEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum TypeEnum
    {
        /// <summary>
        /// EnumControlOwnerContact.
        /// </summary>
        [EnumMember(Value = "Control Owner Contact")]
        EnumControlOwnerContact,

        /// <summary>
        /// EnumOwner1Contact.
        /// </summary>
        [EnumMember(Value = "Owner 1 Contact")]
        EnumOwner1Contact,

        /// <summary>
        /// EnumOwner2Contact.
        /// </summary>
        [EnumMember(Value = "Owner 2 Contact")]
        EnumOwner2Contact,

        /// <summary>
        /// EnumOwner3Contact.
        /// </summary>
        [EnumMember(Value = "Owner 3 Contact")]
        EnumOwner3Contact,

        /// <summary>
        /// EnumOwner4Contact.
        /// </summary>
        [EnumMember(Value = "Owner 4 Contact")]
        EnumOwner4Contact
    }
}