// <copyright file="InstallationContact.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// InstallationContact.
    /// </summary>
    public class InstallationContact
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InstallationContact"/> class.
        /// </summary>
        public InstallationContact()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="InstallationContact"/> class.
        /// </summary>
        /// <param name="firstName">firstName.</param>
        /// <param name="lastName">lastName.</param>
        /// <param name="email">email.</param>
        /// <param name="id">id.</param>
        /// <param name="mobilePhoneNumber">mobilePhoneNumber.</param>
        public InstallationContact(
            string firstName,
            string lastName,
            string email,
            string id = null,
            string mobilePhoneNumber = null)
        {
            this.Id = id;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.MobilePhoneNumber = mobilePhoneNumber;
            this.Email = email;
        }

        /// <summary>
        /// Id for Technical Contact
        /// </summary>
        [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
        public string Id { get; set; }

        /// <summary>
        /// Contact's first name.
        /// </summary>
        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        /// <summary>
        /// Contact's last name.
        /// </summary>
        [JsonProperty("lastName")]
        public string LastName { get; set; }

        /// <summary>
        /// Contact's 10-digit phone number of the format 5131234567.
        /// </summary>
        [JsonProperty("mobilePhoneNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string MobilePhoneNumber { get; set; }

        /// <summary>
        /// Contact's email address. Must have @ and a .
        /// </summary>
        [JsonProperty("email")]
        public string Email { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"InstallationContact : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is InstallationContact other &&                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.FirstName == null && other.FirstName == null) || (this.FirstName?.Equals(other.FirstName) == true)) &&
                ((this.LastName == null && other.LastName == null) || (this.LastName?.Equals(other.LastName) == true)) &&
                ((this.MobilePhoneNumber == null && other.MobilePhoneNumber == null) || (this.MobilePhoneNumber?.Equals(other.MobilePhoneNumber) == true)) &&
                ((this.Email == null && other.Email == null) || (this.Email?.Equals(other.Email) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id)}");
            toStringOutput.Add($"this.FirstName = {(this.FirstName == null ? "null" : this.FirstName)}");
            toStringOutput.Add($"this.LastName = {(this.LastName == null ? "null" : this.LastName)}");
            toStringOutput.Add($"this.MobilePhoneNumber = {(this.MobilePhoneNumber == null ? "null" : this.MobilePhoneNumber)}");
            toStringOutput.Add($"this.Email = {(this.Email == null ? "null" : this.Email)}");
        }
    }
}