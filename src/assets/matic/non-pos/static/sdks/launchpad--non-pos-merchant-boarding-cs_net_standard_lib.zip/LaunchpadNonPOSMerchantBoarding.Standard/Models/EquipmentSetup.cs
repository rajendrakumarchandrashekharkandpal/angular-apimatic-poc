// <copyright file="EquipmentSetup.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// EquipmentSetup.
    /// </summary>
    public class EquipmentSetup
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentSetup"/> class.
        /// </summary>
        public EquipmentSetup()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentSetup"/> class.
        /// </summary>
        /// <param name="shippingOption">shippingOption.</param>
        /// <param name="terminals">terminals.</param>
        public EquipmentSetup(
            Models.ShippingOptionEnum? shippingOption = Models.ShippingOptionEnum.EnumNextDay,
            List<Models.Terminal> terminals = null)
        {
            this.ShippingOption = shippingOption;
            this.Terminals = terminals;
        }

        /// <summary>
        /// The speed you would like the equipment to be shipped.
        /// </summary>
        [JsonProperty("shippingOption", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ShippingOptionEnum? ShippingOption { get; set; }

        /// <summary>
        /// Gets or sets Terminals.
        /// </summary>
        [JsonProperty("terminals", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Terminal> Terminals { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"EquipmentSetup : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is EquipmentSetup other &&                ((this.ShippingOption == null && other.ShippingOption == null) || (this.ShippingOption?.Equals(other.ShippingOption) == true)) &&
                ((this.Terminals == null && other.Terminals == null) || (this.Terminals?.Equals(other.Terminals) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ShippingOption = {(this.ShippingOption == null ? "null" : this.ShippingOption.ToString())}");
            toStringOutput.Add($"this.Terminals = {(this.Terminals == null ? "null" : $"[{string.Join(", ", this.Terminals)} ]")}");
        }
    }
}