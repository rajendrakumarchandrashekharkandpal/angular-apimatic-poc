// <copyright file="AdditionalConfigurationCustomization.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AdditionalConfigurationCustomization.
    /// </summary>
    public class AdditionalConfigurationCustomization
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AdditionalConfigurationCustomization"/> class.
        /// </summary>
        public AdditionalConfigurationCustomization()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AdditionalConfigurationCustomization"/> class.
        /// </summary>
        /// <param name="customizationId">customizationId.</param>
        /// <param name="customizationType">customizationType.</param>
        /// <param name="useProductMatrix">useProductMatrix.</param>
        /// <param name="productId">productId.</param>
        /// <param name="code">code.</param>
        /// <param name="customizationCodeDetails">customizationCodeDetails.</param>
        /// <param name="customizationValue">customizationValue.</param>
        /// <param name="customizationFieldLength">customizationFieldLength.</param>
        /// <param name="customizationDecimalPlace">customizationDecimalPlace.</param>
        /// <param name="customizationMinValue">customizationMinValue.</param>
        /// <param name="customizationMaxValue">customizationMaxValue.</param>
        /// <param name="charactersAllowed">charactersAllowed.</param>
        /// <param name="rule">rule.</param>
        /// <param name="regex">regex.</param>
        /// <param name="multiMerchantFlag">multiMerchantFlag.</param>
        /// <param name="shortDescription">shortDescription.</param>
        /// <param name="longDescription">longDescription.</param>
        public AdditionalConfigurationCustomization(
            string customizationId = null,
            string customizationType = null,
            string useProductMatrix = null,
            string productId = null,
            string code = null,
            List<Models.CustomizationCodeDetails> customizationCodeDetails = null,
            string customizationValue = null,
            string customizationFieldLength = null,
            string customizationDecimalPlace = null,
            string customizationMinValue = null,
            string customizationMaxValue = null,
            string charactersAllowed = null,
            string rule = null,
            string regex = null,
            bool? multiMerchantFlag = false,
            string shortDescription = null,
            string longDescription = null)
        {
            this.CustomizationId = customizationId;
            this.CustomizationType = customizationType;
            this.UseProductMatrix = useProductMatrix;
            this.ProductId = productId;
            this.Code = code;
            this.CustomizationCodeDetails = customizationCodeDetails;
            this.CustomizationValue = customizationValue;
            this.CustomizationFieldLength = customizationFieldLength;
            this.CustomizationDecimalPlace = customizationDecimalPlace;
            this.CustomizationMinValue = customizationMinValue;
            this.CustomizationMaxValue = customizationMaxValue;
            this.CharactersAllowed = charactersAllowed;
            this.Rule = rule;
            this.Regex = regex;
            this.MultiMerchantFlag = multiMerchantFlag;
            this.ShortDescription = shortDescription;
            this.LongDescription = longDescription;
        }

        /// <summary>
        /// Customization Id is internally populated from a master list.
        /// </summary>
        [JsonProperty("customizationId", NullValueHandling = NullValueHandling.Ignore)]
        public string CustomizationId { get; set; }

        /// <summary>
        /// type of customization
        /// </summary>
        [JsonProperty("customizationType", NullValueHandling = NullValueHandling.Ignore)]
        public string CustomizationType { get; set; }

        /// <summary>
        /// Whether or not used in product matrix
        /// </summary>
        [JsonProperty("useProductMatrix", NullValueHandling = NullValueHandling.Ignore)]
        public string UseProductMatrix { get; set; }

        /// <summary>
        /// unique ID for the product
        /// </summary>
        [JsonProperty("productId", NullValueHandling = NullValueHandling.Ignore)]
        public string ProductId { get; set; }

        /// <summary>
        /// product code
        /// </summary>
        [JsonProperty("code", NullValueHandling = NullValueHandling.Ignore)]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets CustomizationCodeDetails.
        /// </summary>
        [JsonProperty("customizationCodeDetails", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.CustomizationCodeDetails> CustomizationCodeDetails { get; set; }

        /// <summary>
        /// Actual Customization Value
        /// </summary>
        [JsonProperty("customizationValue", NullValueHandling = NullValueHandling.Ignore)]
        public string CustomizationValue { get; set; }

        /// <summary>
        /// Length of the customization value
        /// </summary>
        [JsonProperty("customizationFieldLength", NullValueHandling = NullValueHandling.Ignore)]
        public string CustomizationFieldLength { get; set; }

        /// <summary>
        /// Number of decimal places
        /// </summary>
        [JsonProperty("customizationDecimalPlace", NullValueHandling = NullValueHandling.Ignore)]
        public string CustomizationDecimalPlace { get; set; }

        /// <summary>
        /// Minimum Value. Only applicable if the customization value is a number
        /// </summary>
        [JsonProperty("customizationMinValue", NullValueHandling = NullValueHandling.Ignore)]
        public string CustomizationMinValue { get; set; }

        /// <summary>
        /// Maximum Value. Only applicable if the customization value is a number
        /// </summary>
        [JsonProperty("customizationMaxValue", NullValueHandling = NullValueHandling.Ignore)]
        public string CustomizationMaxValue { get; set; }

        /// <summary>
        /// All characters allowed for customization. Only applicable if the customization value is a string.
        /// </summary>
        [JsonProperty("charactersAllowed", NullValueHandling = NullValueHandling.Ignore)]
        public string CharactersAllowed { get; set; }

        /// <summary>
        /// customization rule
        /// </summary>
        [JsonProperty("rule", NullValueHandling = NullValueHandling.Ignore)]
        public string Rule { get; set; }

        /// <summary>
        /// Regular expression to validate the customization value
        /// </summary>
        [JsonProperty("regex", NullValueHandling = NullValueHandling.Ignore)]
        public string Regex { get; set; }

        /// <summary>
        /// Applicable in a multiple merchant situation
        /// </summary>
        [JsonProperty("multiMerchantFlag", NullValueHandling = NullValueHandling.Ignore)]
        public bool? MultiMerchantFlag { get; set; }

        /// <summary>
        /// Description of the customization
        /// </summary>
        [JsonProperty("shortDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string ShortDescription { get; set; }

        /// <summary>
        /// Verbose description of the customiztion
        /// </summary>
        [JsonProperty("longDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string LongDescription { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AdditionalConfigurationCustomization : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AdditionalConfigurationCustomization other &&                ((this.CustomizationId == null && other.CustomizationId == null) || (this.CustomizationId?.Equals(other.CustomizationId) == true)) &&
                ((this.CustomizationType == null && other.CustomizationType == null) || (this.CustomizationType?.Equals(other.CustomizationType) == true)) &&
                ((this.UseProductMatrix == null && other.UseProductMatrix == null) || (this.UseProductMatrix?.Equals(other.UseProductMatrix) == true)) &&
                ((this.ProductId == null && other.ProductId == null) || (this.ProductId?.Equals(other.ProductId) == true)) &&
                ((this.Code == null && other.Code == null) || (this.Code?.Equals(other.Code) == true)) &&
                ((this.CustomizationCodeDetails == null && other.CustomizationCodeDetails == null) || (this.CustomizationCodeDetails?.Equals(other.CustomizationCodeDetails) == true)) &&
                ((this.CustomizationValue == null && other.CustomizationValue == null) || (this.CustomizationValue?.Equals(other.CustomizationValue) == true)) &&
                ((this.CustomizationFieldLength == null && other.CustomizationFieldLength == null) || (this.CustomizationFieldLength?.Equals(other.CustomizationFieldLength) == true)) &&
                ((this.CustomizationDecimalPlace == null && other.CustomizationDecimalPlace == null) || (this.CustomizationDecimalPlace?.Equals(other.CustomizationDecimalPlace) == true)) &&
                ((this.CustomizationMinValue == null && other.CustomizationMinValue == null) || (this.CustomizationMinValue?.Equals(other.CustomizationMinValue) == true)) &&
                ((this.CustomizationMaxValue == null && other.CustomizationMaxValue == null) || (this.CustomizationMaxValue?.Equals(other.CustomizationMaxValue) == true)) &&
                ((this.CharactersAllowed == null && other.CharactersAllowed == null) || (this.CharactersAllowed?.Equals(other.CharactersAllowed) == true)) &&
                ((this.Rule == null && other.Rule == null) || (this.Rule?.Equals(other.Rule) == true)) &&
                ((this.Regex == null && other.Regex == null) || (this.Regex?.Equals(other.Regex) == true)) &&
                ((this.MultiMerchantFlag == null && other.MultiMerchantFlag == null) || (this.MultiMerchantFlag?.Equals(other.MultiMerchantFlag) == true)) &&
                ((this.ShortDescription == null && other.ShortDescription == null) || (this.ShortDescription?.Equals(other.ShortDescription) == true)) &&
                ((this.LongDescription == null && other.LongDescription == null) || (this.LongDescription?.Equals(other.LongDescription) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CustomizationId = {(this.CustomizationId == null ? "null" : this.CustomizationId)}");
            toStringOutput.Add($"this.CustomizationType = {(this.CustomizationType == null ? "null" : this.CustomizationType)}");
            toStringOutput.Add($"this.UseProductMatrix = {(this.UseProductMatrix == null ? "null" : this.UseProductMatrix)}");
            toStringOutput.Add($"this.ProductId = {(this.ProductId == null ? "null" : this.ProductId)}");
            toStringOutput.Add($"this.Code = {(this.Code == null ? "null" : this.Code)}");
            toStringOutput.Add($"this.CustomizationCodeDetails = {(this.CustomizationCodeDetails == null ? "null" : $"[{string.Join(", ", this.CustomizationCodeDetails)} ]")}");
            toStringOutput.Add($"this.CustomizationValue = {(this.CustomizationValue == null ? "null" : this.CustomizationValue)}");
            toStringOutput.Add($"this.CustomizationFieldLength = {(this.CustomizationFieldLength == null ? "null" : this.CustomizationFieldLength)}");
            toStringOutput.Add($"this.CustomizationDecimalPlace = {(this.CustomizationDecimalPlace == null ? "null" : this.CustomizationDecimalPlace)}");
            toStringOutput.Add($"this.CustomizationMinValue = {(this.CustomizationMinValue == null ? "null" : this.CustomizationMinValue)}");
            toStringOutput.Add($"this.CustomizationMaxValue = {(this.CustomizationMaxValue == null ? "null" : this.CustomizationMaxValue)}");
            toStringOutput.Add($"this.CharactersAllowed = {(this.CharactersAllowed == null ? "null" : this.CharactersAllowed)}");
            toStringOutput.Add($"this.Rule = {(this.Rule == null ? "null" : this.Rule)}");
            toStringOutput.Add($"this.Regex = {(this.Regex == null ? "null" : this.Regex)}");
            toStringOutput.Add($"this.MultiMerchantFlag = {(this.MultiMerchantFlag == null ? "null" : this.MultiMerchantFlag.ToString())}");
            toStringOutput.Add($"this.ShortDescription = {(this.ShortDescription == null ? "null" : this.ShortDescription)}");
            toStringOutput.Add($"this.LongDescription = {(this.LongDescription == null ? "null" : this.LongDescription)}");
        }
    }
}