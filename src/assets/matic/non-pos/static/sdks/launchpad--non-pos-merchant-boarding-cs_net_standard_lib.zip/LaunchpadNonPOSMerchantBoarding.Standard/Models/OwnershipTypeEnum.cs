// <copyright file="OwnershipTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// OwnershipTypeEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum OwnershipTypeEnum
    {
        /// <summary>
        /// GOVERNMENT.
        /// </summary>
        [EnumMember(Value = "GOVERNMENT")]
        GOVERNMENT,

        /// <summary>
        /// EnumSOLEPROPRIETOR.
        /// </summary>
        [EnumMember(Value = "SOLE PROPRIETOR")]
        EnumSOLEPROPRIETOR,

        /// <summary>
        /// LLC.
        /// </summary>
        [EnumMember(Value = "LLC")]
        LLC,

        /// <summary>
        /// PARTNERSHIP.
        /// </summary>
        [EnumMember(Value = "PARTNERSHIP")]
        PARTNERSHIP,

        /// <summary>
        /// EnumFININSTITUTION.
        /// </summary>
        [EnumMember(Value = "FIN INSTITUTION")]
        EnumFININSTITUTION,

        /// <summary>
        /// NONPROFIT.
        /// </summary>
        [EnumMember(Value = "NON-PROFIT")]
        NONPROFIT,

        /// <summary>
        /// EnumASSOCIATIONESTATETRUST.
        /// </summary>
        [EnumMember(Value = "ASSOCIATION/ESTATE/TRUST")]
        EnumASSOCIATIONESTATETRUST,

        /// <summary>
        /// EnumPRIVATECORPORATION.
        /// </summary>
        [EnumMember(Value = "PRIVATE CORPORATION")]
        EnumPRIVATECORPORATION,

        /// <summary>
        /// EnumSECREGISTERED.
        /// </summary>
        [EnumMember(Value = "SEC REGISTERED")]
        EnumSECREGISTERED,

        /// <summary>
        /// EnumPUBLICCORPORATION.
        /// </summary>
        [EnumMember(Value = "PUBLIC CORPORATION")]
        EnumPUBLICCORPORATION,

        /// <summary>
        /// OTHER.
        /// </summary>
        [EnumMember(Value = "OTHER")]
        OTHER
    }
}