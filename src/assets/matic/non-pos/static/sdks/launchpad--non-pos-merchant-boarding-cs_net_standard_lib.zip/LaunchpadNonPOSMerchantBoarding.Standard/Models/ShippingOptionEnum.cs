// <copyright file="ShippingOptionEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// ShippingOptionEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum ShippingOptionEnum
    {
        /// <summary>
        /// Ground.
        /// </summary>
        [EnumMember(Value = "ground")]
        Ground,

        /// <summary>
        /// EnumNextDay.
        /// </summary>
        [EnumMember(Value = "next day")]
        EnumNextDay,

        /// <summary>
        /// Enum2ndDay.
        /// </summary>
        [EnumMember(Value = "2nd day")]
        Enum2ndDay
    }
}