// <copyright file="EquipmentLookupController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Exceptions;
    using LaunchpadNonPOSMerchantBoarding.Standard.Http.Client;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// EquipmentLookupController.
    /// </summary>
    public class EquipmentLookupController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="EquipmentLookupController"/> class.
        /// </summary>
        internal EquipmentLookupController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Retrieve applicable equipment for an existing application.
        /// </summary>
        /// <param name="externalRefId">Required parameter: The externalRefId returned from POST /applications call..</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <returns>Returns the Models.InlineResponse200 response from the API call.</returns>
        public Models.InlineResponse200 GetEquipmentSupported(
                Guid externalRefId,
                Guid? vCorrelationId = null)
            => CoreHelper.RunTask(GetEquipmentSupportedAsync(externalRefId, vCorrelationId));

        /// <summary>
        /// Retrieve applicable equipment for an existing application.
        /// </summary>
        /// <param name="externalRefId">Required parameter: The externalRefId returned from POST /applications call..</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.InlineResponse200 response from the API call.</returns>
        public async Task<Models.InlineResponse200> GetEquipmentSupportedAsync(
                Guid externalRefId,
                Guid? vCorrelationId = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.InlineResponse200>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/equipment/supported")
                  .WithAuth("api_key")
                  .Parameters(_parameters => _parameters
                      .Header(_header => _header.Setup("externalRefId", externalRefId))
                      .Header(_header => _header.Setup("v-correlation-id", vCorrelationId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("0", CreateErrorCase("Default errors", (_reason, _context) => new ErrorResponseException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Fetches a list of valid terminal customizations and peripherals, such as electing to password protect a void.
        /// </summary>
        /// <param name="externalRefId">Required parameter: The externalRefId returned from POST /applications call..</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="logicalApplicationId">Optional parameter: Logical App ID of the terminal..</param>
        /// <returns>Returns the Models.AdditionalConfigurationsResponse response from the API call.</returns>
        public Models.AdditionalConfigurationsResponse GetAdditionalConfigurations(
                Guid externalRefId,
                Guid? vCorrelationId = null,
                string logicalApplicationId = null)
            => CoreHelper.RunTask(GetAdditionalConfigurationsAsync(externalRefId, vCorrelationId, logicalApplicationId));

        /// <summary>
        /// Fetches a list of valid terminal customizations and peripherals, such as electing to password protect a void.
        /// </summary>
        /// <param name="externalRefId">Required parameter: The externalRefId returned from POST /applications call..</param>
        /// <param name="vCorrelationId">Optional parameter: Unique transaction Id. Will be generated if not provided and returned in response headers..</param>
        /// <param name="logicalApplicationId">Optional parameter: Logical App ID of the terminal..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.AdditionalConfigurationsResponse response from the API call.</returns>
        public async Task<Models.AdditionalConfigurationsResponse> GetAdditionalConfigurationsAsync(
                Guid externalRefId,
                Guid? vCorrelationId = null,
                string logicalApplicationId = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.AdditionalConfigurationsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/terminal/additional-configurations")
                  .WithAuth("api_key")
                  .Parameters(_parameters => _parameters
                      .Header(_header => _header.Setup("externalRefId", externalRefId))
                      .Header(_header => _header.Setup("v-correlation-id", vCorrelationId))
                      .Header(_header => _header.Setup("logicalApplicationId", logicalApplicationId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("0", CreateErrorCase("Default errors", (_reason, _context) => new ErrorResponseException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}