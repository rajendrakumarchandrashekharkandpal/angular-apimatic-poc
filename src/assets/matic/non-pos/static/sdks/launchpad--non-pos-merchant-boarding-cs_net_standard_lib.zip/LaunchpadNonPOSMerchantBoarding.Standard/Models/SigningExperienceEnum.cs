// <copyright file="SigningExperienceEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// SigningExperienceEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum SigningExperienceEnum
    {
        /// <summary>
        /// Embed.
        /// </summary>
        [EnumMember(Value = "embed")]
        Embed,

        /// <summary>
        /// Email.
        /// </summary>
        [EnumMember(Value = "email")]
        Email,

        /// <summary>
        /// Wet.
        /// </summary>
        [EnumMember(Value = "wet")]
        Wet
    }
}