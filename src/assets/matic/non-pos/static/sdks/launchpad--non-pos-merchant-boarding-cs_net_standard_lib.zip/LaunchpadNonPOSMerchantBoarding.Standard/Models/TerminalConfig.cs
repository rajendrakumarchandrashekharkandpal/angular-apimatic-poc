// <copyright file="TerminalConfig.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// TerminalConfig.
    /// </summary>
    public class TerminalConfig
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TerminalConfig"/> class.
        /// </summary>
        public TerminalConfig()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TerminalConfig"/> class.
        /// </summary>
        /// <param name="terminalId">terminalId.</param>
        /// <param name="price">price.</param>
        /// <param name="quantity">quantity.</param>
        /// <param name="logicalApplicationId">logicalApplicationId.</param>
        /// <param name="accessMethod">accessMethod.</param>
        /// <param name="paymentMethod">paymentMethod.</param>
        /// <param name="environmentName">environmentName.</param>
        /// <param name="requestId">requestId.</param>
        /// <param name="terminalModel">terminalModel.</param>
        /// <param name="isVar">isVar.</param>
        /// <param name="emvCapable">emvCapable.</param>
        /// <param name="leaseId">leaseId.</param>
        /// <param name="leaseTermLength">leaseTermLength.</param>
        /// <param name="terminalSequenceNumber">terminalSequenceNumber.</param>
        /// <param name="specialCustomizations">specialCustomizations.</param>
        public TerminalConfig(
            string terminalId,
            double price,
            int quantity,
            string logicalApplicationId,
            string accessMethod,
            Models.PaymentMethodEnum paymentMethod,
            string environmentName,
            string requestId = null,
            string terminalModel = null,
            bool? isVar = false,
            bool? emvCapable = false,
            string leaseId = null,
            Models.LeaseTermLengthEnum? leaseTermLength = null,
            string terminalSequenceNumber = null,
            string specialCustomizations = null)
        {
            this.RequestId = requestId;
            this.TerminalId = terminalId;
            this.TerminalModel = terminalModel;
            this.Price = price;
            this.Quantity = quantity;
            this.LogicalApplicationId = logicalApplicationId;
            this.AccessMethod = accessMethod;
            this.PaymentMethod = paymentMethod;
            this.EnvironmentName = environmentName;
            this.IsVar = isVar;
            this.EmvCapable = emvCapable;
            this.LeaseId = leaseId;
            this.LeaseTermLength = leaseTermLength;
            this.TerminalSequenceNumber = terminalSequenceNumber;
            this.SpecialCustomizations = specialCustomizations;
        }

        /// <summary>
        /// Partner assigned unique request ID for terminal setup.
        /// </summary>
        [JsonProperty("requestId", NullValueHandling = NullValueHandling.Ignore)]
        public string RequestId { get; set; }

        /// <summary>
        /// Terminal ID number.
        /// </summary>
        [JsonProperty("terminalId")]
        public string TerminalId { get; set; }

        /// <summary>
        /// The model name of the terminal in use.
        /// </summary>
        [JsonProperty("terminalModel", NullValueHandling = NullValueHandling.Ignore)]
        public string TerminalModel { get; set; }

        /// <summary>
        /// Terminal price
        /// </summary>
        [JsonProperty("price")]
        public double Price { get; set; }

        /// <summary>
        /// Gets or sets Quantity.
        /// </summary>
        [JsonProperty("quantity")]
        public int Quantity { get; set; }

        /// <summary>
        /// Logical application ID.
        /// </summary>
        [JsonProperty("logicalApplicationId")]
        public string LogicalApplicationId { get; set; }

        /// <summary>
        /// Methods of terminal access.
        /// </summary>
        [JsonProperty("accessMethod")]
        public string AccessMethod { get; set; }

        /// <summary>
        /// Payment method for the selected terminal.
        /// </summary>
        [JsonProperty("paymentMethod")]
        public Models.PaymentMethodEnum PaymentMethod { get; set; }

        /// <summary>
        /// Environment name
        /// </summary>
        [JsonProperty("environmentName")]
        public string EnvironmentName { get; set; }

        /// <summary>
        /// The value added reseller. Default value is false.
        /// </summary>
        [JsonProperty("isVar", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsVar { get; set; }

        /// <summary>
        /// Is it EMV capabale?
        /// </summary>
        [JsonProperty("emvCapable", NullValueHandling = NullValueHandling.Ignore)]
        public bool? EmvCapable { get; set; }

        /// <summary>
        /// Lease ID. Required when PaymentMethod is selected as lease.
        /// </summary>
        [JsonProperty("leaseId", NullValueHandling = NullValueHandling.Ignore)]
        public string LeaseId { get; set; }

        /// <summary>
        /// Lease term for the peripheral
        /// </summary>
        [JsonProperty("leaseTermLength", NullValueHandling = NullValueHandling.Ignore)]
        public Models.LeaseTermLengthEnum? LeaseTermLength { get; set; }

        /// <summary>
        /// Terminal sequence number. If not sent, the API will autogenerate a number.
        /// </summary>
        [JsonProperty("terminalSequenceNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string TerminalSequenceNumber { get; set; }

        /// <summary>
        /// Any customization request for a terminal configuration.
        /// </summary>
        [JsonProperty("specialCustomizations", NullValueHandling = NullValueHandling.Ignore)]
        public string SpecialCustomizations { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"TerminalConfig : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is TerminalConfig other &&                ((this.RequestId == null && other.RequestId == null) || (this.RequestId?.Equals(other.RequestId) == true)) &&
                ((this.TerminalId == null && other.TerminalId == null) || (this.TerminalId?.Equals(other.TerminalId) == true)) &&
                ((this.TerminalModel == null && other.TerminalModel == null) || (this.TerminalModel?.Equals(other.TerminalModel) == true)) &&
                this.Price.Equals(other.Price) &&
                this.Quantity.Equals(other.Quantity) &&
                ((this.LogicalApplicationId == null && other.LogicalApplicationId == null) || (this.LogicalApplicationId?.Equals(other.LogicalApplicationId) == true)) &&
                ((this.AccessMethod == null && other.AccessMethod == null) || (this.AccessMethod?.Equals(other.AccessMethod) == true)) &&
                this.PaymentMethod.Equals(other.PaymentMethod) &&
                ((this.EnvironmentName == null && other.EnvironmentName == null) || (this.EnvironmentName?.Equals(other.EnvironmentName) == true)) &&
                ((this.IsVar == null && other.IsVar == null) || (this.IsVar?.Equals(other.IsVar) == true)) &&
                ((this.EmvCapable == null && other.EmvCapable == null) || (this.EmvCapable?.Equals(other.EmvCapable) == true)) &&
                ((this.LeaseId == null && other.LeaseId == null) || (this.LeaseId?.Equals(other.LeaseId) == true)) &&
                ((this.LeaseTermLength == null && other.LeaseTermLength == null) || (this.LeaseTermLength?.Equals(other.LeaseTermLength) == true)) &&
                ((this.TerminalSequenceNumber == null && other.TerminalSequenceNumber == null) || (this.TerminalSequenceNumber?.Equals(other.TerminalSequenceNumber) == true)) &&
                ((this.SpecialCustomizations == null && other.SpecialCustomizations == null) || (this.SpecialCustomizations?.Equals(other.SpecialCustomizations) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.RequestId = {(this.RequestId == null ? "null" : this.RequestId)}");
            toStringOutput.Add($"this.TerminalId = {(this.TerminalId == null ? "null" : this.TerminalId)}");
            toStringOutput.Add($"this.TerminalModel = {(this.TerminalModel == null ? "null" : this.TerminalModel)}");
            toStringOutput.Add($"this.Price = {this.Price}");
            toStringOutput.Add($"this.Quantity = {this.Quantity}");
            toStringOutput.Add($"this.LogicalApplicationId = {(this.LogicalApplicationId == null ? "null" : this.LogicalApplicationId)}");
            toStringOutput.Add($"this.AccessMethod = {(this.AccessMethod == null ? "null" : this.AccessMethod)}");
            toStringOutput.Add($"this.PaymentMethod = {this.PaymentMethod}");
            toStringOutput.Add($"this.EnvironmentName = {(this.EnvironmentName == null ? "null" : this.EnvironmentName)}");
            toStringOutput.Add($"this.IsVar = {(this.IsVar == null ? "null" : this.IsVar.ToString())}");
            toStringOutput.Add($"this.EmvCapable = {(this.EmvCapable == null ? "null" : this.EmvCapable.ToString())}");
            toStringOutput.Add($"this.LeaseId = {(this.LeaseId == null ? "null" : this.LeaseId)}");
            toStringOutput.Add($"this.LeaseTermLength = {(this.LeaseTermLength == null ? "null" : this.LeaseTermLength.ToString())}");
            toStringOutput.Add($"this.TerminalSequenceNumber = {(this.TerminalSequenceNumber == null ? "null" : this.TerminalSequenceNumber)}");
            toStringOutput.Add($"this.SpecialCustomizations = {(this.SpecialCustomizations == null ? "null" : this.SpecialCustomizations)}");
        }
    }
}