// <copyright file="StatusHistory.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// StatusHistory.
    /// </summary>
    public class StatusHistory
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StatusHistory"/> class.
        /// </summary>
        public StatusHistory()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="StatusHistory"/> class.
        /// </summary>
        /// <param name="statusSeqNumber">statusSeqNumber.</param>
        /// <param name="detailStatus">detailStatus.</param>
        /// <param name="summaryStatus">summaryStatus.</param>
        /// <param name="statusCategory">statusCategory.</param>
        /// <param name="statusDateTime">statusDateTime.</param>
        public StatusHistory(
            int? statusSeqNumber = null,
            string detailStatus = null,
            string summaryStatus = null,
            string statusCategory = null,
            DateTime? statusDateTime = null)
        {
            this.StatusSeqNumber = statusSeqNumber;
            this.DetailStatus = detailStatus;
            this.SummaryStatus = summaryStatus;
            this.StatusCategory = statusCategory;
            this.StatusDateTime = statusDateTime;
        }

        /// <summary>
        /// Gets or sets StatusSeqNumber.
        /// </summary>
        [JsonProperty("statusSeqNumber", NullValueHandling = NullValueHandling.Ignore)]
        public int? StatusSeqNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailStatus.
        /// </summary>
        [JsonProperty("detailStatus", NullValueHandling = NullValueHandling.Ignore)]
        public string DetailStatus { get; set; }

        /// <summary>
        /// Gets or sets SummaryStatus.
        /// </summary>
        [JsonProperty("summaryStatus", NullValueHandling = NullValueHandling.Ignore)]
        public string SummaryStatus { get; set; }

        /// <summary>
        /// Gets or sets StatusCategory.
        /// </summary>
        [JsonProperty("statusCategory", NullValueHandling = NullValueHandling.Ignore)]
        public string StatusCategory { get; set; }

        /// <summary>
        /// Gets or sets StatusDateTime.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("statusDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StatusDateTime { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"StatusHistory : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is StatusHistory other &&                ((this.StatusSeqNumber == null && other.StatusSeqNumber == null) || (this.StatusSeqNumber?.Equals(other.StatusSeqNumber) == true)) &&
                ((this.DetailStatus == null && other.DetailStatus == null) || (this.DetailStatus?.Equals(other.DetailStatus) == true)) &&
                ((this.SummaryStatus == null && other.SummaryStatus == null) || (this.SummaryStatus?.Equals(other.SummaryStatus) == true)) &&
                ((this.StatusCategory == null && other.StatusCategory == null) || (this.StatusCategory?.Equals(other.StatusCategory) == true)) &&
                ((this.StatusDateTime == null && other.StatusDateTime == null) || (this.StatusDateTime?.Equals(other.StatusDateTime) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.StatusSeqNumber = {(this.StatusSeqNumber == null ? "null" : this.StatusSeqNumber.ToString())}");
            toStringOutput.Add($"this.DetailStatus = {(this.DetailStatus == null ? "null" : this.DetailStatus)}");
            toStringOutput.Add($"this.SummaryStatus = {(this.SummaryStatus == null ? "null" : this.SummaryStatus)}");
            toStringOutput.Add($"this.StatusCategory = {(this.StatusCategory == null ? "null" : this.StatusCategory)}");
            toStringOutput.Add($"this.StatusDateTime = {(this.StatusDateTime == null ? "null" : this.StatusDateTime.ToString())}");
        }
    }
}