// <copyright file="Terminal.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Terminal.
    /// </summary>
    public class Terminal
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Terminal"/> class.
        /// </summary>
        public Terminal()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Terminal"/> class.
        /// </summary>
        /// <param name="terminalConfigs">terminalConfigs.</param>
        /// <param name="products">products.</param>
        /// <param name="customizations">customizations.</param>
        /// <param name="peripherals">peripherals.</param>
        /// <param name="vendors">vendors.</param>
        /// <param name="gateways">gateways.</param>
        /// <param name="supply">supply.</param>
        /// <param name="deployment">deployment.</param>
        public Terminal(
            Models.TerminalConfig terminalConfigs,
            List<Models.Product> products,
            List<Models.TerminalCustomization> customizations = null,
            List<Models.Peripheral> peripherals = null,
            List<Models.PaymentApplicationVendor> vendors = null,
            List<Models.Gateway> gateways = null,
            List<Models.TerminalSupply> supply = null,
            Models.TerminalDeployment deployment = null)
        {
            this.TerminalConfigs = terminalConfigs;
            this.Customizations = customizations;
            this.Products = products;
            this.Peripherals = peripherals;
            this.Vendors = vendors;
            this.Gateways = gateways;
            this.Supply = supply;
            this.Deployment = deployment;
        }

        /// <summary>
        /// Gets or sets TerminalConfigs.
        /// </summary>
        [JsonProperty("terminalConfigs")]
        public Models.TerminalConfig TerminalConfigs { get; set; }

        /// <summary>
        /// Gets or sets Customizations.
        /// </summary>
        [JsonProperty("customizations", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.TerminalCustomization> Customizations { get; set; }

        /// <summary>
        /// Gets or sets Products.
        /// </summary>
        [JsonProperty("products")]
        public List<Models.Product> Products { get; set; }

        /// <summary>
        /// Gets or sets Peripherals.
        /// </summary>
        [JsonProperty("peripherals", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Peripheral> Peripherals { get; set; }

        /// <summary>
        /// Gets or sets Vendors.
        /// </summary>
        [JsonProperty("vendors", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.PaymentApplicationVendor> Vendors { get; set; }

        /// <summary>
        /// Gets or sets Gateways.
        /// </summary>
        [JsonProperty("gateways", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Gateway> Gateways { get; set; }

        /// <summary>
        /// Gets or sets Supply.
        /// </summary>
        [JsonProperty("supply", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.TerminalSupply> Supply { get; set; }

        /// <summary>
        /// Gets or sets Deployment.
        /// </summary>
        [JsonProperty("deployment", NullValueHandling = NullValueHandling.Ignore)]
        public Models.TerminalDeployment Deployment { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Terminal : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is Terminal other &&                ((this.TerminalConfigs == null && other.TerminalConfigs == null) || (this.TerminalConfigs?.Equals(other.TerminalConfigs) == true)) &&
                ((this.Customizations == null && other.Customizations == null) || (this.Customizations?.Equals(other.Customizations) == true)) &&
                ((this.Products == null && other.Products == null) || (this.Products?.Equals(other.Products) == true)) &&
                ((this.Peripherals == null && other.Peripherals == null) || (this.Peripherals?.Equals(other.Peripherals) == true)) &&
                ((this.Vendors == null && other.Vendors == null) || (this.Vendors?.Equals(other.Vendors) == true)) &&
                ((this.Gateways == null && other.Gateways == null) || (this.Gateways?.Equals(other.Gateways) == true)) &&
                ((this.Supply == null && other.Supply == null) || (this.Supply?.Equals(other.Supply) == true)) &&
                ((this.Deployment == null && other.Deployment == null) || (this.Deployment?.Equals(other.Deployment) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.TerminalConfigs = {(this.TerminalConfigs == null ? "null" : this.TerminalConfigs.ToString())}");
            toStringOutput.Add($"this.Customizations = {(this.Customizations == null ? "null" : $"[{string.Join(", ", this.Customizations)} ]")}");
            toStringOutput.Add($"this.Products = {(this.Products == null ? "null" : $"[{string.Join(", ", this.Products)} ]")}");
            toStringOutput.Add($"this.Peripherals = {(this.Peripherals == null ? "null" : $"[{string.Join(", ", this.Peripherals)} ]")}");
            toStringOutput.Add($"this.Vendors = {(this.Vendors == null ? "null" : $"[{string.Join(", ", this.Vendors)} ]")}");
            toStringOutput.Add($"this.Gateways = {(this.Gateways == null ? "null" : $"[{string.Join(", ", this.Gateways)} ]")}");
            toStringOutput.Add($"this.Supply = {(this.Supply == null ? "null" : $"[{string.Join(", ", this.Supply)} ]")}");
            toStringOutput.Add($"this.Deployment = {(this.Deployment == null ? "null" : this.Deployment.ToString())}");
        }
    }
}