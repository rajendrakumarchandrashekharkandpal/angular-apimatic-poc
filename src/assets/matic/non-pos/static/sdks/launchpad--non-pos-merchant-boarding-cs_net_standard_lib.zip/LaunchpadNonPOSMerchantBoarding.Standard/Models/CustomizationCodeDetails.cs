// <copyright file="CustomizationCodeDetails.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CustomizationCodeDetails.
    /// </summary>
    public class CustomizationCodeDetails
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomizationCodeDetails"/> class.
        /// </summary>
        public CustomizationCodeDetails()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomizationCodeDetails"/> class.
        /// </summary>
        /// <param name="mValue">value.</param>
        /// <param name="shortDescription">shortDescription.</param>
        /// <param name="longDescription">longDescription.</param>
        public CustomizationCodeDetails(
            string mValue = null,
            string shortDescription = null,
            string longDescription = null)
        {
            this.MValue = mValue;
            this.ShortDescription = shortDescription;
            this.LongDescription = longDescription;
        }

        /// <summary>
        /// customization code
        /// </summary>
        [JsonProperty("value", NullValueHandling = NullValueHandling.Ignore)]
        public string MValue { get; set; }

        /// <summary>
        /// short description of the customization code
        /// </summary>
        [JsonProperty("shortDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string ShortDescription { get; set; }

        /// <summary>
        /// long description of the customization code
        /// </summary>
        [JsonProperty("longDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string LongDescription { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CustomizationCodeDetails : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is CustomizationCodeDetails other &&                ((this.MValue == null && other.MValue == null) || (this.MValue?.Equals(other.MValue) == true)) &&
                ((this.ShortDescription == null && other.ShortDescription == null) || (this.ShortDescription?.Equals(other.ShortDescription) == true)) &&
                ((this.LongDescription == null && other.LongDescription == null) || (this.LongDescription?.Equals(other.LongDescription) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MValue = {(this.MValue == null ? "null" : this.MValue)}");
            toStringOutput.Add($"this.ShortDescription = {(this.ShortDescription == null ? "null" : this.ShortDescription)}");
            toStringOutput.Add($"this.LongDescription = {(this.LongDescription == null ? "null" : this.LongDescription)}");
        }
    }
}