// <copyright file="ReturnPolicyEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// ReturnPolicyEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum ReturnPolicyEnum
    {
        /// <summary>
        /// Enum3Day.
        /// </summary>
        [EnumMember(Value = "3 Day")]
        Enum3Day,

        /// <summary>
        /// Enum30Day.
        /// </summary>
        [EnumMember(Value = "30 Day")]
        Enum30Day,

        /// <summary>
        /// Enum60Day.
        /// </summary>
        [EnumMember(Value = "60 Day")]
        Enum60Day,

        /// <summary>
        /// Enum60Day1.
        /// </summary>
        [EnumMember(Value = "60+ Day")]
        Enum60Day1,

        /// <summary>
        /// EnumALLSALESFINAL.
        /// </summary>
        [EnumMember(Value = "ALL SALES FINAL")]
        EnumALLSALESFINAL,

        /// <summary>
        /// EnumEXCHANGEONLYSTORECREDIT.
        /// </summary>
        [EnumMember(Value = "EXCHANGE ONLY/STORE CREDIT")]
        EnumEXCHANGEONLYSTORECREDIT,

        /// <summary>
        /// EnumNORETURNPOLICY.
        /// </summary>
        [EnumMember(Value = "NO RETURN POLICY")]
        EnumNORETURNPOLICY
    }
}