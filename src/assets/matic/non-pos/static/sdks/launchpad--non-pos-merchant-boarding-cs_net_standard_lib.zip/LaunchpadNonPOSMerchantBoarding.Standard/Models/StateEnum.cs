// <copyright file="StateEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// StateEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum StateEnum
    {
        /// <summary>
        /// AK.
        /// </summary>
        [EnumMember(Value = "AK")]
        AK,

        /// <summary>
        /// AL.
        /// </summary>
        [EnumMember(Value = "AL")]
        AL,

        /// <summary>
        /// AR.
        /// </summary>
        [EnumMember(Value = "AR")]
        AR,

        /// <summary>
        /// AS.
        /// </summary>
        [EnumMember(Value = "AS")]
        AS,

        /// <summary>
        /// AZ.
        /// </summary>
        [EnumMember(Value = "AZ")]
        AZ,

        /// <summary>
        /// CA.
        /// </summary>
        [EnumMember(Value = "CA")]
        CA,

        /// <summary>
        /// CO.
        /// </summary>
        [EnumMember(Value = "CO")]
        CO,

        /// <summary>
        /// CT.
        /// </summary>
        [EnumMember(Value = "CT")]
        CT,

        /// <summary>
        /// DC.
        /// </summary>
        [EnumMember(Value = "DC")]
        DC,

        /// <summary>
        /// DE.
        /// </summary>
        [EnumMember(Value = "DE")]
        DE,

        /// <summary>
        /// FL.
        /// </summary>
        [EnumMember(Value = "FL")]
        FL,

        /// <summary>
        /// FM.
        /// </summary>
        [EnumMember(Value = "FM")]
        FM,

        /// <summary>
        /// GA.
        /// </summary>
        [EnumMember(Value = "GA")]
        GA,

        /// <summary>
        /// GU.
        /// </summary>
        [EnumMember(Value = "GU")]
        GU,

        /// <summary>
        /// HI.
        /// </summary>
        [EnumMember(Value = "HI")]
        HI,

        /// <summary>
        /// IA.
        /// </summary>
        [EnumMember(Value = "IA")]
        IA,

        /// <summary>
        /// ID.
        /// </summary>
        [EnumMember(Value = "ID")]
        ID,

        /// <summary>
        /// IL.
        /// </summary>
        [EnumMember(Value = "IL")]
        IL,

        /// <summary>
        /// IN.
        /// </summary>
        [EnumMember(Value = "IN")]
        IN,

        /// <summary>
        /// KS.
        /// </summary>
        [EnumMember(Value = "KS")]
        KS,

        /// <summary>
        /// KY.
        /// </summary>
        [EnumMember(Value = "KY")]
        KY,

        /// <summary>
        /// LA.
        /// </summary>
        [EnumMember(Value = "LA")]
        LA,

        /// <summary>
        /// MA.
        /// </summary>
        [EnumMember(Value = "MA")]
        MA,

        /// <summary>
        /// MD.
        /// </summary>
        [EnumMember(Value = "MD")]
        MD,

        /// <summary>
        /// ME.
        /// </summary>
        [EnumMember(Value = "ME")]
        ME,

        /// <summary>
        /// MH.
        /// </summary>
        [EnumMember(Value = "MH")]
        MH,

        /// <summary>
        /// MI.
        /// </summary>
        [EnumMember(Value = "MI")]
        MI,

        /// <summary>
        /// MN.
        /// </summary>
        [EnumMember(Value = "MN")]
        MN,

        /// <summary>
        /// MO.
        /// </summary>
        [EnumMember(Value = "MO")]
        MO,

        /// <summary>
        /// MP.
        /// </summary>
        [EnumMember(Value = "MP")]
        MP,

        /// <summary>
        /// MS.
        /// </summary>
        [EnumMember(Value = "MS")]
        MS,

        /// <summary>
        /// MT.
        /// </summary>
        [EnumMember(Value = "MT")]
        MT,

        /// <summary>
        /// NC.
        /// </summary>
        [EnumMember(Value = "NC")]
        NC,

        /// <summary>
        /// ND.
        /// </summary>
        [EnumMember(Value = "ND")]
        ND,

        /// <summary>
        /// NE.
        /// </summary>
        [EnumMember(Value = "NE")]
        NE,

        /// <summary>
        /// NH.
        /// </summary>
        [EnumMember(Value = "NH")]
        NH,

        /// <summary>
        /// NJ.
        /// </summary>
        [EnumMember(Value = "NJ")]
        NJ,

        /// <summary>
        /// NM.
        /// </summary>
        [EnumMember(Value = "NM")]
        NM,

        /// <summary>
        /// NV.
        /// </summary>
        [EnumMember(Value = "NV")]
        NV,

        /// <summary>
        /// NY.
        /// </summary>
        [EnumMember(Value = "NY")]
        NY,

        /// <summary>
        /// OH.
        /// </summary>
        [EnumMember(Value = "OH")]
        OH,

        /// <summary>
        /// OK.
        /// </summary>
        [EnumMember(Value = "OK")]
        OK,

        /// <summary>
        /// OR.
        /// </summary>
        [EnumMember(Value = "OR")]
        OR,

        /// <summary>
        /// PA.
        /// </summary>
        [EnumMember(Value = "PA")]
        PA,

        /// <summary>
        /// PR.
        /// </summary>
        [EnumMember(Value = "PR")]
        PR,

        /// <summary>
        /// PW.
        /// </summary>
        [EnumMember(Value = "PW")]
        PW,

        /// <summary>
        /// RI.
        /// </summary>
        [EnumMember(Value = "RI")]
        RI,

        /// <summary>
        /// SC.
        /// </summary>
        [EnumMember(Value = "SC")]
        SC,

        /// <summary>
        /// SD.
        /// </summary>
        [EnumMember(Value = "SD")]
        SD,

        /// <summary>
        /// TN.
        /// </summary>
        [EnumMember(Value = "TN")]
        TN,

        /// <summary>
        /// TX.
        /// </summary>
        [EnumMember(Value = "TX")]
        TX,

        /// <summary>
        /// UT.
        /// </summary>
        [EnumMember(Value = "UT")]
        UT,

        /// <summary>
        /// VA.
        /// </summary>
        [EnumMember(Value = "VA")]
        VA,

        /// <summary>
        /// VI.
        /// </summary>
        [EnumMember(Value = "VI")]
        VI,

        /// <summary>
        /// VT.
        /// </summary>
        [EnumMember(Value = "VT")]
        VT,

        /// <summary>
        /// WA.
        /// </summary>
        [EnumMember(Value = "WA")]
        WA,

        /// <summary>
        /// WI.
        /// </summary>
        [EnumMember(Value = "WI")]
        WI,

        /// <summary>
        /// WV.
        /// </summary>
        [EnumMember(Value = "WV")]
        WV,

        /// <summary>
        /// WY.
        /// </summary>
        [EnumMember(Value = "WY")]
        WY
    }
}