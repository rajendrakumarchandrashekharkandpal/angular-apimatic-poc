// <copyright file="AuthSigners.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AuthSigners.
    /// </summary>
    public class AuthSigners
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AuthSigners"/> class.
        /// </summary>
        public AuthSigners()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AuthSigners"/> class.
        /// </summary>
        /// <param name="firstName">firstName.</param>
        /// <param name="middleInitial">middleInitial.</param>
        /// <param name="lastName">lastName.</param>
        /// <param name="email">email.</param>
        /// <param name="status">status.</param>
        /// <param name="lastUpdated">lastUpdated.</param>
        /// <param name="dateSubmitted">dateSubmitted.</param>
        /// <param name="dateSent">dateSent.</param>
        /// <param name="dateDelivered">dateDelivered.</param>
        /// <param name="dateSigned">dateSigned.</param>
        /// <param name="signerRoleName">signerRoleName.</param>
        /// <param name="signerExperience">signerExperience.</param>
        public AuthSigners(
            string firstName = null,
            string middleInitial = null,
            string lastName = null,
            string email = null,
            string status = null,
            DateTime? lastUpdated = null,
            DateTime? dateSubmitted = null,
            DateTime? dateSent = null,
            DateTime? dateDelivered = null,
            DateTime? dateSigned = null,
            string signerRoleName = null,
            string signerExperience = null)
        {
            this.FirstName = firstName;
            this.MiddleInitial = middleInitial;
            this.LastName = lastName;
            this.Email = email;
            this.Status = status;
            this.LastUpdated = lastUpdated;
            this.DateSubmitted = dateSubmitted;
            this.DateSent = dateSent;
            this.DateDelivered = dateDelivered;
            this.DateSigned = dateSigned;
            this.SignerRoleName = signerRoleName;
            this.SignerExperience = signerExperience;
        }

        /// <summary>
        /// First name. Region based validations will be applied to this field.
        /// </summary>
        [JsonProperty("firstName", NullValueHandling = NullValueHandling.Ignore)]
        public string FirstName { get; set; }

        /// <summary>
        /// Middle initial.
        /// </summary>
        [JsonProperty("middleInitial", NullValueHandling = NullValueHandling.Ignore)]
        public string MiddleInitial { get; set; }

        /// <summary>
        /// Last name. Region based validations will be applied to this field.
        /// </summary>
        [JsonProperty("lastName", NullValueHandling = NullValueHandling.Ignore)]
        public string LastName { get; set; }

        /// <summary>
        /// Email address of the contact. Must have @ and a .
        /// </summary>
        [JsonProperty("email", NullValueHandling = NullValueHandling.Ignore)]
        public string Email { get; set; }

        /// <summary>
        /// Status of the signer
        /// </summary>
        [JsonProperty("status", NullValueHandling = NullValueHandling.Ignore)]
        public string Status { get; set; }

        /// <summary>
        /// Date contract was last updated
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("lastUpdated", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? LastUpdated { get; set; }

        /// <summary>
        /// Date contract was last updated
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("dateSubmitted", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? DateSubmitted { get; set; }

        /// <summary>
        /// Date contract was sent
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("dateSent", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? DateSent { get; set; }

        /// <summary>
        /// Date contract was delivered
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("dateDelivered", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? DateDelivered { get; set; }

        /// <summary>
        /// Date contract was signed
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("dateSigned", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? DateSigned { get; set; }

        /// <summary>
        /// Role of the signer
        /// </summary>
        [JsonProperty("signerRoleName", NullValueHandling = NullValueHandling.Ignore)]
        public string SignerRoleName { get; set; }

        /// <summary>
        /// Method of sign
        /// </summary>
        [JsonProperty("signerExperience", NullValueHandling = NullValueHandling.Ignore)]
        public string SignerExperience { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AuthSigners : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AuthSigners other &&                ((this.FirstName == null && other.FirstName == null) || (this.FirstName?.Equals(other.FirstName) == true)) &&
                ((this.MiddleInitial == null && other.MiddleInitial == null) || (this.MiddleInitial?.Equals(other.MiddleInitial) == true)) &&
                ((this.LastName == null && other.LastName == null) || (this.LastName?.Equals(other.LastName) == true)) &&
                ((this.Email == null && other.Email == null) || (this.Email?.Equals(other.Email) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                ((this.LastUpdated == null && other.LastUpdated == null) || (this.LastUpdated?.Equals(other.LastUpdated) == true)) &&
                ((this.DateSubmitted == null && other.DateSubmitted == null) || (this.DateSubmitted?.Equals(other.DateSubmitted) == true)) &&
                ((this.DateSent == null && other.DateSent == null) || (this.DateSent?.Equals(other.DateSent) == true)) &&
                ((this.DateDelivered == null && other.DateDelivered == null) || (this.DateDelivered?.Equals(other.DateDelivered) == true)) &&
                ((this.DateSigned == null && other.DateSigned == null) || (this.DateSigned?.Equals(other.DateSigned) == true)) &&
                ((this.SignerRoleName == null && other.SignerRoleName == null) || (this.SignerRoleName?.Equals(other.SignerRoleName) == true)) &&
                ((this.SignerExperience == null && other.SignerExperience == null) || (this.SignerExperience?.Equals(other.SignerExperience) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.FirstName = {(this.FirstName == null ? "null" : this.FirstName)}");
            toStringOutput.Add($"this.MiddleInitial = {(this.MiddleInitial == null ? "null" : this.MiddleInitial)}");
            toStringOutput.Add($"this.LastName = {(this.LastName == null ? "null" : this.LastName)}");
            toStringOutput.Add($"this.Email = {(this.Email == null ? "null" : this.Email)}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status)}");
            toStringOutput.Add($"this.LastUpdated = {(this.LastUpdated == null ? "null" : this.LastUpdated.ToString())}");
            toStringOutput.Add($"this.DateSubmitted = {(this.DateSubmitted == null ? "null" : this.DateSubmitted.ToString())}");
            toStringOutput.Add($"this.DateSent = {(this.DateSent == null ? "null" : this.DateSent.ToString())}");
            toStringOutput.Add($"this.DateDelivered = {(this.DateDelivered == null ? "null" : this.DateDelivered.ToString())}");
            toStringOutput.Add($"this.DateSigned = {(this.DateSigned == null ? "null" : this.DateSigned.ToString())}");
            toStringOutput.Add($"this.SignerRoleName = {(this.SignerRoleName == null ? "null" : this.SignerRoleName)}");
            toStringOutput.Add($"this.SignerExperience = {(this.SignerExperience == null ? "null" : this.SignerExperience)}");
        }
    }
}