// <copyright file="Peripheral.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Peripheral.
    /// </summary>
    public class Peripheral
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Peripheral"/> class.
        /// </summary>
        public Peripheral()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Peripheral"/> class.
        /// </summary>
        /// <param name="peripheralId">peripheralId.</param>
        /// <param name="peripheralType">peripheralType.</param>
        /// <param name="model">model.</param>
        /// <param name="leaseId">leaseId.</param>
        /// <param name="leaseTermLength">leaseTermLength.</param>
        /// <param name="paymentMethod">paymentMethod.</param>
        /// <param name="amount">amount.</param>
        /// <param name="paymentConfirmationNumber">paymentConfirmationNumber.</param>
        public Peripheral(
            string peripheralId = null,
            string peripheralType = null,
            string model = null,
            string leaseId = null,
            Models.LeaseTermLengthEnum? leaseTermLength = null,
            Models.PaymentMethod1Enum? paymentMethod = null,
            string amount = null,
            string paymentConfirmationNumber = null)
        {
            this.PeripheralId = peripheralId;
            this.PeripheralType = peripheralType;
            this.Model = model;
            this.LeaseId = leaseId;
            this.LeaseTermLength = leaseTermLength;
            this.PaymentMethod = paymentMethod;
            this.Amount = amount;
            this.PaymentConfirmationNumber = paymentConfirmationNumber;
        }

        /// <summary>
        /// Peripheral IDs are internally populated.
        /// </summary>
        [JsonProperty("peripheralId", NullValueHandling = NullValueHandling.Ignore)]
        public string PeripheralId { get; set; }

        /// <summary>
        /// Peripheral type
        /// </summary>
        [JsonProperty("peripheralType", NullValueHandling = NullValueHandling.Ignore)]
        public string PeripheralType { get; set; }

        /// <summary>
        /// Gets or sets Model.
        /// </summary>
        [JsonProperty("model", NullValueHandling = NullValueHandling.Ignore)]
        public string Model { get; set; }

        /// <summary>
        /// Lease ID for the peripheral
        /// </summary>
        [JsonProperty("leaseId", NullValueHandling = NullValueHandling.Ignore)]
        public string LeaseId { get; set; }

        /// <summary>
        /// Lease term for the peripheral
        /// </summary>
        [JsonProperty("leaseTermLength", NullValueHandling = NullValueHandling.Ignore)]
        public Models.LeaseTermLengthEnum? LeaseTermLength { get; set; }

        /// <summary>
        /// Payment method for the selected peripheral.
        /// </summary>
        [JsonProperty("paymentMethod", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PaymentMethod1Enum? PaymentMethod { get; set; }

        /// <summary>
        /// "Payment Amount for the peripheral. Valid values are 0.00
        ///   - 9999999999.99."
        /// </summary>
        [JsonProperty("amount", NullValueHandling = NullValueHandling.Ignore)]
        public string Amount { get; set; }

        /// <summary>
        /// Payment confirmation number for the peripheral.
        /// </summary>
        [JsonProperty("paymentConfirmationNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string PaymentConfirmationNumber { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Peripheral : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is Peripheral other &&                ((this.PeripheralId == null && other.PeripheralId == null) || (this.PeripheralId?.Equals(other.PeripheralId) == true)) &&
                ((this.PeripheralType == null && other.PeripheralType == null) || (this.PeripheralType?.Equals(other.PeripheralType) == true)) &&
                ((this.Model == null && other.Model == null) || (this.Model?.Equals(other.Model) == true)) &&
                ((this.LeaseId == null && other.LeaseId == null) || (this.LeaseId?.Equals(other.LeaseId) == true)) &&
                ((this.LeaseTermLength == null && other.LeaseTermLength == null) || (this.LeaseTermLength?.Equals(other.LeaseTermLength) == true)) &&
                ((this.PaymentMethod == null && other.PaymentMethod == null) || (this.PaymentMethod?.Equals(other.PaymentMethod) == true)) &&
                ((this.Amount == null && other.Amount == null) || (this.Amount?.Equals(other.Amount) == true)) &&
                ((this.PaymentConfirmationNumber == null && other.PaymentConfirmationNumber == null) || (this.PaymentConfirmationNumber?.Equals(other.PaymentConfirmationNumber) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PeripheralId = {(this.PeripheralId == null ? "null" : this.PeripheralId)}");
            toStringOutput.Add($"this.PeripheralType = {(this.PeripheralType == null ? "null" : this.PeripheralType)}");
            toStringOutput.Add($"this.Model = {(this.Model == null ? "null" : this.Model)}");
            toStringOutput.Add($"this.LeaseId = {(this.LeaseId == null ? "null" : this.LeaseId)}");
            toStringOutput.Add($"this.LeaseTermLength = {(this.LeaseTermLength == null ? "null" : this.LeaseTermLength.ToString())}");
            toStringOutput.Add($"this.PaymentMethod = {(this.PaymentMethod == null ? "null" : this.PaymentMethod.ToString())}");
            toStringOutput.Add($"this.Amount = {(this.Amount == null ? "null" : this.Amount)}");
            toStringOutput.Add($"this.PaymentConfirmationNumber = {(this.PaymentConfirmationNumber == null ? "null" : this.PaymentConfirmationNumber)}");
        }
    }
}