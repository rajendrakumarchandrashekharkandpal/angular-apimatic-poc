// <copyright file="TerminalSupply.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// TerminalSupply.
    /// </summary>
    public class TerminalSupply
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TerminalSupply"/> class.
        /// </summary>
        public TerminalSupply()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TerminalSupply"/> class.
        /// </summary>
        /// <param name="supplyType">supplyType.</param>
        /// <param name="name">name.</param>
        /// <param name="quantity">quantity.</param>
        /// <param name="total">total.</param>
        public TerminalSupply(
            string supplyType,
            string name = null,
            int? quantity = null,
            string total = null)
        {
            this.SupplyType = supplyType;
            this.Name = name;
            this.Quantity = quantity;
            this.Total = total;
        }

        /// <summary>
        /// Gets or sets SupplyType.
        /// </summary>
        [JsonProperty("supplyType")]
        public string SupplyType { get; set; }

        /// <summary>
        /// Supply name
        /// </summary>
        [JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// Supply quantity
        /// </summary>
        [JsonProperty("quantity", NullValueHandling = NullValueHandling.Ignore)]
        public int? Quantity { get; set; }

        /// <summary>
        /// Total Supplies. Valid values are 0.00
        ///   - 9999999999.99."
        /// </summary>
        [JsonProperty("total", NullValueHandling = NullValueHandling.Ignore)]
        public string Total { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"TerminalSupply : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is TerminalSupply other &&                ((this.SupplyType == null && other.SupplyType == null) || (this.SupplyType?.Equals(other.SupplyType) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Quantity == null && other.Quantity == null) || (this.Quantity?.Equals(other.Quantity) == true)) &&
                ((this.Total == null && other.Total == null) || (this.Total?.Equals(other.Total) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.SupplyType = {(this.SupplyType == null ? "null" : this.SupplyType)}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name)}");
            toStringOutput.Add($"this.Quantity = {(this.Quantity == null ? "null" : this.Quantity.ToString())}");
            toStringOutput.Add($"this.Total = {(this.Total == null ? "null" : this.Total)}");
        }
    }
}