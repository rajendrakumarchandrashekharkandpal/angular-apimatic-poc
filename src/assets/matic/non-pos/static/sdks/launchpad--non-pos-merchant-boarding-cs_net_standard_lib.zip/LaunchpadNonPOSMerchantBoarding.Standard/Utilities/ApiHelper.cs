// <copyright file="ApiHelper.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Utilities
{
    using APIMatic.Core.Utilities;

    /// <summary>
    /// ApiHelper class contains a bunch of helper methods.
    /// </summary>
    public class ApiHelper : CoreHelper { }
}
