// <copyright file="IdTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;

    /// <summary>
    /// IdTypeEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum IdTypeEnum
    {
        /// <summary>
        /// EnumALIENID.
        /// </summary>
        [EnumMember(Value = "ALIEN ID")]
        EnumALIENID,

        /// <summary>
        /// EnumCREDITBUREAU.
        /// </summary>
        [EnumMember(Value = "CREDIT BUREAU")]
        EnumCREDITBUREAU,

        /// <summary>
        /// EnumDRIVERSLICENSE.
        /// </summary>
        [EnumMember(Value = "DRIVERS LICENSE")]
        EnumDRIVERSLICENSE,

        /// <summary>
        /// EnumSTATEID.
        /// </summary>
        [EnumMember(Value = "STATE ID")]
        EnumSTATEID,

        /// <summary>
        /// EnumMEXICANCONSULATE.
        /// </summary>
        [EnumMember(Value = "MEXICAN CONSULATE")]
        EnumMEXICANCONSULATE,

        /// <summary>
        /// EnumMILITARYID.
        /// </summary>
        [EnumMember(Value = "MILITARY ID")]
        EnumMILITARYID,

        /// <summary>
        /// OTHER.
        /// </summary>
        [EnumMember(Value = "OTHER")]
        OTHER,

        /// <summary>
        /// PASSPORT.
        /// </summary>
        [EnumMember(Value = "PASSPORT")]
        PASSPORT
    }
}