// <copyright file="Address1.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Address1.
    /// </summary>
    public class Address1
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Address1"/> class.
        /// </summary>
        public Address1()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Address1"/> class.
        /// </summary>
        /// <param name="type">type.</param>
        /// <param name="addressLine1">addressLine1.</param>
        /// <param name="city">city.</param>
        /// <param name="state">state.</param>
        /// <param name="country">country.</param>
        /// <param name="postalCode">postalCode.</param>
        /// <param name="addressLine2">addressLine2.</param>
        /// <param name="postalCodeExtension">postalCodeExtension.</param>
        public Address1(
            Models.AddressTypeEnum type,
            string addressLine1,
            string city,
            Models.State1Enum state,
            string country,
            string postalCode,
            string addressLine2 = null,
            string postalCodeExtension = null)
        {
            this.Type = type;
            this.AddressLine1 = addressLine1;
            this.AddressLine2 = addressLine2;
            this.City = city;
            this.State = state;
            this.Country = country;
            this.PostalCode = postalCode;
            this.PostalCodeExtension = postalCodeExtension;
        }

        /// <summary>
        /// Address Type
        ///  1) Physical address is mandatory.
        ///  2) If equipment needs to be sent to a different location than the physical address, then shipping address should be added.
        /// 3) For any address type, addressLine1, city, state, postalCode and country are mandatory.
        /// </summary>
        [JsonProperty("type")]
        public Models.AddressTypeEnum Type { get; set; }

        /// <summary>
        /// Address Line 1. Field for house number, street and direction.
        /// </summary>
        [JsonProperty("addressLine1")]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Address Line 2. Field for apartment or suite numbers, etc.
        /// </summary>
        [JsonProperty("addressLine2", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets City.
        /// </summary>
        [JsonProperty("city")]
        public string City { get; set; }

        /// <summary>
        /// Valid US state, commonwealth, and territory codes are allowed.
        /// </summary>
        [JsonProperty("state")]
        public Models.State1Enum State { get; set; }

        /// <summary>
        /// Only United States is allowed.
        /// </summary>
        [JsonProperty("country")]
        public string Country { get; set; }

        /// <summary>
        /// Postal code / zip code. The postal code must be valid for the address' country code.
        /// </summary>
        [JsonProperty("postalCode")]
        public string PostalCode { get; set; }

        /// <summary>
        /// Postal code / zip code extension.  The postal code extension must be valid for the address' country code.
        /// </summary>
        [JsonProperty("postalCodeExtension", NullValueHandling = NullValueHandling.Ignore)]
        public string PostalCodeExtension { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Address1 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is Address1 other &&                this.Type.Equals(other.Type) &&
                ((this.AddressLine1 == null && other.AddressLine1 == null) || (this.AddressLine1?.Equals(other.AddressLine1) == true)) &&
                ((this.AddressLine2 == null && other.AddressLine2 == null) || (this.AddressLine2?.Equals(other.AddressLine2) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                this.State.Equals(other.State) &&
                ((this.Country == null && other.Country == null) || (this.Country?.Equals(other.Country) == true)) &&
                ((this.PostalCode == null && other.PostalCode == null) || (this.PostalCode?.Equals(other.PostalCode) == true)) &&
                ((this.PostalCodeExtension == null && other.PostalCodeExtension == null) || (this.PostalCodeExtension?.Equals(other.PostalCodeExtension) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Type = {this.Type}");
            toStringOutput.Add($"this.AddressLine1 = {(this.AddressLine1 == null ? "null" : this.AddressLine1)}");
            toStringOutput.Add($"this.AddressLine2 = {(this.AddressLine2 == null ? "null" : this.AddressLine2)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City)}");
            toStringOutput.Add($"this.State = {this.State}");
            toStringOutput.Add($"this.Country = {(this.Country == null ? "null" : this.Country)}");
            toStringOutput.Add($"this.PostalCode = {(this.PostalCode == null ? "null" : this.PostalCode)}");
            toStringOutput.Add($"this.PostalCodeExtension = {(this.PostalCodeExtension == null ? "null" : this.PostalCodeExtension)}");
        }
    }
}