// <copyright file="InlineResponse200Equipment.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// InlineResponse200Equipment.
    /// </summary>
    public class InlineResponse200Equipment
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InlineResponse200Equipment"/> class.
        /// </summary>
        public InlineResponse200Equipment()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="InlineResponse200Equipment"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="name">name.</param>
        /// <param name="logicalApplicationId">logicalApplicationId.</param>
        /// <param name="environment">environment.</param>
        public InlineResponse200Equipment(
            string id = null,
            string name = null,
            string logicalApplicationId = null,
            string environment = null)
        {
            this.Id = id;
            this.Name = name;
            this.LogicalApplicationId = logicalApplicationId;
            this.Environment = environment;
        }

        /// <summary>
        /// Gets or sets Id.
        /// </summary>
        [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        [JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets LogicalApplicationId.
        /// </summary>
        [JsonProperty("logicalApplicationId", NullValueHandling = NullValueHandling.Ignore)]
        public string LogicalApplicationId { get; set; }

        /// <summary>
        /// Gets or sets Environment.
        /// </summary>
        [JsonProperty("environment", NullValueHandling = NullValueHandling.Ignore)]
        public string Environment { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"InlineResponse200Equipment : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is InlineResponse200Equipment other &&                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.LogicalApplicationId == null && other.LogicalApplicationId == null) || (this.LogicalApplicationId?.Equals(other.LogicalApplicationId) == true)) &&
                ((this.Environment == null && other.Environment == null) || (this.Environment?.Equals(other.Environment) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id)}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name)}");
            toStringOutput.Add($"this.LogicalApplicationId = {(this.LogicalApplicationId == null ? "null" : this.LogicalApplicationId)}");
            toStringOutput.Add($"this.Environment = {(this.Environment == null ? "null" : this.Environment)}");
        }
    }
}