// <copyright file="BusinessInfo.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// BusinessInfo.
    /// </summary>
    public class BusinessInfo
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BusinessInfo"/> class.
        /// </summary>
        public BusinessInfo()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BusinessInfo"/> class.
        /// </summary>
        /// <param name="dbaName">dbaName.</param>
        /// <param name="legalName">legalName.</param>
        /// <param name="ownershipType">ownershipType.</param>
        /// <param name="mccCode">mccCode.</param>
        /// <param name="businessEstablishedDate">businessEstablishedDate.</param>
        /// <param name="websiteUrl">websiteUrl.</param>
        /// <param name="numberOfLocation">numberOfLocation.</param>
        /// <param name="federalTaxId">federalTaxId.</param>
        /// <param name="paymentAcceptanceMethod">paymentAcceptanceMethod.</param>
        /// <param name="pciadc">pciadc.</param>
        /// <param name="pcidssValidated">pcidssValidated.</param>
        /// <param name="surroundingArea">surroundingArea.</param>
        /// <param name="productServiceSold">productServiceSold.</param>
        /// <param name="ownAddYears">ownAddYears.</param>
        /// <param name="lengthOfContract">lengthOfContract.</param>
        /// <param name="seasonal">seasonal.</param>
        /// <param name="activeMonths">activeMonths.</param>
        /// <param name="warranty">warranty.</param>
        /// <param name="returnPolicy">returnPolicy.</param>
        /// <param name="taxExempt">taxExempt.</param>
        /// <param name="acceptCreditCards">acceptCreditCards.</param>
        public BusinessInfo(
            string dbaName,
            string legalName,
            Models.OwnershipTypeEnum ownershipType,
            string mccCode,
            DateTime? businessEstablishedDate = null,
            string websiteUrl = null,
            int? numberOfLocation = null,
            string federalTaxId = null,
            List<Models.PaymentAcceptanceMethodEnum> paymentAcceptanceMethod = null,
            Models.PciadcEnum? pciadc = Models.PciadcEnum.No,
            Models.PcidssValidatedEnum? pcidssValidated = Models.PcidssValidatedEnum.Yes,
            Models.SurroundingAreaEnum? surroundingArea = null,
            string productServiceSold = null,
            int? ownAddYears = null,
            string lengthOfContract = null,
            Models.SeasonalEnum? seasonal = null,
            List<Models.ActiveMonthEnum> activeMonths = null,
            Models.WarrantyEnum? warranty = null,
            Models.ReturnPolicyEnum? returnPolicy = null,
            Models.TaxExemptEnum? taxExempt = null,
            Models.AcceptCreditCardsEnum? acceptCreditCards = null)
        {
            this.DbaName = dbaName;
            this.LegalName = legalName;
            this.OwnershipType = ownershipType;
            this.MccCode = mccCode;
            this.BusinessEstablishedDate = businessEstablishedDate;
            this.WebsiteUrl = websiteUrl;
            this.NumberOfLocation = numberOfLocation;
            this.FederalTaxId = federalTaxId;
            this.PaymentAcceptanceMethod = paymentAcceptanceMethod;
            this.Pciadc = pciadc;
            this.PcidssValidated = pcidssValidated;
            this.SurroundingArea = surroundingArea;
            this.ProductServiceSold = productServiceSold;
            this.OwnAddYears = ownAddYears;
            this.LengthOfContract = lengthOfContract;
            this.Seasonal = seasonal;
            this.ActiveMonths = activeMonths;
            this.Warranty = warranty;
            this.ReturnPolicy = returnPolicy;
            this.TaxExempt = taxExempt;
            this.AcceptCreditCards = acceptCreditCards;
        }

        /// <summary>
        /// The merchant name they do business as.  Generally with what their customers know the business.
        /// </summary>
        [JsonProperty("dbaName")]
        public string DbaName { get; set; }

        /// <summary>
        /// Business Legal Name as filed with the IRS.
        /// </summary>
        [JsonProperty("legalName")]
        public string LegalName { get; set; }

        /// <summary>
        /// Required. OwnershipType defines the type of the Merchant Organization, and drives the requirements for data collections of beneficial and control owners under U.S. Financial Crimes Enforcement Network (FinCEN).
        /// </summary>
        [JsonProperty("ownershipType")]
        public Models.OwnershipTypeEnum OwnershipType { get; set; }

        /// <summary>
        /// SIC Code / MCC Code (Merchant Category Code) is the code use to describe what the merchant is selling. Use MCC look up call to search valid codes, with sort and long description to find the MCC that most closely matches what the merchant is selling.
        /// </summary>
        [JsonProperty("mccCode")]
        public string MccCode { get; set; }

        /// <summary>
        /// Date (CCYY-MM-DD) on which the merchant's business was established.
        /// </summary>
        [JsonConverter(typeof(CustomDateTimeConverter), "yyyy'-'MM'-'dd")]
        [JsonProperty("businessEstablishedDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? BusinessEstablishedDate { get; set; }

        /// <summary>
        /// The URL of the merchant's website.
        /// </summary>
        [JsonProperty("websiteUrl", NullValueHandling = NullValueHandling.Ignore)]
        public string WebsiteUrl { get; set; }

        /// <summary>
        /// Number of current locations.
        /// </summary>
        [JsonProperty("numberOfLocation", NullValueHandling = NullValueHandling.Ignore)]
        public int? NumberOfLocation { get; set; }

        /// <summary>
        /// The Federal Tax ID is the business Tax Identification Number (TIN) or Employer Identification Number (EIN). If the business is a sole proprietor they may use the social security number of the sole proprietor.
        /// </summary>
        [JsonProperty("federalTaxId", NullValueHandling = NullValueHandling.Ignore)]
        public string FederalTaxId { get; set; }

        /// <summary>
        /// The ways in which the business is accepting payments. Multiple options may be selected. 'In person', would be card present at a brick and mortar store, 'onlinesite' would be card not present use on an ecommerce website, and 'phoneormailorder' would be card not present used for mail and telephone orders.
        /// </summary>
        [JsonProperty("paymentAcceptanceMethod", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.PaymentAcceptanceMethodEnum> PaymentAcceptanceMethod { get; set; }

        /// <summary>
        /// Indication if the merchant has had an account data compromise.
        /// </summary>
        [JsonProperty("pciadc", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PciadcEnum? Pciadc { get; set; }

        /// <summary>
        /// Indictor showing if the merchant is compliant or not with the Payment Card Industry Data Security Standards.
        /// </summary>
        [JsonProperty("pcidssValidated", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PcidssValidatedEnum? PcidssValidated { get; set; }

        /// <summary>
        /// Type of area surroundning the business.
        /// </summary>
        [JsonProperty("surroundingArea", NullValueHandling = NullValueHandling.Ignore)]
        public Models.SurroundingAreaEnum? SurroundingArea { get; set; }

        /// <summary>
        /// Type of goods or services sold.
        /// </summary>
        [JsonProperty("productServiceSold", NullValueHandling = NullValueHandling.Ignore)]
        public string ProductServiceSold { get; set; }

        /// <summary>
        /// Years the business has been operating in their current location.
        /// </summary>
        [JsonProperty("ownAddYears", NullValueHandling = NullValueHandling.Ignore)]
        public int? OwnAddYears { get; set; }

        /// <summary>
        /// Inital contract term in months.
        /// </summary>
        [JsonProperty("lengthOfContract", NullValueHandling = NullValueHandling.Ignore)]
        public string LengthOfContract { get; set; }

        /// <summary>
        /// Does the business operate seasonally?
        /// </summary>
        [JsonProperty("seasonal", NullValueHandling = NullValueHandling.Ignore)]
        public Models.SeasonalEnum? Seasonal { get; set; }

        /// <summary>
        /// The months during which the business is actively operating.
        /// </summary>
        [JsonProperty("activeMonths", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ActiveMonthEnum> ActiveMonths { get; set; }

        /// <summary>
        /// Does the business offer warranties, dues, subscriptions, memberships, or other extended services?
        /// </summary>
        [JsonProperty("warranty", NullValueHandling = NullValueHandling.Ignore)]
        public Models.WarrantyEnum? Warranty { get; set; }

        /// <summary>
        /// The business's return policy.
        /// </summary>
        [JsonProperty("returnPolicy", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ReturnPolicyEnum? ReturnPolicy { get; set; }

        /// <summary>
        /// Gets or sets TaxExempt.
        /// </summary>
        [JsonProperty("taxExempt", NullValueHandling = NullValueHandling.Ignore)]
        public Models.TaxExemptEnum? TaxExempt { get; set; }

        /// <summary>
        /// Does the business accept credit cards?
        /// </summary>
        [JsonProperty("acceptCreditCards", NullValueHandling = NullValueHandling.Ignore)]
        public Models.AcceptCreditCardsEnum? AcceptCreditCards { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BusinessInfo : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is BusinessInfo other &&                ((this.DbaName == null && other.DbaName == null) || (this.DbaName?.Equals(other.DbaName) == true)) &&
                ((this.LegalName == null && other.LegalName == null) || (this.LegalName?.Equals(other.LegalName) == true)) &&
                this.OwnershipType.Equals(other.OwnershipType) &&
                ((this.MccCode == null && other.MccCode == null) || (this.MccCode?.Equals(other.MccCode) == true)) &&
                ((this.BusinessEstablishedDate == null && other.BusinessEstablishedDate == null) || (this.BusinessEstablishedDate?.Equals(other.BusinessEstablishedDate) == true)) &&
                ((this.WebsiteUrl == null && other.WebsiteUrl == null) || (this.WebsiteUrl?.Equals(other.WebsiteUrl) == true)) &&
                ((this.NumberOfLocation == null && other.NumberOfLocation == null) || (this.NumberOfLocation?.Equals(other.NumberOfLocation) == true)) &&
                ((this.FederalTaxId == null && other.FederalTaxId == null) || (this.FederalTaxId?.Equals(other.FederalTaxId) == true)) &&
                ((this.PaymentAcceptanceMethod == null && other.PaymentAcceptanceMethod == null) || (this.PaymentAcceptanceMethod?.Equals(other.PaymentAcceptanceMethod) == true)) &&
                ((this.Pciadc == null && other.Pciadc == null) || (this.Pciadc?.Equals(other.Pciadc) == true)) &&
                ((this.PcidssValidated == null && other.PcidssValidated == null) || (this.PcidssValidated?.Equals(other.PcidssValidated) == true)) &&
                ((this.SurroundingArea == null && other.SurroundingArea == null) || (this.SurroundingArea?.Equals(other.SurroundingArea) == true)) &&
                ((this.ProductServiceSold == null && other.ProductServiceSold == null) || (this.ProductServiceSold?.Equals(other.ProductServiceSold) == true)) &&
                ((this.OwnAddYears == null && other.OwnAddYears == null) || (this.OwnAddYears?.Equals(other.OwnAddYears) == true)) &&
                ((this.LengthOfContract == null && other.LengthOfContract == null) || (this.LengthOfContract?.Equals(other.LengthOfContract) == true)) &&
                ((this.Seasonal == null && other.Seasonal == null) || (this.Seasonal?.Equals(other.Seasonal) == true)) &&
                ((this.ActiveMonths == null && other.ActiveMonths == null) || (this.ActiveMonths?.Equals(other.ActiveMonths) == true)) &&
                ((this.Warranty == null && other.Warranty == null) || (this.Warranty?.Equals(other.Warranty) == true)) &&
                ((this.ReturnPolicy == null && other.ReturnPolicy == null) || (this.ReturnPolicy?.Equals(other.ReturnPolicy) == true)) &&
                ((this.TaxExempt == null && other.TaxExempt == null) || (this.TaxExempt?.Equals(other.TaxExempt) == true)) &&
                ((this.AcceptCreditCards == null && other.AcceptCreditCards == null) || (this.AcceptCreditCards?.Equals(other.AcceptCreditCards) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.DbaName = {(this.DbaName == null ? "null" : this.DbaName)}");
            toStringOutput.Add($"this.LegalName = {(this.LegalName == null ? "null" : this.LegalName)}");
            toStringOutput.Add($"this.OwnershipType = {this.OwnershipType}");
            toStringOutput.Add($"this.MccCode = {(this.MccCode == null ? "null" : this.MccCode)}");
            toStringOutput.Add($"this.BusinessEstablishedDate = {(this.BusinessEstablishedDate == null ? "null" : this.BusinessEstablishedDate.ToString())}");
            toStringOutput.Add($"this.WebsiteUrl = {(this.WebsiteUrl == null ? "null" : this.WebsiteUrl)}");
            toStringOutput.Add($"this.NumberOfLocation = {(this.NumberOfLocation == null ? "null" : this.NumberOfLocation.ToString())}");
            toStringOutput.Add($"this.FederalTaxId = {(this.FederalTaxId == null ? "null" : this.FederalTaxId)}");
            toStringOutput.Add($"this.PaymentAcceptanceMethod = {(this.PaymentAcceptanceMethod == null ? "null" : $"[{string.Join(", ", this.PaymentAcceptanceMethod)} ]")}");
            toStringOutput.Add($"this.Pciadc = {(this.Pciadc == null ? "null" : this.Pciadc.ToString())}");
            toStringOutput.Add($"this.PcidssValidated = {(this.PcidssValidated == null ? "null" : this.PcidssValidated.ToString())}");
            toStringOutput.Add($"this.SurroundingArea = {(this.SurroundingArea == null ? "null" : this.SurroundingArea.ToString())}");
            toStringOutput.Add($"this.ProductServiceSold = {(this.ProductServiceSold == null ? "null" : this.ProductServiceSold)}");
            toStringOutput.Add($"this.OwnAddYears = {(this.OwnAddYears == null ? "null" : this.OwnAddYears.ToString())}");
            toStringOutput.Add($"this.LengthOfContract = {(this.LengthOfContract == null ? "null" : this.LengthOfContract)}");
            toStringOutput.Add($"this.Seasonal = {(this.Seasonal == null ? "null" : this.Seasonal.ToString())}");
            toStringOutput.Add($"this.ActiveMonths = {(this.ActiveMonths == null ? "null" : $"[{string.Join(", ", this.ActiveMonths)} ]")}");
            toStringOutput.Add($"this.Warranty = {(this.Warranty == null ? "null" : this.Warranty.ToString())}");
            toStringOutput.Add($"this.ReturnPolicy = {(this.ReturnPolicy == null ? "null" : this.ReturnPolicy.ToString())}");
            toStringOutput.Add($"this.TaxExempt = {(this.TaxExempt == null ? "null" : this.TaxExempt.ToString())}");
            toStringOutput.Add($"this.AcceptCreditCards = {(this.AcceptCreditCards == null ? "null" : this.AcceptCreditCards.ToString())}");
        }
    }
}