// <copyright file="SubmitApplicationControllerTest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace LaunchpadNonPOSMerchantBoarding.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities;
    using LaunchpadNonPOSMerchantBoarding.Standard;
    using LaunchpadNonPOSMerchantBoarding.Standard.Controllers;
    using LaunchpadNonPOSMerchantBoarding.Standard.Exceptions;
    using LaunchpadNonPOSMerchantBoarding.Standard.Http.Client;
    using LaunchpadNonPOSMerchantBoarding.Standard.Http.Response;
    using LaunchpadNonPOSMerchantBoarding.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using NUnit.Framework;

    /// <summary>
    /// SubmitApplicationControllerTest.
    /// </summary>
    [TestFixture]
    public class SubmitApplicationControllerTest : ControllerTestBase
    {
        /// <summary>
        /// Controller instance (for all tests).
        /// </summary>
        private SubmitApplicationController controller;

        /// <summary>
        /// Setup test class.
        /// </summary>
        [OneTimeSetUp]
        public void SetUpDerived()
        {
            this.controller = this.Client.SubmitApplicationController;
        }

        /// <summary>
        /// Begins the merchant validation process before boarding after all necessary information has been submitted to the API. Please see the reference guide for specific boarding requirements..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestValidateBoard()
        {
            // Parameters for the API call
            Guid externalRefId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");
            Guid? vCorrelationId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");
            Standard.Models.ContentTypeEnum contentType = ApiHelper.JsonDeserialize<Standard.Models.ContentTypeEnum>("\"application/json\"");

            // Perform API call
            try
            {
                await this.controller.ValidateBoardAsync(externalRefId, vCorrelationId, contentType);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("v-correlation-id", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }

        /// <summary>
        /// Begins the merchant boarding process after all necessary information has been submitted to the API. Please see the reference guide for specific boarding requirements..
        /// </summary>
        /// <returns>A <see cref="Task"/> representing the asynchronous unit test.</returns>
        [Test]
        public async Task TestTestInititateBoard()
        {
            // Parameters for the API call
            Guid externalRefId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");
            Guid? vCorrelationId = Guid.Parse("3fcb1437-4e52-4946-9ae1-e618351b6d16");
            Standard.Models.ContentTypeEnum contentType = ApiHelper.JsonDeserialize<Standard.Models.ContentTypeEnum>("\"application/json\"");
            string threatmetrixId = null;

            // Perform API call
            try
            {
                await this.controller.InititateBoardAsync(externalRefId, vCorrelationId, contentType, threatmetrixId);
            }
            catch (ApiException)
            {
            }

            // Test response code
            Assert.AreEqual(200, HttpCallBack.Response.StatusCode, "Status should be 200");

            // Test headers
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("v-correlation-id", null);

            Assert.IsTrue(
                    TestHelper.AreHeadersProperSubsetOf (
                    headers,
                    HttpCallBack.Response.Headers),
                    "Headers should match");
        }
    }
}