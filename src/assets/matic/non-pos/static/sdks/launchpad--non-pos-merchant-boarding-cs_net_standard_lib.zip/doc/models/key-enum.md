
# Key Enum

## Enumeration

`KeyEnum`

## Fields

| Name |
|  --- |
| `PartnerEmployeeId` |
| `PartnerEmployeeName` |
| `PartnerEmployeePhoneNumber` |
| `PartnerEmployeeEmail` |
| `PartnerEmployeeType` |
| `PartnerEmployeeBranch` |
| `PartnerEmployeeCostCentre` |
| `PartnerEmployeeRegion` |
| `PartnerEmployeeOfficerCode` |
| `PartnerEmployeeCompany` |
| `PartnerEmployeeId2` |
| `PartnerEmployeeName2` |
| `PartnerEmployeePhoneNumber2` |
| `PartnerEmployeeEmail2` |
| `PartnerEmployeeType2` |
| `PartnerEmployeeBranch2` |
| `PartnerEmployeeCostCentre2` |
| `PartnerEmployeeRegion2` |
| `PartnerEmployeeOfficerCode2` |
| `PartnerEmployeeCompany2` |
| `PartnerEmployeeIndustry` |
| `PartnerLeadSource` |
| `PartnerEmployeeRef` |
| `PartnerMethod` |
| `PartnerVipIndicator` |
| `PartnerMarketRegion` |
| `PartnerPromotionCampaign` |
| `PartnerLeadType` |
| `PartnerCustom1` |
| `PartnerCustom2` |
| `PartnerCustom3` |
| `PartnerCustom4` |
| `PartnerCustom5` |
| `LeadInitiatedBy` |

## Example

```
partnerEmployeeId
```

