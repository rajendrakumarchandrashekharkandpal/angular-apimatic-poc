
# Application

## Structure

`Application`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientTrackingId` | `string` | Optional | This is an optional field that can be used by the partners to send a unique Id from their application for reporting purposes.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `36` |
| `BusinessInfo` | [`BusinessInfo1`](../../doc/models/business-info-1.md) | Required | - |
| `TransactionInfo` | [`TransactionInfo1`](../../doc/models/transaction-info-1.md) | Required | - |
| `Owners` | [`List<Owner1>`](../../doc/models/owner-1.md) | Optional | - |
| `AuthorizedSigners` | [`List<AuthorizedSigner1>`](../../doc/models/authorized-signer-1.md) | Required | - |
| `Guarantors` | [`List<Guarantor1>`](../../doc/models/guarantor-1.md) | Optional | Guarantor information. A guarantor is the person whose credit report will be pulled during the underwriting process.<br>**Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `Contacts` | [`List<Contact1>`](../../doc/models/contact-1.md) | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `Addresses` | [`List<Address1>`](../../doc/models/address-1.md) | Required | **Constraints**: *Minimum Items*: `1`, *Unique Items Required* |
| `BankAccount` | [`BankAccount1`](../../doc/models/bank-account-1.md) | Optional | Bank account collects bank account information from merchant. It is optional till the time of boarding where bank account becomes required along with ddaType, achType, accountNumber, routingNumber & bankName. |
| `AdvancedSettelment` | [`List<AdvancedSettlementInner>`](../../doc/models/advanced-settlement-inner.md) | Optional | - |
| `SalesAgent` | [`SalesAgent1`](../../doc/models/sales-agent-1.md) | Optional | The agent who is submitting the deal. It is an optional object. It becomes required, when  partner wants to route deals to their own sales rep. Please work with your integration specialist for route to sales rep functionality. |
| `InstallationContact` | [`InstallationContact`](../../doc/models/installation-contact.md) | Optional | The Technical Agent who is going to do setup. |
| `AdditionalInformation` | [`List<AdditionalInformationObject>`](../../doc/models/additional-information-object.md) | Optional | - |
| `LeadSource` | `string` | Optional | The source of the lead.<br>**Constraints**: *Maximum Length*: `150` |
| `RouteToSalesRep` | `bool?` | Optional | Used to route a application to a worldpay or partner sales rep. |
| `ProductsInquiry` | `List<string>` | Optional | **Constraints**: *Unique Items Required*, *Minimum Length*: `1`, *Maximum Length*: `25` |

## Example (as JSON)

```json
{
  "clientTrackingId": "1341341234132412341",
  "businessInfo": {
    "dbaName": "The DBA Name",
    "legalName": "legalName8",
    "ownershipType": "LLC",
    "mccCode": "5812",
    "businessEstablishedDate": "2000-03-23",
    "websiteUrl": "www.thefoodplace.com",
    "numberOfLocation": 2,
    "federalTaxId": "123456781",
    "paymentAcceptanceMethod": [
      "inPerson",
      "onlineSite"
    ],
    "pciadc": "No",
    "pcidssValidated": "No",
    "surroundingArea": "Commercial",
    "productServiceSold": "Food",
    "ownAddYears": 2,
    "seasonal": "Yes",
    "activeMonths": [
      "Jan",
      "Feb",
      "Mar"
    ],
    "warranty": "1 YEAR",
    "returnPolicy": "30 Day",
    "govOwnedMerchantCountry": "US"
  },
  "transactionInfo": {
    "annualSalesVolume": 20000.12,
    "percentRetailSwipedTransactions": 82,
    "averageTicket": 2.3,
    "highestTicket": 32.41,
    "currentProcessor": "Global Payments",
    "acceptChargebacks": "No",
    "chargebackPercent": 0,
    "returnPercent": 10,
    "cardNotPresentPercent": 20,
    "businessToBusinessPercent": 20,
    "internetTransactionPercent": 10,
    "inPersonTransactionPercent": 10,
    "motoTransactionPercent": 10,
    "annualCreditSalesVolume": 123.32,
    "annualDebitSalesVolume": 32.23,
    "annualAmexVolume": 10000,
    "amexAverageTicket": 2.3,
    "averageNumberofDays": 10,
    "needsProcessingBy": "2022-11-01"
  },
  "authorizedSigners": [
    {
      "roleName": "Merchant",
      "signingExperience": "email",
      "signingOrder": "2",
      "title": "President",
      "firstName": "Todd",
      "middleInitial": "M",
      "lastName": "Davis",
      "phoneNumber": "5131234567",
      "phoneNumberExt": "1234",
      "phoneType": "mobile",
      "alternatePhone": "5131234567",
      "alternatePhoneType": "home",
      "faxNumber": "5131234567",
      "email": "test@gmail.com",
      "ssn": "123456789",
      "dob": "2000-03-23",
      "addressLine1": "4355 N Coalwhipe St.",
      "addressLine2": "suite 104",
      "city": "Denver",
      "state": "CO",
      "country": "United States",
      "postalCode": "12345",
      "postalCodeExtension": "1234"
    }
  ],
  "contacts": [
    {
      "type": "Primary Contact",
      "title": "President",
      "firstName": "Todd",
      "middleInitial": "M",
      "lastName": "Davis",
      "ssn": "123456789",
      "birthDate": "2000-03-23",
      "phoneNumber": "5131234567",
      "phoneNumberExt": "1234",
      "phoneType": "mobile",
      "alternatePhone": "5131234567",
      "alternatePhoneType": "home",
      "email": "test@gmail.com",
      "faxNumber": "5131234567"
    }
  ],
  "addresses": [
    {
      "type": "Mailing Address",
      "addressLine1": "1234 W Tester Ave.",
      "city": "City Town",
      "state": "CO",
      "country": "United States",
      "postalCode": "80123",
      "postalCodeExtension": "1234",
      "addressLine2": "addressLine24"
    },
    {
      "type": "Physical Address",
      "addressLine1": "1234 W Tester Ave.",
      "city": "City Town",
      "state": "CO",
      "country": "United States",
      "postalCode": "80123",
      "postalCodeExtension": "1234",
      "addressLine2": "addressLine24"
    },
    {
      "type": "Shipping Address",
      "addressLine1": "1234 W Tester Ave.",
      "city": "City Town",
      "state": "CO",
      "country": "United States",
      "postalCode": "80123",
      "postalCodeExtension": "1234",
      "addressLine2": "addressLine24"
    }
  ],
  "leadSource": "LP Connect API",
  "owners": [
    {
      "type": "Owner 1 Contact",
      "title": "title0",
      "firstName": "firstName0",
      "middleInitial": "middleInitial2",
      "lastName": "lastName8",
      "phoneNumber": "phoneNumber6",
      "phoneNumberExt": "phoneNumberExt4",
      "phoneType": "mobile",
      "alternatePhone": "alternatePhone2",
      "email": "email2",
      "addressLine1": "addressLine16",
      "city": "city4",
      "state": "TX",
      "country": "country8",
      "postalCode": "postalCode4"
    },
    {
      "type": "Owner 1 Contact",
      "title": "title0",
      "firstName": "firstName0",
      "middleInitial": "middleInitial2",
      "lastName": "lastName8",
      "phoneNumber": "phoneNumber6",
      "phoneNumberExt": "phoneNumberExt4",
      "phoneType": "mobile",
      "alternatePhone": "alternatePhone2",
      "email": "email2",
      "addressLine1": "addressLine16",
      "city": "city4",
      "state": "TX",
      "country": "country8",
      "postalCode": "postalCode4"
    },
    {
      "type": "Owner 1 Contact",
      "title": "title0",
      "firstName": "firstName0",
      "middleInitial": "middleInitial2",
      "lastName": "lastName8",
      "phoneNumber": "phoneNumber6",
      "phoneNumberExt": "phoneNumberExt4",
      "phoneType": "mobile",
      "alternatePhone": "alternatePhone2",
      "email": "email2",
      "addressLine1": "addressLine16",
      "city": "city4",
      "state": "TX",
      "country": "country8",
      "postalCode": "postalCode4"
    }
  ],
  "guarantors": [
    {
      "type": "Guarantor 3 Contact",
      "title": "title0",
      "firstName": "firstName0",
      "middleInitial": "middleInitial2",
      "lastName": "lastName8",
      "phoneNumber": "phoneNumber6",
      "phoneNumberExt": "phoneNumberExt4",
      "phoneType": "mobile",
      "alternatePhone": "alternatePhone2",
      "email": "email2",
      "addressLine1": "addressLine14",
      "city": "city6",
      "state": "KY",
      "country": "country8",
      "postalCode": "postalCode4"
    },
    {
      "type": "Guarantor 3 Contact",
      "title": "title0",
      "firstName": "firstName0",
      "middleInitial": "middleInitial2",
      "lastName": "lastName8",
      "phoneNumber": "phoneNumber6",
      "phoneNumberExt": "phoneNumberExt4",
      "phoneType": "mobile",
      "alternatePhone": "alternatePhone2",
      "email": "email2",
      "addressLine1": "addressLine14",
      "city": "city6",
      "state": "KY",
      "country": "country8",
      "postalCode": "postalCode4"
    }
  ],
  "bankAccount": {
    "ddaType": "Checking",
    "achType": "Commercial Checking",
    "accountNumber": "accountNumber4",
    "routingNumber": "routingNumber0",
    "bankName": "bankName6"
  },
  "advancedSettelment": [
    {
      "settlementCategories": [
        "Fees"
      ],
      "bankAccount": {
        "ddaType": "Checking",
        "achType": "Commercial Checking",
        "accountNumber": "accountNumber4",
        "routingNumber": "routingNumber0",
        "bankName": "bankName6"
      }
    }
  ]
}
```

