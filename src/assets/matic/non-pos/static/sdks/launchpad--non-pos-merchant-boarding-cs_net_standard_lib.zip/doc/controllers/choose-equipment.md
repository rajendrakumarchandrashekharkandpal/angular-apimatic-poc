# Choose Equipment

```csharp
ChooseEquipmentController chooseEquipmentController = client.ChooseEquipmentController;
```

## Class Name

`ChooseEquipmentController`

## Methods

* [Get Terminal Info](../../doc/controllers/choose-equipment.md#get-terminal-info)
* [Update Terminal](../../doc/controllers/choose-equipment.md#update-terminal)
* [Config Standalone Terminal](../../doc/controllers/choose-equipment.md#config-standalone-terminal)


# Get Terminal Info

Gets the terminal configuration information for a specific partner.

```csharp
GetTerminalInfoAsync(
    Guid externalRefId,
    Guid? vCorrelationId = null,
    Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson,
    string locationId = null,
    string merchantId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `Guid` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `Guid?` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum?`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `locationId` | `string` | Header, Optional | The locationId returned from POST /locations call. |
| `merchantId` | `string` | Header, Optional | The merchantId returned from POST /merchants call. |

## Response Type

[`Task<Models.EquipmentSetup>`](../../doc/models/equipment-setup.md)

## Example Usage

```csharp
Guid externalRefId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
Guid? vCorrelationId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
ContentTypeEnum? contentType = ContentTypeEnum.EnumApplicationjson;
try
{
    EquipmentSetup result = await chooseEquipmentController.GetTerminalInfoAsync(
        externalRefId,
        vCorrelationId,
        contentType
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Update Terminal

Updates terminal configurations.

```csharp
UpdateTerminalAsync(
    Guid externalRefId,
    Models.EquipmentSetup body,
    Guid? vCorrelationId = null,
    Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson,
    string locationId = null,
    string merchantId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `Guid` | Header, Required | The externalRefId returned from POST /applications call. |
| `body` | [`EquipmentSetup`](../../doc/models/equipment-setup.md) | Body, Required | - |
| `vCorrelationId` | `Guid?` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum?`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `locationId` | `string` | Header, Optional | The locationId returned from POST /locations call. |
| `merchantId` | `string` | Header, Optional | The merchantId returned from POST /merchants call. |

## Response Type

`Task`

## Example Usage

```csharp
Guid externalRefId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
EquipmentSetup body = new EquipmentSetup
{
    ShippingOption = ShippingOptionEnum.EnumNextDay,
    Terminals = new List<Models.Terminal>
    {
        new Terminal
        {
            TerminalConfigs = new TerminalConfig
            {
                TerminalId = "67",
                Price = 187.99,
                Quantity = 1,
                LogicalApplicationId = "194",
                AccessMethod = "SSL",
                PaymentMethod = PaymentMethodEnum.EnumPURCHASESALE,
                EnvironmentName = "Restaurant",
                RequestId = "41231",
                TerminalModel = "VAR - Xpient Solutions",
            },
            Products = new List<Models.Product>
            {
                new Product
                {
                    ProductId = "1",
                    ProductName = "Credit",
                },
            },
        },
    },
};

try
{
    await chooseEquipmentController.UpdateTerminalAsync(
        externalRefId,
        body
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Config Standalone Terminal

Sets up terminal configurations.

```csharp
ConfigStandaloneTerminalAsync(
    Guid externalRefId,
    Models.EquipmentSetup body,
    Guid? vCorrelationId = null,
    Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson,
    string locationId = null,
    string merchantId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `Guid` | Header, Required | The externalRefId returned from POST /applications call. |
| `body` | [`EquipmentSetup`](../../doc/models/equipment-setup.md) | Body, Required | - |
| `vCorrelationId` | `Guid?` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum?`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `locationId` | `string` | Header, Optional | The locationId returned from POST /locations call. |
| `merchantId` | `string` | Header, Optional | The merchantId returned from POST /merchants call. |

## Response Type

`Task`

## Example Usage

```csharp
Guid externalRefId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
EquipmentSetup body = new EquipmentSetup
{
    ShippingOption = ShippingOptionEnum.EnumNextDay,
    Terminals = new List<Models.Terminal>
    {
        new Terminal
        {
            TerminalConfigs = new TerminalConfig
            {
                TerminalId = "67",
                Price = 187.99,
                Quantity = 1,
                LogicalApplicationId = "194",
                AccessMethod = "SSL",
                PaymentMethod = PaymentMethodEnum.EnumPURCHASESALE,
                EnvironmentName = "Restaurant",
                RequestId = "41231",
                TerminalModel = "VAR - Xpient Solutions",
            },
            Products = new List<Models.Product>
            {
                new Product
                {
                    ProductId = "1",
                    ProductName = "Credit",
                },
            },
        },
    },
};

try
{
    await chooseEquipmentController.ConfigStandaloneTerminalAsync(
        externalRefId,
        body
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

