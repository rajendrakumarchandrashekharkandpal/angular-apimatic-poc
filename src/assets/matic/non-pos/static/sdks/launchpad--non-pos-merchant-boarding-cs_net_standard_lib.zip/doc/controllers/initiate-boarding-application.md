# Initiate Boarding Application

```csharp
InitiateBoardingApplicationController initiateBoardingApplicationController = client.InitiateBoardingApplicationController;
```

## Class Name

`InitiateBoardingApplicationController`

## Methods

* [Fetch Application](../../doc/controllers/initiate-boarding-application.md#fetch-application)
* [Exisiting Application](../../doc/controllers/initiate-boarding-application.md#exisiting-application)
* [New Application](../../doc/controllers/initiate-boarding-application.md#new-application)


# Fetch Application

Retrieves existing application data.

```csharp
FetchApplicationAsync(
    Guid externalRefId,
    Guid? vCorrelationId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `Guid` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `Guid?` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`Task<Models.ExistingApplication>`](../../doc/models/existing-application.md)

## Example Usage

```csharp
Guid externalRefId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
Guid? vCorrelationId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
try
{
    ExistingApplication result = await initiateBoardingApplicationController.FetchApplicationAsync(
        externalRefId,
        vCorrelationId
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Exisiting Application

This endpoint allows merchants to update an existing application with new information.

```csharp
ExisitingApplicationAsync(
    Models.ExistingApplication1 body,
    Guid? vCorrelationId = null,
    Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ExistingApplication1`](../../doc/models/existing-application-1.md) | Body, Required | - |
| `vCorrelationId` | `Guid?` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum?`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

`Task`

## Example Usage

```csharp
ExistingApplication1 body = new ExistingApplication1
{
    ExternalRefId = "df8a6d82-3bb4-4f3b-ba18-57a5981ede8e",
    BusinessInfo = new BusinessInfo1
    {
        DbaName = "The DBA Name",
        LegalName = "legalName8",
        OwnershipType = OwnershipTypeEnum.LLC,
        MccCode = "5812",
        BusinessEstablishedDate = DateTime.Parse("2000-03-23"),
        WebsiteUrl = "www.thefoodplace.com",
        NumberOfLocation = 2,
        FederalTaxId = "123456781",
        PaymentAcceptanceMethod = new List<PaymentAcceptanceMethodEnum>
        {
            PaymentAcceptanceMethodEnum.InPerson,
            PaymentAcceptanceMethodEnum.OnlineSite,
        },
        Pciadc = PciadcEnum.No,
        PcidssValidated = PcidssValidatedEnum.No,
        SurroundingArea = SurroundingAreaEnum.Commercial,
        ProductServiceSold = "Food",
        OwnAddYears = 2,
        Seasonal = SeasonalEnum.Yes,
        ActiveMonths = new List<ActiveMonthEnum>
        {
            ActiveMonthEnum.Jan,
            ActiveMonthEnum.Feb,
            ActiveMonthEnum.Mar,
        },
        Warranty = WarrantyEnum.Enum1YEAR,
        ReturnPolicy = ReturnPolicyEnum.Enum30Day,
        GovOwnedMerchantCountry = "US",
    },
    TransactionInfo = new TransactionInfo1
    {
        AnnualSalesVolume = 20000.12,
        PercentRetailSwipedTransactions = 82,
        AverageTicket = 2.3,
        HighestTicket = 32.41,
        CurrentProcessor = "Global Payments",
        AcceptChargebacks = AcceptChargebacksEnum.No,
        ChargebackPercent = 0,
        ReturnPercent = 10,
        CardNotPresentPercent = 20,
        BusinessToBusinessPercent = 20,
        InternetTransactionPercent = 10,
        InPersonTransactionPercent = 10,
        MotoTransactionPercent = 10,
        AnnualCreditSalesVolume = 123.32,
        AnnualDebitSalesVolume = 32.23,
        AnnualAmexVolume = 10000,
        AmexAverageTicket = 2.3,
        AverageNumberofDays = 10,
        NeedsProcessingBy = DateTime.Parse("2022-11-01"),
    },
    LeadSource = "Activate",
    Addresses = new List<Models.Address1>
    {
        new Address1
        {
            Type = AddressTypeEnum.EnumMailingAddress,
            AddressLine1 = "1234 W Tester Ave.",
            City = "City Town",
            State = State1Enum.CO,
            Country = "United States",
            PostalCode = "80123",
            PostalCodeExtension = "1234",
        },
        new Address1
        {
            Type = AddressTypeEnum.EnumPhysicalAddress,
            AddressLine1 = "1234 W Tester Ave.",
            City = "City Town",
            State = State1Enum.CO,
            Country = "United States",
            PostalCode = "80123",
            PostalCodeExtension = "1234",
        },
    },
    RouteToSalesRep = false,
};

Guid? vCorrelationId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
ContentTypeEnum? contentType = ContentTypeEnum.EnumApplicationjson;
try
{
    await initiateBoardingApplicationController.ExisitingApplicationAsync(
        body,
        vCorrelationId,
        contentType
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# New Application

Use this endpoint to collect the merchant information needed to initiate a new contract.

```csharp
NewApplicationAsync(
    Models.Application body,
    Guid? vCorrelationId = null,
    Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`Application`](../../doc/models/application.md) | Body, Required | - |
| `vCorrelationId` | `Guid?` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum?`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

[`Task<Models.ApplicationResponse>`](../../doc/models/application-response.md)

## Example Usage

```csharp
Application body = new Application
{
    BusinessInfo = new BusinessInfo1
    {
        DbaName = "The DBA Name",
        LegalName = "legalName8",
        OwnershipType = OwnershipTypeEnum.LLC,
        MccCode = "5812",
        BusinessEstablishedDate = DateTime.Parse("2000-03-23"),
        WebsiteUrl = "www.thefoodplace.com",
        NumberOfLocation = 2,
        FederalTaxId = "123456781",
        PaymentAcceptanceMethod = new List<PaymentAcceptanceMethodEnum>
        {
            PaymentAcceptanceMethodEnum.InPerson,
            PaymentAcceptanceMethodEnum.OnlineSite,
        },
        Pciadc = PciadcEnum.No,
        PcidssValidated = PcidssValidatedEnum.No,
        SurroundingArea = SurroundingAreaEnum.Commercial,
        ProductServiceSold = "Food",
        OwnAddYears = 2,
        Seasonal = SeasonalEnum.Yes,
        ActiveMonths = new List<ActiveMonthEnum>
        {
            ActiveMonthEnum.Jan,
            ActiveMonthEnum.Feb,
            ActiveMonthEnum.Mar,
        },
        Warranty = WarrantyEnum.Enum1YEAR,
        ReturnPolicy = ReturnPolicyEnum.Enum30Day,
        GovOwnedMerchantCountry = "US",
    },
    TransactionInfo = new TransactionInfo1
    {
        AnnualSalesVolume = 20000.12,
        PercentRetailSwipedTransactions = 82,
        AverageTicket = 2.3,
        HighestTicket = 32.41,
        CurrentProcessor = "Global Payments",
        AcceptChargebacks = AcceptChargebacksEnum.No,
        ChargebackPercent = 0,
        ReturnPercent = 10,
        CardNotPresentPercent = 20,
        BusinessToBusinessPercent = 20,
        InternetTransactionPercent = 10,
        InPersonTransactionPercent = 10,
        MotoTransactionPercent = 10,
        AnnualCreditSalesVolume = 123.32,
        AnnualDebitSalesVolume = 32.23,
        AnnualAmexVolume = 10000,
        AmexAverageTicket = 2.3,
        AverageNumberofDays = 10,
        NeedsProcessingBy = DateTime.Parse("2022-11-01"),
    },
    AuthorizedSigners = new List<Models.AuthorizedSigner1>
    {
        new AuthorizedSigner1
        {
            RoleName = RoleName1Enum.Merchant,
            SigningExperience = SigningExperienceEnum.Email,
            SigningOrder = "2",
            FirstName = "Todd",
            LastName = "Davis",
            PhoneNumber = "5131234567",
            Email = "test@gmail.com",
            Ssn = "123456789",
            Dob = DateTime.Parse("2000-03-23"),
            AddressLine1 = "4355 N Coalwhipe St.",
            City = "Denver",
            State = State1Enum.CO,
            Country = "United States",
            PostalCode = "12345",
            Title = "President",
            MiddleInitial = "M",
            PhoneNumberExt = "1234",
            PhoneType = PhoneTypeEnum.Mobile,
            AlternatePhone = "5131234567",
            AlternatePhoneType = AlternatePhoneTypeEnum.Home,
            FaxNumber = "5131234567",
            AddressLine2 = "suite 104",
            PostalCodeExtension = "1234",
        },
    },
    Contacts = new List<Models.Contact1>
    {
        new Contact1
        {
            Type = Type4Enum.EnumPrimaryContact,
            FirstName = "Todd",
            LastName = "Davis",
            PhoneNumber = "5131234567",
            Email = "test@gmail.com",
            Title = "President",
            MiddleInitial = "M",
            Ssn = "123456789",
            BirthDate = DateTime.Parse("2000-03-23"),
            PhoneNumberExt = "1234",
            PhoneType = PhoneTypeEnum.Mobile,
            AlternatePhone = "5131234567",
            AlternatePhoneType = AlternatePhoneTypeEnum.Home,
            FaxNumber = "5131234567",
        },
    },
    Addresses = new List<Models.Address1>
    {
        new Address1
        {
            Type = AddressTypeEnum.EnumMailingAddress,
            AddressLine1 = "1234 W Tester Ave.",
            City = "City Town",
            State = State1Enum.CO,
            Country = "United States",
            PostalCode = "80123",
            PostalCodeExtension = "1234",
        },
        new Address1
        {
            Type = AddressTypeEnum.EnumPhysicalAddress,
            AddressLine1 = "1234 W Tester Ave.",
            City = "City Town",
            State = State1Enum.CO,
            Country = "United States",
            PostalCode = "80123",
            PostalCodeExtension = "1234",
        },
        new Address1
        {
            Type = AddressTypeEnum.EnumShippingAddress,
            AddressLine1 = "1234 W Tester Ave.",
            City = "City Town",
            State = State1Enum.CO,
            Country = "United States",
            PostalCode = "80123",
            PostalCodeExtension = "1234",
        },
    },
    ClientTrackingId = "1341341234132412341",
    LeadSource = "LP Connect API",
};

Guid? vCorrelationId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
ContentTypeEnum? contentType = ContentTypeEnum.EnumApplicationjson;
try
{
    ApplicationResponse result = await initiateBoardingApplicationController.NewApplicationAsync(
        body,
        vCorrelationId,
        contentType
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

