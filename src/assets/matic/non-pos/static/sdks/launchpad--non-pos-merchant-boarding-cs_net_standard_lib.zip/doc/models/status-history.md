
# Status History

## Structure

`StatusHistory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StatusSeqNumber` | `int?` | Optional | - |
| `DetailStatus` | `string` | Optional | - |
| `SummaryStatus` | `string` | Optional | - |
| `StatusCategory` | `string` | Optional | - |
| `StatusDateTime` | `DateTime?` | Optional | - |

## Example (as JSON)

```json
{
  "statusSeqNumber": 2200,
  "detailStatus": "Contract Signed",
  "summaryStatus": "App Submitted",
  "statusCategory": "Contract",
  "statusDateTime": "2016-03-13T12:52:32.123Z"
}
```

