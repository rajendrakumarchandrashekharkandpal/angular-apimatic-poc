
# Pciadc Enum

Indication if the merchant has had an account data compromise.

## Enumeration

`PciadcEnum`

## Fields

| Name |
|  --- |
| `Yes` |
| `No` |

## Example

```
No
```

