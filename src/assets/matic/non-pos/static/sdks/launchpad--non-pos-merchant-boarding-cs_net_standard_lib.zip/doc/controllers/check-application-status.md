# Check Application Status

```csharp
CheckApplicationStatusController checkApplicationStatusController = client.CheckApplicationStatusController;
```

## Class Name

`CheckApplicationStatusController`

## Methods

* [Get Application Status](../../doc/controllers/check-application-status.md#get-application-status)
* [Fetch Application Status History](../../doc/controllers/check-application-status.md#fetch-application-status-history)
* [Fetch Signer Status](../../doc/controllers/check-application-status.md#fetch-signer-status)


# Get Application Status

Retrieves the status of a contract when passed with an externalRefID. Both the externalRefID and authorization header are required.

```csharp
GetApplicationStatusAsync(
    Guid externalRefId,
    Guid? vCorrelationId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `Guid` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `Guid?` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`Task<Models.ApplicationStatus>`](../../doc/models/application-status.md)

## Example Usage

```csharp
Guid externalRefId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
Guid? vCorrelationId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
try
{
    ApplicationStatus result = await checkApplicationStatusController.GetApplicationStatusAsync(
        externalRefId,
        vCorrelationId
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Fetch Application Status History

Use this endpoint to get a application's status history.

```csharp
FetchApplicationStatusHistoryAsync(
    Guid externalRefId,
    Guid? vCorrelationId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `Guid` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `Guid?` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`Task<Models.StatusHistoryResponse>`](../../doc/models/status-history-response.md)

## Example Usage

```csharp
Guid externalRefId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
Guid? vCorrelationId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
try
{
    StatusHistoryResponse result = await checkApplicationStatusController.FetchApplicationStatusHistoryAsync(
        externalRefId,
        vCorrelationId
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |


# Fetch Signer Status

Use this endpoint to get signer status

```csharp
FetchSignerStatusAsync(
    Guid externalRefId,
    Guid? vCorrelationId = null,
    Models.ContentTypeEnum? contentType = Models.ContentTypeEnum.EnumApplicationjson)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `Guid` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `Guid?` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum?`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |

## Response Type

[`Task<Models.SignerStatus>`](../../doc/models/signer-status.md)

## Example Usage

```csharp
Guid externalRefId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
Guid? vCorrelationId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
ContentTypeEnum? contentType = ContentTypeEnum.EnumApplicationjson;
try
{
    SignerStatus result = await checkApplicationStatusController.FetchSignerStatusAsync(
        externalRefId,
        vCorrelationId,
        contentType
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

