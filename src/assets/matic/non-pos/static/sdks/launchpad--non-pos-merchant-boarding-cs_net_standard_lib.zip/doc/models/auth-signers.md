
# Auth Signers

## Structure

`AuthSigners`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FirstName` | `string` | Optional | First name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `15`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `MiddleInitial` | `string` | Optional | Middle initial.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `LastName` | `string` | Optional | Last name. Region based validations will be applied to this field.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `25`, *Pattern*: `^[a-zA-Z0-9 \p{P}\p{S}]+$` |
| `Email` | `string` | Optional | Email address of the contact. Must have @ and a .<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64`, *Pattern*: `\b[A-Za-z0-9._%+-]+@(?:[A-Za-z0-9-]+\.)+[A-Za-z0-9]{2,}` |
| `Status` | `string` | Optional | Status of the signer |
| `LastUpdated` | `DateTime?` | Optional | Date contract was last updated |
| `DateSubmitted` | `DateTime?` | Optional | Date contract was last updated |
| `DateSent` | `DateTime?` | Optional | Date contract was sent |
| `DateDelivered` | `DateTime?` | Optional | Date contract was delivered |
| `DateSigned` | `DateTime?` | Optional | Date contract was signed |
| `SignerRoleName` | `string` | Optional | Role of the signer |
| `SignerExperience` | `string` | Optional | Method of sign |

## Example (as JSON)

```json
{
  "firstName": "Todd",
  "middleInitial": "M",
  "lastName": "Davis",
  "email": "test@gmail.com",
  "status": "sent",
  "signerRoleName": "Merchant",
  "signerExperience": "wet"
}
```

