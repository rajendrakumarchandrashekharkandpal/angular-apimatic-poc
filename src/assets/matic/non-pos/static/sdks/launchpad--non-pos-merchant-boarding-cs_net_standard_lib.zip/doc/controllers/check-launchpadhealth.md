# Check Launchpadhealth

```csharp
CheckLaunchpadhealthController checkLaunchpadhealthController = client.CheckLaunchpadhealthController;
```

## Class Name

`CheckLaunchpadhealthController`


# Gethealth

Checks the the health of Launchpad and its dependent down streams systems like CPQ, Sales Force, XAA and Jigsaw at regular intervals to check the system is up or down.

```csharp
GethealthAsync(
    Guid? vCorrelationId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vCorrelationId` | `Guid?` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |

## Response Type

[`Task<Models.InlineResponse2001>`](../../doc/models/inline-response-2001.md)

## Example Usage

```csharp
Guid? vCorrelationId = new Guid("3fcb1437-4e52-4946-9ae1-e618351b6d16");
try
{
    InlineResponse2001 result = await checkLaunchpadHealthController.GethealthAsync(vCorrelationId);
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

