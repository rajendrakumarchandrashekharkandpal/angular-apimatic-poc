# Reviewand Sign Contract

```ts
const reviewandSignContractController = new ReviewandSignContractController(client);
```

## Class Name

`ReviewandSignContractController`

## Methods

* [Get Contract](../../doc/controllers/reviewand-sign-contract.md#get-contract)
* [Docusign Link](../../doc/controllers/reviewand-sign-contract.md#docusign-link)


# Get Contract

Returns a PDF contract to be signed.

```ts
async getContract(
  externalRefId: string,
  vCorrelationId?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<unknown>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `externalRefId` | `string` | Header, Required | The externalRefId returned from POST /applications call. |
| `vCorrelationId` | `string \| undefined` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`unknown`

## Example Usage

```ts
const externalRefId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

const vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await reviewAndSignContractController.getContract(
  externalRefId,
  vCorrelationId
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseError`](../../doc/models/error-response-error.md) |


# Docusign Link

Retrieves a Docusign link to view the contract.

```ts
async docusignLink(
  body: DocumentLink,
  vCorrelationId?: string,
  contentType?: ContentTypeEnum,
  requestOptions?: RequestOptions
): Promise<ApiResponse<DocuSignLink>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`DocumentLink`](../../doc/models/document-link.md) | Body, Required | - |
| `vCorrelationId` | `string \| undefined` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `contentType` | [`ContentTypeEnum \| undefined`](../../doc/models/content-type-enum.md) | Header, Optional | Indicates the media type of the request-body. Accepts application/json. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`DocuSignLink`](../../doc/models/docu-sign-link.md)

## Example Usage

```ts
const body: DocumentLink = {
  externalRefId: 'df8a6d82-3bb4-4f3b-ba18-57a5981ede8e',
  returnUrl: 'https://docusign.com',
};

const vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

const contentType = ContentTypeEnum.EnumApplicationjson;

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await reviewAndSignContractController.docusignLink(
  body,
  vCorrelationId,
  contentType
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| Default | Default errors | [`ErrorResponseError`](../../doc/models/error-response-error.md) |

