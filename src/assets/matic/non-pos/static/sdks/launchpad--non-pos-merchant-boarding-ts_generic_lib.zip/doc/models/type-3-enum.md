
# Type 3 Enum

## Enumeration

`Type3Enum`

## Fields

| Name |
|  --- |
| `enumGuarantor1Contact` |
| `enumGuarantor2Contact` |
| `enumGuarantor3Contact` |
| `enumGuarantor4Contact` |

## Example

```
Guarantor 1 Contact
```

