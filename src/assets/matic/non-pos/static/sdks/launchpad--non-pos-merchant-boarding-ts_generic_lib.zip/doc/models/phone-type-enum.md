
# Phone Type Enum

Phone type.

## Enumeration

`PhoneTypeEnum`

## Fields

| Name |
|  --- |
| `mobile` |
| `home` |

## Example

```
mobile
```

