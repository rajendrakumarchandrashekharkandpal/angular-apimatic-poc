
# Pcidss Validated Enum

Indictor showing if the merchant is compliant or not with the Payment Card Industry Data Security Standards.

## Enumeration

`PcidssValidatedEnum`

## Fields

| Name |
|  --- |
| `yes` |
| `no` |

## Example

```
No
```

