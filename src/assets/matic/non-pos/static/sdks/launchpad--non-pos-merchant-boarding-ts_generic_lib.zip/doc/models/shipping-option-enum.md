
# Shipping Option Enum

The speed you would like the equipment to be shipped.

## Enumeration

`ShippingOptionEnum`

## Fields

| Name |
|  --- |
| `ground` |
| `enumNextDay` |
| `enum2ndDay` |

## Example

```
next day
```

