
# Contract Status Enum

## Enumeration

`ContractStatusEnum`

## Fields

| Name |
|  --- |
| `complete` |
| `enumInProgress` |
| `error` |
| `pending` |

