
# Identification

## Structure

`Identification`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `idType` | [`IdTypeEnum`](../../doc/models/id-type-enum.md) | Required | Type of ID provided by the owner. |
| `idNumber` | `string` | Required | Owner's ID number.<br>**Constraints**: *Maximum Length*: `40` |
| `issuedCity` | `string \| undefined` | Optional | City in which ID was issued.<br>**Constraints**: *Maximum Length*: `28` |
| `issuedState` | [`IssuedStateEnum \| undefined`](../../doc/models/issued-state-enum.md) | Optional | Valid state code where ID was issued.<br>**Constraints**: *Maximum Length*: `2` |
| `issuedCountry` | `string \| undefined` | Optional | Country where ID was issued.<br>**Constraints**: *Maximum Length*: `2` |
| `dateIssued` | `string \| undefined` | Optional | Date ID was issued (CCYY-MM-DD). |
| `dateExpires` | `string \| undefined` | Optional | Date ID expires (CCYY-MM-DD). |

## Example (as JSON)

```json
{
  "idType": "PASSPORT",
  "idNumber": "312312341",
  "issuedCity": "City Town",
  "issuedState": "CO",
  "issuedCountry": "US",
  "dateIssued": "1999-01-30",
  "dateExpires": "2020-02-11"
}
```

