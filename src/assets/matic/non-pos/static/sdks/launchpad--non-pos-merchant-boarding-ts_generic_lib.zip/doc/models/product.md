
# Product

## Structure

`Product`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `productId` | `string \| undefined` | Optional | Product ID is populated internally. |
| `productName` | `string \| undefined` | Optional | Payment method associated with the internally-populated ID. |

## Example (as JSON)

```json
{
  "productId": "1",
  "productName": "Debit"
}
```

