
# Seasonal Enum

Does the business operate seasonally?

## Enumeration

`SeasonalEnum`

## Fields

| Name |
|  --- |
| `yes` |
| `no` |

## Example

```
Yes
```

