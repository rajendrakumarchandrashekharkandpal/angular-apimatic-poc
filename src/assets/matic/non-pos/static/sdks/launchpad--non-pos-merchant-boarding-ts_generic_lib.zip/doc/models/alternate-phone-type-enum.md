
# Alternate Phone Type Enum

Alternate phone type.

## Enumeration

`AlternatePhoneTypeEnum`

## Fields

| Name |
|  --- |
| `mobile` |
| `home` |

## Example

```
home
```

