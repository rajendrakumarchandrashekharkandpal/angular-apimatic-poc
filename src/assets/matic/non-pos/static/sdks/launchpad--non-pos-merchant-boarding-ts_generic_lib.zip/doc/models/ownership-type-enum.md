
# Ownership Type Enum

Required. OwnershipType defines the type of the Merchant Organization, and drives the requirements for data collections of beneficial and control owners under U.S. Financial Crimes Enforcement Network (FinCEN).

## Enumeration

`OwnershipTypeEnum`

## Fields

| Name |
|  --- |
| `gOVERNMENT` |
| `enumSOLEPROPRIETOR` |
| `lLC` |
| `pARTNERSHIP` |
| `enumFININSTITUTION` |
| `nONPROFIT` |
| `enumASSOCIATIONESTATETRUST` |
| `enumPRIVATECORPORATION` |
| `enumSECREGISTERED` |
| `enumPUBLICCORPORATION` |
| `oTHER` |

## Example

```
LLC
```

