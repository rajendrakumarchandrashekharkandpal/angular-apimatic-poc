
# Terminal Supply

## Structure

`TerminalSupply`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `supplyType` | `string` | Required | - |
| `name` | `string \| undefined` | Optional | Supply name |
| `quantity` | `number \| undefined` | Optional | Supply quantity |
| `total` | `string \| undefined` | Optional | Total Supplies. Valid values are 0.00<br><br>- 9999999999.99."<br>**Constraints**: *Pattern*: `(^\d{1,10}([.]\d{1,2})?)$` |

## Example (as JSON)

```json
{
  "supplyType": "supplyType2",
  "quantity": 2,
  "total": "220.21",
  "name": "name6"
}
```

