
# Transaction Info

## Structure

`TransactionInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `annualSalesVolume` | `number` | Required | Projected annual sales volume.<br>**Constraints**: `>= 0`, `<= 9999999999999.99` |
| `percentRetailSwipedTransactions` | `number` | Required | Projected Percentage of daily card-present transactions.<br>**Constraints**: `>= 0`, `<= 100` |
| `averageTicket` | `number \| undefined` | Optional | Average ticket dollar amount.<br>**Constraints**: `>= 0`, `<= 9999999.99` |
| `highestTicket` | `number \| undefined` | Optional | Highest ticket dollar amount.<br>**Constraints**: `>= 0`, `<= 9999999.99` |
| `currentProcessor` | `string \| undefined` | Optional | the current processor |
| `acceptChargebacks` | [`AcceptChargebacksEnum \| undefined`](../../doc/models/accept-chargebacks-enum.md) | Optional | Do you have more than 25 chargeback accepted in the last 12 months? |
| `chargebackPercent` | `number \| undefined` | Optional | Projected chargeback percentage.<br><br>`Required when acceptChargebacks is 'Yes'`<br><br>`Optional when acceptChargebacks is null or 'No'.`<br>**Constraints**: `>= 0`, `<= 100` |
| `returnPercent` | `number \| undefined` | Optional | Projected return percent of  goods sold<br>**Constraints**: `>= 0`, `<= 100` |
| `cardNotPresentPercent` | `number \| undefined` | Optional | Percent of card not present transactions.<br>**Constraints**: `>= 0`, `<= 100` |
| `businessToBusinessPercent` | `number \| undefined` | Optional | Percent of business-to-business transactions.<br>**Constraints**: `>= 0`, `<= 100` |
| `internetTransactionPercent` | `number \| undefined` | Optional | Percent of internet transactions.<br>**Constraints**: `>= 0`, `<= 100` |
| `annualCreditSalesVolume` | `number \| undefined` | Optional | Projected annual credit card sales volume.<br>**Constraints**: `>= 0`, `<= 999999999.99` |
| `annualDebitSalesVolume` | `number \| undefined` | Optional | Projected annual debit card sales volume.<br>**Constraints**: `>= 0`, `<= 999999999.99` |
| `annualAmexVolume` | `number \| undefined` | Optional | Projected annual Amex volume. `This field is required when you opt-in for Amex`<br>**Constraints**: `>= 0`, `<= 999999999.99` |
| `amexAverageTicket` | `number \| undefined` | Optional | AverageTicket dollar amount for Amex.<br>`This field is required when you opt-in for Amex`<br>**Constraints**: `>= 0`, `<= 9999999.99` |
| `averageNumberofDays` | `number \| undefined` | Optional | Average number of days from when cardholder is charged & when products or services are received IN FULL by cardholder.<br>**Constraints**: `>= 0` |

## Example (as JSON)

```json
{
  "annualSalesVolume": 20000.12,
  "percentRetailSwipedTransactions": 82,
  "averageTicket": 2.3,
  "highestTicket": 32.41,
  "currentProcessor": "Global Payments",
  "acceptChargebacks": "No",
  "chargebackPercent": 0,
  "returnPercent": 10,
  "cardNotPresentPercent": 20,
  "businessToBusinessPercent": 20,
  "internetTransactionPercent": 10,
  "annualCreditSalesVolume": 123.32,
  "annualDebitSalesVolume": 32.23,
  "annualAmexVolume": 10000,
  "amexAverageTicket": 2.3,
  "averageNumberofDays": 10
}
```

