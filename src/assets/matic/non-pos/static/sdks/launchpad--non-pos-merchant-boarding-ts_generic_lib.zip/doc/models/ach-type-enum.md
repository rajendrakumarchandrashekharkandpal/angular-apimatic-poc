
# Ach Type Enum

Check deposit type

## Enumeration

`AchTypeEnum`

## Fields

| Name |
|  --- |
| `enumCommercialChecking` |
| `enumPrivateChecking` |

## Example

```
Commercial Checking
```

