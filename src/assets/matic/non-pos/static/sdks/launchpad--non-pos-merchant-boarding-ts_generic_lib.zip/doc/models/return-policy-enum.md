
# Return Policy Enum

The business's return policy.

## Enumeration

`ReturnPolicyEnum`

## Fields

| Name |
|  --- |
| `enum3Day` |
| `enum30Day` |
| `enum60Day` |
| `enum60Day1` |
| `enumALLSALESFINAL` |
| `enumEXCHANGEONLYSTORECREDIT` |
| `enumNORETURNPOLICY` |

## Example

```
30 Day
```

