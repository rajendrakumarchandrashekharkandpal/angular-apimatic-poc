
# Issued State Enum

Valid state code where ID was issued.

## Enumeration

`IssuedStateEnum`

## Fields

| Name |
|  --- |
| `aK` |
| `aL` |
| `aR` |
| `aS` |
| `aZ` |
| `cA` |
| `cO` |
| `cT` |
| `dC` |
| `dE` |
| `fL` |
| `fM` |
| `gA` |
| `gU` |
| `hI` |
| `iA` |
| `iD` |
| `iL` |
| `iN` |
| `kS` |
| `kY` |
| `lA` |
| `mA` |
| `mD` |
| `mE` |
| `mH` |
| `mI` |
| `mN` |
| `mO` |
| `mP` |
| `mS` |
| `mT` |
| `nC` |
| `nD` |
| `nE` |
| `nH` |
| `nJ` |
| `nM` |
| `nV` |
| `nY` |
| `oH` |
| `oK` |
| `oR` |
| `pA` |
| `pR` |
| `pW` |
| `rI` |
| `sC` |
| `sD` |
| `tN` |
| `tX` |
| `uT` |
| `vA` |
| `vI` |
| `vT` |
| `wA` |
| `wI` |
| `wV` |
| `wY` |

## Example

```
CO
```

