
# Type Enum

The Owner Type. Please note the above Ownership Types where a Control Owner is required.

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `enumControlOwnerContact` |
| `enumOwner1Contact` |
| `enumOwner2Contact` |
| `enumOwner3Contact` |
| `enumOwner4Contact` |

