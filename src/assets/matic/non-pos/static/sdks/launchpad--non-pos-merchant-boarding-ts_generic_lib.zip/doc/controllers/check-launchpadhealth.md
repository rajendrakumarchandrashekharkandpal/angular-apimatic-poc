# Check Launchpadhealth

```ts
const checkLaunchpadhealthController = new CheckLaunchpadhealthController(client);
```

## Class Name

`CheckLaunchpadhealthController`


# Gethealth

Checks the the health of Launchpad and its dependent down streams systems like CPQ, Sales Force, XAA and Jigsaw at regular intervals to check the system is up or down.

```ts
async gethealth(
  vCorrelationId?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<InlineResponse2001>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vCorrelationId` | `string \| undefined` | Header, Optional | Unique transaction Id. Will be generated if not provided and returned in response headers. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

[`InlineResponse2001`](../../doc/models/inline-response-2001.md)

## Example Usage

```ts
const vCorrelationId = '3fcb1437-4e52-4946-9ae1-e618351b6d16';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await checkLaunchpadHealthController.gethealth(vCorrelationId);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

