
# Inline Response 200 Equipment

## Structure

`InlineResponse200Equipment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string \| undefined` | Optional | - |
| `name` | `string \| undefined` | Optional | - |
| `logicalApplicationId` | `string \| undefined` | Optional | - |
| `environment` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "id": "1",
  "name": "Verifone LX570",
  "logicalApplicationId": "1073",
  "environment": "Retail"
}
```

