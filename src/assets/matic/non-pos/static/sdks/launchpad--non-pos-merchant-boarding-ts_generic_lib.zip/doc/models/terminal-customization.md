
# Terminal Customization

## Structure

`TerminalCustomization`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customizationId` | `string \| undefined` | Optional | Customization ID is internally populated from a master list. |
| `customizationName` | `string \| undefined` | Optional | - |
| `customizationFieldValue` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "customizationId": "10",
  "customizationName": "Auto-Close Time",
  "customizationFieldValue": "N"
}
```

