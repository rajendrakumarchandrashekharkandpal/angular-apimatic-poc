
# Dda Type Enum

Direct deposit account type.

## Enumeration

`DdaTypeEnum`

## Fields

| Name |
|  --- |
| `checking` |
| `savings` |

## Example

```
Checking
```

