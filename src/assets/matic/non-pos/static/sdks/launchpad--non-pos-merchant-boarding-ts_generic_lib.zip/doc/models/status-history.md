
# Status History

## Structure

`StatusHistory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `statusSeqNumber` | `number \| undefined` | Optional | - |
| `detailStatus` | `string \| undefined` | Optional | - |
| `summaryStatus` | `string \| undefined` | Optional | - |
| `statusCategory` | `string \| undefined` | Optional | - |
| `statusDateTime` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "statusSeqNumber": 2200,
  "detailStatus": "Contract Signed",
  "summaryStatus": "App Submitted",
  "statusCategory": "Contract",
  "statusDateTime": "2016-03-13T12:52:32.123Z"
}
```

